/**
 * routes/dosen/kurikulum.js
 * Menampilkan kurikulum prodi (daftar mata kuliah) dan detail MK
 * Serta halaman MyRPS (daftar MK yang diampu dosen) dan manajemen RPS + materi pertemuan
 * - Upload RPS (PDF) ke Google Drive
 * - Update pertemuan: tanggal, status, catatan, upload file pendukung
 * Topik materi sudah ditentukan oleh admin/kaprodi (tidak bisa diubah dosen)
 */

const express = require('express');
const router = express.Router();
const { verifyToken, isDosen } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const { filterIdMahasiswaAktif } = require('../../helpers/statusMahasiswaHelper');
const { dosenCache } = require('../../helpers/cache');
const drive = require('../../config/googleDrive');
const { Readable } = require('stream');
const { getRencanaPertemuan, getInfoRencana } = require('../../data/rencanaPertemuanData');
const multer = require('multer');
const upload = multer({ storage: multer.memoryStorage() });
const { getPeriodeAktif } = require('../../helpers/nilaiHelper');
const academicHelper = require('../../helpers/academicHelper');

router.use(verifyToken);
router.use(isDosen);

// ============================================================================
// KONSTANTA FOLDER GOOGLE DRIVE
// ============================================================================
const DATA_WEB_FOLDER_ID = '17Z02_5zOImG1GYfi_5gvWL97-p6dW5t0'; // Ganti dengan ID folder Data WEB Anda

async function getOrCreateSubFolder(parentId, name) {
  const query = await drive.files.list({
    q: `'${parentId}' in parents and name='${name}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    fields: 'files(id)',
  });
  if (query.data.files.length > 0) {
    return query.data.files[0].id;
  } else {
    const folder = await drive.files.create({
      resource: { name, mimeType: 'application/vnd.google-apps.folder', parents: [parentId] },
      fields: 'id',
    });
    return folder.data.id;
  }
}

async function getRpsFolder(kodeMK) {
  const parentDosen = await getOrCreateSubFolder(DATA_WEB_FOLDER_ID, 'Dosen');
  const parentRps = await getOrCreateSubFolder(parentDosen, 'RPS MK');
  const mkFolder = await getOrCreateSubFolder(parentRps, kodeMK);
  return mkFolder;
}

async function getMateriMkFolder(kodeMK) {
  const parentDosen = await getOrCreateSubFolder(DATA_WEB_FOLDER_ID, 'Dosen');
  const parentMateri = await getOrCreateSubFolder(parentDosen, 'Materi MK');
  const mkFolder = await getOrCreateSubFolder(parentMateri, kodeMK);
  return mkFolder;
}

function removeUndefined(obj) {
  Object.keys(obj).forEach(key => obj[key] === undefined && delete obj[key]);
  return obj;
}

// Data dosen per ID lewat dosenCache bersama (10 menit, sama seperti di
// elearning/pengajaran) - dulu get() satu per satu berurutan di setiap halaman.
async function getDosenData(id) {
  return dosenCache.getOrFetch(id, async () => {
    const doc = await db.collection('dosen').doc(id).get();
    return doc.exists ? doc.data() : null;
  });
}

async function getDosenNames(dosenIds) {
  if (!dosenIds || dosenIds.length === 0) return '-';
  const datas = await Promise.all(dosenIds.map(getDosenData));
  const names = datas.filter(Boolean).map(d => d.nama);
  return names.join(', ') || '-';
}

// ============================================================================
// ROUTE UTAMA (DAFTAR MK YANG DIAMPU DOSEN) - dengan filter semester
// ============================================================================
router.get('/', async (req, res) => {
  try {
    const dosenId = req.dosen.id;
    const { semester } = req.query;

    let query = db.collection('mataKuliah')
      .where('dosenIds', 'array-contains', dosenId)
      .orderBy('semester')
      .orderBy('kode');

    if (semester) query = query.where('semester', '==', parseInt(semester));

    const mkSnapshot = await query.get();
    const mkList = [];
    for (const doc of mkSnapshot.docs) {
      const data = doc.data();
      const dosenNames = await getDosenNames(data.dosenIds || []);
      mkList.push({
        id: doc.id,
        kode: data.kode,
        nama: data.nama,
        sks: data.sks,
        semester: data.semester,
        dosen: dosenNames,
        rpsUrl: data.rpsUrl || null
      });
    }

    const semesterSet = new Set();
    mkList.forEach(mk => semesterSet.add(mk.semester));
    const semesterList = Array.from(semesterSet).sort((a, b) => a - b);

    res.render('dosen/kurikulum/my_rps', {
      title: 'Mata Kuliah Saya',
      mkList,
      semesterList,
      selectedSemester: semester || ''
    });
  } catch (error) {
    console.error('Error memuat kurikulum dosen:', error);
    res.status(500).render('error', { message: 'Gagal memuat data mata kuliah' });
  }
});

// ============================================================================
// HALAMAN MY RPS (tanpa filter)
// ============================================================================
router.get('/my-rps', async (req, res) => {
  try {
    const dosenId = req.dosen.id;
    const mkSnapshot = await db.collection('mataKuliah')
      .where('dosenIds', 'array-contains', dosenId)
      .orderBy('semester')
      .orderBy('kode')
      .get();

    const mkList = mkSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        kode: data.kode,
        nama: data.nama,
        sks: data.sks,
        semester: data.semester,
        rpsUrl: data.rpsUrl || null
      };
    });

    res.render('dosen/kurikulum/my_rps', {
      title: 'My RPS',
      mkList,
      semesterList: [],
      selectedSemester: ''
    });
  } catch (error) {
    console.error('Error memuat My RPS:', error);
    res.status(500).render('error', { message: 'Gagal memuat data RPS' });
  }
});

// ============================================================================
// RPS PER PERIODE - supaya RPS bisa berbeda tiap semester tanpa menimpa
// riwayat RPS semester sebelumnya. Disimpan di subcollection
// mataKuliah/{id}/rpsPeriode/{periodeId}. Field mk.rpsUrl tetap disinkronkan
// mengikuti periode AKTIF, supaya halaman lain yang membaca mk.rpsUrl
// (daftar admin, halaman publik dokumen, dll) tidak perlu diubah.
// ============================================================================
async function getRpsUntukPeriode(mkId, periodeId, fallbackUrl) {
  const doc = await db.collection('mataKuliah').doc(mkId).collection('rpsPeriode').doc(periodeId).get();
  if (doc.exists) return doc.data();
  const activePeriodeId = academicHelper.getActivePeriodeId();
  if (periodeId === activePeriodeId && fallbackUrl) {
    return { fileUrl: fallbackUrl, fileNama: null, uploadedAt: null };
  }
  return null;
}

async function getRiwayatRps(mkId) {
  const snap = await db.collection('mataKuliah').doc(mkId).collection('rpsPeriode').orderBy('urutan', 'desc').get();
  return snap.docs.map(doc => doc.data());
}

// ============================================================================
// HANDLER UPLOAD RPS (digunakan oleh dua route)
// ============================================================================
async function handleUploadRps(req, res, mkId) {
  try {
    const mkDoc = await db.collection('mataKuliah').doc(mkId).get();
    if (!mkDoc.exists) return res.status(404).send('Mata kuliah tidak ditemukan');
    const mkData = mkDoc.data();

    if (!mkData.dosenIds || !mkData.dosenIds.includes(req.dosen.id)) {
      return res.status(403).send('Anda tidak memiliki akses ke mata kuliah ini');
    }
    if (!req.file) return res.status(400).send('File RPS tidak ditemukan');

    const periodeId = req.body.periodeId || academicHelper.getActivePeriodeId();
    const periodeOptions = academicHelper.generatePeriodeOptions(50, 5);
    const info = periodeOptions.find(p => p.id === periodeId);

    const folderId = await getRpsFolder(mkData.kode);
    const fileName = `RPS_${mkData.kode}_${periodeId}.pdf`;
    const fileMetadata = { name: fileName, parents: [folderId] };
    const media = { mimeType: req.file.mimetype, body: Readable.from(req.file.buffer) };
    const response = await drive.files.create({ resource: fileMetadata, media, fields: 'id' });
    await drive.permissions.create({ fileId: response.data.id, requestBody: { role: 'reader', type: 'anyone' } });
    const fileUrl = `https://drive.google.com/uc?export=view&id=${response.data.id}`;

    await db.collection('mataKuliah').doc(mkId).collection('rpsPeriode').doc(periodeId).set({
      periodeId,
      label: info ? info.label : periodeId,
      urutan: info ? info.urutan : 0,
      fileUrl,
      fileNama: req.file.originalname,
      uploadedAt: new Date().toISOString()
    }, { merge: true });

    // Sinkronkan ke field utama hanya kalau ini periode yang sedang berjalan
    const activePeriodeId = academicHelper.getActivePeriodeId();
    if (periodeId === activePeriodeId) {
      await db.collection('mataKuliah').doc(mkId).update({ rpsUrl: fileUrl, updatedAt: new Date().toISOString() });
    }

    res.redirect(`/dosen/kurikulum/${mkId}?periode=${periodeId}`);
  } catch (error) {
    console.error('Error upload RPS:', error);
    res.status(500).send('Gagal mengupload RPS');
  }
}

// Route upload RPS standar (dengan prefix /dosen/kurikulum/:id/rps)
router.post('/:id/rps', upload.single('rpsFile'), (req, res) => handleUploadRps(req, res, req.params.id));

// ALIAS: untuk mendukung form yang menggunakan /dosen/mk/:id/rps
router.post('/mk/:id/rps', upload.single('rpsFile'), (req, res) => handleUploadRps(req, res, req.params.id));

// ============================================================================
// HANDLER UPDATE PERTEMUAN
// ============================================================================
async function handleUpdatePertemuan(req, res, mkId, pertemuanKe) {
  try {
    const { tanggal, status, catatan } = req.body;
    const file = req.file;

    const mkRef = db.collection('mataKuliah').doc(mkId);
    const mkDoc = await mkRef.get();
    if (!mkDoc.exists) return res.status(404).send('Mata kuliah tidak ditemukan');
    const mkData = mkDoc.data();

    if (!mkData.dosenIds || !mkData.dosenIds.includes(req.dosen.id)) {
      return res.status(403).send('Anda tidak memiliki akses ke mata kuliah ini');
    }

    let materi = mkData.materi || [];
    const idx = materi.findIndex(m => m.pertemuan === pertemuanKe);
    const old = idx !== -1 ? materi[idx] : {};

    const updated = { pertemuan: pertemuanKe, updatedAt: new Date().toISOString() };
    updated.topik = old.topik || `Pertemuan ${pertemuanKe}`;
    updated.tanggal = tanggal !== undefined ? tanggal : (old.tanggal || null);
    updated.status = status !== undefined ? status : (old.status || 'belum');
    updated.catatan = catatan !== undefined ? catatan : (old.catatan || '');

    if (file) {
      const folderId = await getMateriMkFolder(mkData.kode);
      const fileName = `Pertemuan_${pertemuanKe}_${Date.now()}.pdf`;
      const fileMetadata = { name: fileName, parents: [folderId] };
      const media = { mimeType: file.mimetype, body: Readable.from(file.buffer) };
      const response = await drive.files.create({ resource: fileMetadata, media, fields: 'id' });
      await drive.permissions.create({ fileId: response.data.id, requestBody: { role: 'reader', type: 'anyone' } });
      updated.fileUrl = `https://drive.google.com/uc?export=view&id=${response.data.id}`;
    } else {
      if (old.fileUrl) updated.fileUrl = old.fileUrl;
    }

    removeUndefined(updated);
    if (idx !== -1) materi[idx] = { ...materi[idx], ...updated };
    else materi.push(updated);

    materi.sort((a, b) => a.pertemuan - b.pertemuan);
    await mkRef.update({ materi, updatedAt: new Date().toISOString() });
    res.redirect(`/dosen/kurikulum/${mkId}`);
  } catch (error) {
    console.error('Error update pertemuan:', error);
    res.status(500).send('Gagal update pertemuan');
  }
}

// Route update pertemuan standar
router.post('/:id/pertemuan/:pertemuan', upload.single('file'), (req, res) => {
  handleUpdatePertemuan(req, res, req.params.id, parseInt(req.params.pertemuan));
});

// ALIAS: untuk mendukung form yang menggunakan /dosen/mk/:id/pertemuan/:pertemuan
router.post('/mk/:id/pertemuan/:pertemuan', upload.single('file'), (req, res) => {
  handleUpdatePertemuan(req, res, req.params.id, parseInt(req.params.pertemuan));
});

// ============================================================================
// HALAMAN DETAIL MATA KULIAH
// ============================================================================
router.get('/:id', async (req, res) => {
  try {
    const mkId = req.params.id;
    const mkDoc = await db.collection('mataKuliah').doc(mkId).get();
    if (!mkDoc.exists) {
      return res.status(404).render('error', { title: 'Tidak Ditemukan', message: 'Mata kuliah tidak ditemukan' });
    }
    const mk = { id: mkId, ...mkDoc.data() };

    if (!mk.dosenIds || !mk.dosenIds.includes(req.dosen.id)) {
      return res.status(403).render('error', { title: 'Akses Ditolak', message: 'Anda tidak memiliki akses ke mata kuliah ini' });
    }

    const dosenList = (await Promise.all((mk.dosenIds || []).map(getDosenData)))
      .filter(Boolean)
      .map(d => d.nama);

    const materiExisting = mk.materi || [];
    // Rekomendasi pembahasan per pertemuan (hardcoded dari RPS: data/rencanaPertemuanData.js)
    const rencanaRps = getRencanaPertemuan(mk.kode) || [];
    const infoRencana = getInfoRencana(mk.kode);
    const pertemuanList = [];
    for (let i = 1; i <= 16; i++) {
      const existing = materiExisting.find(m => m.pertemuan === i) || {};
      const rps = rencanaRps.find(r => r.pertemuan === i) || null;
      pertemuanList.push({
        pertemuan: i,
        topik: existing.topik || `Pertemuan ${i}`,
        tanggal: existing.tanggal || null,
        status: existing.status || 'belum',
        catatan: existing.catatan || '',
        fileUrl: existing.fileUrl || null,
        rekom: rps ? {
          topik: rps.topik,
          kemampuan: rps.kemampuan,
          metode: rps.metode,
          bobot: rps.bobot,
          jenis: rps.jenis,
          sumber: rps.sumber
        } : null
      });
    }
    // "Pertemuan ini" = pertemuan pertama yang belum selesai; "berikutnya" = sesudahnya.
    const idxIni = pertemuanList.findIndex(p => p.status !== 'selesai');
    const pertemuanIni = idxIni >= 0 ? pertemuanList[idxIni] : null;
    const pertemuanBerikut = idxIni >= 0 && idxIni + 1 < pertemuanList.length ? pertemuanList[idxIni + 1] : null;

    const terlaksana = pertemuanList.filter(p => p.status === 'selesai').length;
    const persentase = Math.round((terlaksana / 16) * 100);

    const enrollmentSnapshot = await db.collection('enrollment').where('mkId', '==', mkId).where('status', '==', 'active').get();
    const mahasiswaIds = await filterIdMahasiswaAktif(db, enrollmentSnapshot.docs.map(doc => doc.data().userId).filter(uid => uid));
    const mahasiswaList = [];
    for (const uid of mahasiswaIds) {
      const userDoc = await db.collection('users').doc(uid).get();
      if (userDoc.exists) mahasiswaList.push({ id: uid, nama: userDoc.data().nama, nim: userDoc.data().nim });
    }
    mahasiswaList.sort((a, b) => a.nim.localeCompare(b.nim));

    let tugasList = [];
    try {
      const periodeAktif = getPeriodeAktif();
      let tugasSnapshot;
      try {
        tugasSnapshot = await db.collection('tugas').where('mkId', '==', mkId).where('periode', '==', periodeAktif).orderBy('deadline', 'asc').get();
      } catch (indexError) {
        console.error('Index tugas belum siap, fallback:', indexError.message);
        tugasSnapshot = await db.collection('tugas').where('mkId', '==', mkId).get();
      }
      if (tugasSnapshot.empty) {
        const semuaSnapshot = await db.collection('tugas').where('mkId', '==', mkId).get();
        const perluDitandai = semuaSnapshot.docs.filter(doc => !doc.data().periode);
        if (perluDitandai.length > 0) {
          await Promise.all(perluDitandai.map(doc => doc.ref.update({ periode: periodeAktif }).catch(() => {})));
        }
        tugasSnapshot = semuaSnapshot;
      }
      tugasList = tugasSnapshot.docs
        .filter(doc => (doc.data().periode || periodeAktif) === periodeAktif) // data lama tanpa periode dianggap periode aktif
        .sort((a, b) => (a.data().deadline || '').localeCompare(b.data().deadline || ''))
        .map(doc => ({ id: doc.id, judul: doc.data().judul, deadline: doc.data().deadline, tipe: doc.data().tipe }));
    } catch (err) { console.error('Gagal ambil tugas:', err.message); }

    // RPS per periode (dropdown)
    const periodeOptions = academicHelper.generatePeriodeOptions();
    const activePeriodeId = academicHelper.getActivePeriodeId();
    const selectedPeriodeId = req.query.periode || activePeriodeId;
    const rpsSelected = await getRpsUntukPeriode(mk.id, selectedPeriodeId, mk.rpsUrl);
    const rpsHistori = await getRiwayatRps(mk.id);

    res.render('dosen/kurikulum/detail', {
      title: `Detail MK - ${mk.kode} ${mk.nama}`,
      mk,
      dosenList,
      pertemuanList,
      infoRencana,
      pertemuanIni,
      pertemuanBerikut,
      terlaksana,
      persentase,
      mahasiswaList,
      tugasList,
      periodeOptions,
      activePeriodeId,
      selectedPeriodeId,
      rpsSelected,
      rpsHistori
    });
  } catch (error) {
    console.error('Error memuat detail MK:', error);
    res.status(500).render('error', { message: 'Gagal memuat detail mata kuliah' });
  }
});

// ============================================================================
// ALIAS GET untuk mendukung URL /dosen/mk/:id/rps (redirect ke halaman detail)
// ============================================================================
router.get('/mk/:id/rps', async (req, res) => {
  res.redirect(`/dosen/kurikulum/${req.params.id}`);
});

module.exports = router;