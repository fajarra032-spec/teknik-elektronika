// ==================== PENGUMUMAN PER KELAS ====================
// Guru/Admin membuat pengumuman untuk kelas tertentu; siswa melihatnya di dashboard.
// Ini fondasi ringan sebelum modul chat real-time di fase mendatang.
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdminOrTeacher } = require('../middleware/auth');
const { notifyManyUsers } = require('../utils/notificationHelper');

const router = express.Router();

async function loadClassAndAuthorize(req, res, next) {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.classId).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };
    const role = req.session.user.role;
    if (role === 'teacher' && cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }
    req.cls = cls;
    req.backUrl = role === 'admin' ? `/admin/classes/${cls.id}` : `/teacher/classes/${cls.id}`;
    next();
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat data kelas: ' + err.message);
  }
}

router.use('/classes/:classId/announcements', isAdminOrTeacher, loadClassAndAuthorize);

router.get('/classes/:classId/announcements', async (req, res) => {
  try {
    const snap = await db.collection('announcements')
      .where('classId', '==', req.params.classId)
      .orderBy('createdAt', 'desc')
      .get();
    const announcements = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    res.render('classes/announcements', {
      cls: req.cls, announcements, backUrl: req.backUrl, role: req.session.user.role,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil pengumuman: ' + err.message);
  }
});

router.post('/classes/:classId/announcements', async (req, res) => {
  const { title, message } = req.body;
  if (!title || !message) {
    return res.redirect(`/classes/${req.params.classId}/announcements?error=` + encodeURIComponent('Judul dan isi pengumuman wajib diisi'));
  }
  try {
    await db.collection('announcements').add({
      classId: req.params.classId,
      title, message,
      createdBy: req.session.user.uid,
      createdByName: req.session.user.name,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    await notifyManyUsers({
      userIds: req.cls.studentIds || [], type: 'announcement',
      title: `Pengumuman: ${title}`,
      message: `${req.cls.name} — ${message}`,
      link: `/user/dashboard`
    });
    res.redirect(`/classes/${req.params.classId}/announcements?success=` + encodeURIComponent('Pengumuman berhasil diposting'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/announcements?error=` + encodeURIComponent(err.message));
  }
});

router.post('/classes/:classId/announcements/:id/delete', async (req, res) => {
  try {
    await db.collection('announcements').doc(req.params.id).delete();
    res.redirect(`/classes/${req.params.classId}/announcements?success=` + encodeURIComponent('Pengumuman dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/announcements?error=` + encodeURIComponent(err.message));
  }
});

module.exports = router;
