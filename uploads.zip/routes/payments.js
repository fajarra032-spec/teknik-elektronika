// ==================== PEMBAYARAN & INVOICE ====================
// Model pembayaran di fase ini bersifat MANUAL (bukan payment gateway online):
// admin membuat tagihan, siswa melihat status tagihannya, admin menandai lunas
// setelah menerima pembayaran (transfer/tunai/dsb). Fondasi ini nanti bisa
// dihubungkan ke payment gateway (Midtrans/Xendit) di fase berikutnya tanpa
// mengubah skema data inti (invoices).
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdmin, isAuthenticated } = require('../middleware/auth');
const { notifyUser } = require('../utils/notificationHelper');

const router = express.Router();

function formatRupiah(num) {
  return 'Rp ' + Math.round(num || 0).toLocaleString('id-ID');
}

// Hitung status efektif: kalau belum lunas & sudah lewat jatuh tempo -> overdue
function effectiveStatus(inv) {
  if (inv.status === 'paid') return 'paid';
  if (inv.dueDate && new Date(inv.dueDate) < new Date()) return 'overdue';
  return 'unpaid';
}

// ============ ADMIN: LIST & KELOLA SEMUA INVOICE ============
router.get('/admin/payments', isAdmin, async (req, res) => {
  try {
    const snap = await db.collection('invoices').orderBy('createdAt', 'desc').get();
    const invoices = snap.docs.map(d => {
      const inv = { id: d.id, ...d.data() };
      inv.effectiveStatus = effectiveStatus(inv);
      return inv;
    });

    const totalRevenue = invoices.filter(i => i.effectiveStatus === 'paid').reduce((s, i) => s + (i.amount || 0), 0);
    const totalOutstanding = invoices.filter(i => i.effectiveStatus !== 'paid').reduce((s, i) => s + (i.amount || 0), 0);
    const totalOverdue = invoices.filter(i => i.effectiveStatus === 'overdue').length;

    const studentsSnap = await db.collection('users').where('role', '==', 'user').where('status', '==', 'active').get();
    const students = studentsSnap.docs.map(d => ({ id: d.id, ...d.data() }));

    res.render('admin/payments', {
      invoices, students, totalRevenue, totalOutstanding, totalOverdue,
      formatRupiah,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil data tagihan: ' + err.message);
  }
});

// ============ ADMIN: BUAT INVOICE BARU ============
router.post('/admin/payments', isAdmin, async (req, res) => {
  const { studentId, description, amount, dueDate } = req.body;
  if (!studentId || !description || !amount || !dueDate) {
    return res.redirect('/admin/payments?error=' + encodeURIComponent('Semua field wajib diisi'));
  }
  try {
    const studentDoc = await db.collection('users').doc(studentId).get();
    if (!studentDoc.exists) return res.redirect('/admin/payments?error=' + encodeURIComponent('Siswa tidak ditemukan'));

    const countSnap = await db.collection('invoices').get();
    const invoiceNumber = 'INV-' + String(countSnap.size + 1).padStart(5, '0');

    await db.collection('invoices').add({
      invoiceNumber,
      studentId,
      studentName: studentDoc.data().name,
      description, amount: Number(amount), dueDate,
      status: 'unpaid',
      paidAt: null,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    await notifyUser({
      userId: studentId, type: 'invoice',
      title: 'Tagihan Baru',
      message: `${description} — Rp ${Number(amount).toLocaleString('id-ID')}, jatuh tempo ${dueDate}`,
      link: '/user/dashboard'
    });
    res.redirect('/admin/payments?success=' + encodeURIComponent('Tagihan berhasil dibuat: ' + invoiceNumber));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/payments?error=' + encodeURIComponent(err.message));
  }
});

// ============ ADMIN: TANDAI LUNAS ============
router.post('/admin/payments/:id/mark-paid', isAdmin, async (req, res) => {
  try {
    await db.collection('invoices').doc(req.params.id).update({
      status: 'paid',
      paidAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.redirect('/admin/payments?success=' + encodeURIComponent('Tagihan ditandai lunas'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/payments?error=' + encodeURIComponent(err.message));
  }
});

// ============ ADMIN: BATALKAN STATUS LUNAS (kalau salah klik) ============
router.post('/admin/payments/:id/mark-unpaid', isAdmin, async (req, res) => {
  try {
    await db.collection('invoices').doc(req.params.id).update({ status: 'unpaid', paidAt: null });
    res.redirect('/admin/payments?success=' + encodeURIComponent('Status tagihan dikembalikan ke belum lunas'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/payments?error=' + encodeURIComponent(err.message));
  }
});

// ============ ADMIN: HAPUS INVOICE ============
router.post('/admin/payments/:id/delete', isAdmin, async (req, res) => {
  try {
    await db.collection('invoices').doc(req.params.id).delete();
    res.redirect('/admin/payments?success=' + encodeURIComponent('Tagihan dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/payments?error=' + encodeURIComponent(err.message));
  }
});

// ============ LIHAT/CETAK 1 INVOICE (admin ATAU siswa pemilik invoice) ============
router.get('/invoices/:id', isAuthenticated, async (req, res) => {
  try {
    const invDoc = await db.collection('invoices').doc(req.params.id).get();
    if (!invDoc.exists) return res.status(404).send('Tagihan tidak ditemukan');
    const invoice = { id: invDoc.id, ...invDoc.data() };
    invoice.effectiveStatus = effectiveStatus(invoice);

    const role = req.session.user.role;
    if (role !== 'admin' && invoice.studentId !== req.session.user.uid) {
      return res.status(403).send('Anda tidak berhak melihat tagihan ini');
    }

    res.render('invoice-detail', { invoice, formatRupiah, role });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil tagihan: ' + err.message);
  }
});

module.exports = router;
