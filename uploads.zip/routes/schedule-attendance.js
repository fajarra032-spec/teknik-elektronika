// ==================== JADWAL (PERTEMUAN) & ABSENSI PER KELAS ====================
// Router ini dipakai BERSAMA oleh Admin dan Guru (guru hanya untuk kelas yang ia ampu).
// Dipasang di path /classes/:classId/sessions supaya tidak bentrok dengan:
//   /admin/classes/:id  (kelola kelas oleh admin)
//   /teacher/classes/:id (lihat kelas oleh guru)
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdminOrTeacher } = require('../middleware/auth');

const router = express.Router();

const STATUS_LABELS = { hadir: 'Hadir', izin: 'Izin', sakit: 'Sakit', alpa: 'Alpa' };

// Pastikan user (admin ATAU guru pengampu kelas ini) berhak akses, lalu lampirkan
// data kelas + siswa + backUrl (tujuan tombol "kembali", beda untuk admin/guru) ke req.
async function loadClassAndAuthorize(req, res, next) {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.classId).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };

    const role = req.session.user.role;
    if (role === 'teacher' && cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }

    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }

    req.cls = cls;
    req.classStudents = students;
    req.backUrl = role === 'admin' ? `/admin/classes/${cls.id}` : `/teacher/classes/${cls.id}`;
    next();
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat data kelas: ' + err.message);
  }
}

router.use('/classes/:classId/sessions', isAdminOrTeacher, loadClassAndAuthorize);

// LIST jadwal/pertemuan sebuah kelas
router.get('/classes/:classId/sessions', async (req, res) => {
  try {
    const snap = await db.collection('class_sessions')
      .where('classId', '==', req.params.classId)
      .orderBy('meetingNumber', 'asc')
      .get();
    const sessions = snap.docs.map(d => {
      const s = { id: d.id, ...d.data() };
      const values = Object.values(s.attendance || {});
      s.hadirCount = values.filter(a => a.status === 'hadir').length;
      s.totalRecorded = values.length;
      return s;
    });
    res.render('classes/sessions', {
      cls: req.cls, sessions, backUrl: req.backUrl, role: req.session.user.role,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil jadwal: ' + err.message);
  }
});

// TAMBAH pertemuan baru (jadwal)
router.post('/classes/:classId/sessions', async (req, res) => {
  const { date, topic, notes } = req.body;
  if (!date) {
    return res.redirect(`/classes/${req.params.classId}/sessions?error=` + encodeURIComponent('Tanggal wajib diisi'));
  }
  try {
    const countSnap = await db.collection('class_sessions').where('classId', '==', req.params.classId).get();
    await db.collection('class_sessions').add({
      classId: req.params.classId,
      meetingNumber: countSnap.size + 1,
      date, topic: topic || '', notes: notes || '',
      status: 'terjadwal',
      attendance: {},
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.redirect(`/classes/${req.params.classId}/sessions?success=` + encodeURIComponent('Pertemuan baru ditambahkan ke jadwal'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/sessions?error=` + encodeURIComponent(err.message));
  }
});

// REKAP kehadiran seluruh siswa di kelas ini (harus didaftar SEBELUM /:sessionId agar tidak ketangkap sebagai id)
router.get('/classes/:classId/sessions/recap', async (req, res) => {
  try {
    const snap = await db.collection('class_sessions')
      .where('classId', '==', req.params.classId)
      .orderBy('meetingNumber', 'asc')
      .get();
    const sessions = snap.docs.map(d => ({ id: d.id, ...d.data() }));

    const recap = req.classStudents.map(s => {
      let hadir = 0, izin = 0, sakit = 0, alpa = 0, tercatat = 0;
      const perSesi = sessions.map(sess => {
        const rec = (sess.attendance || {})[s.id];
        if (rec) {
          tercatat++;
          if (rec.status === 'hadir') hadir++;
          else if (rec.status === 'izin') izin++;
          else if (rec.status === 'sakit') sakit++;
          else if (rec.status === 'alpa') alpa++;
        }
        return rec ? rec.status : null;
      });
      const percentage = tercatat === 0 ? 0 : Math.round((hadir / tercatat) * 100);
      return { student: s, perSesi, hadir, izin, sakit, alpa, tercatat, percentage };
    });

    res.render('classes/recap', {
      cls: req.cls, sessions, recap, backUrl: req.backUrl, statusLabels: STATUS_LABELS, role: req.session.user.role
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal membuat rekap absensi: ' + err.message);
  }
});

// DETAIL pertemuan + form isi absensi
router.get('/classes/:classId/sessions/:sessionId', async (req, res) => {
  try {
    const sessDoc = await db.collection('class_sessions').doc(req.params.sessionId).get();
    if (!sessDoc.exists || sessDoc.data().classId !== req.params.classId) {
      return res.status(404).send('Pertemuan tidak ditemukan');
    }
    const sessionData = { id: sessDoc.id, ...sessDoc.data() };
    res.render('classes/session-detail', {
      cls: req.cls, session: sessionData, students: req.classStudents, backUrl: req.backUrl, role: req.session.user.role,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil detail pertemuan: ' + err.message);
  }
});

// UPDATE info pertemuan (tanggal/topik/catatan)
router.post('/classes/:classId/sessions/:sessionId/update', async (req, res) => {
  const { date, topic, notes } = req.body;
  try {
    await db.collection('class_sessions').doc(req.params.sessionId).update({
      date, topic: topic || '', notes: notes || ''
    });
    res.redirect(`/classes/${req.params.classId}/sessions/${req.params.sessionId}?success=` + encodeURIComponent('Info pertemuan diperbarui'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/sessions/${req.params.sessionId}?error=` + encodeURIComponent(err.message));
  }
});

// SIMPAN absensi (bulk, untuk semua siswa sekaligus)
router.post('/classes/:classId/sessions/:sessionId/attendance', async (req, res) => {
  try {
    const attendance = {};
    for (const student of req.classStudents) {
      const status = req.body[`status_${student.id}`] || 'alpa';
      const note = req.body[`note_${student.id}`] || '';
      attendance[student.id] = { status, note };
    }
    await db.collection('class_sessions').doc(req.params.sessionId).update({
      attendance, status: 'selesai',
      recordedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.redirect(`/classes/${req.params.classId}/sessions/${req.params.sessionId}?success=` + encodeURIComponent('Absensi berhasil disimpan'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/sessions/${req.params.sessionId}?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS pertemuan
router.post('/classes/:classId/sessions/:sessionId/delete', async (req, res) => {
  try {
    await db.collection('class_sessions').doc(req.params.sessionId).delete();
    res.redirect(`/classes/${req.params.classId}/sessions?success=` + encodeURIComponent('Pertemuan dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/sessions?error=` + encodeURIComponent(err.message));
  }
});

module.exports = router;
