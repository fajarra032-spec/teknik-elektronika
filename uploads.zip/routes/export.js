// ==================== EXPORT EXCEL/PDF (v2.0 - basic) ====================
// Versi dasar: export data yang paling sering dibutuhkan sekolah untuk laporan
// offline (rapat, arsip, dikirim ke yayasan, dll) — siswa, enrollment, absensi,
// dan nilai per kelas. Excel pakai ExcelJS, PDF pakai PDFKit (keduanya pure-JS,
// tidak butuh binary tambahan di server).
const express = require('express');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { db } = require('../config/firebase');
const { isAdmin, isAdminOrTeacher } = require('../middleware/auth');
const { getGradeClassification } = require('../utils/helpers');

const router = express.Router();

const STATUS_LABELS = { hadir: 'Hadir', izin: 'Izin', sakit: 'Sakit', alpa: 'Alpa' };

// Style header kolom, dipakai berulang supaya semua sheet konsisten
function styleHeaderRow(row) {
  row.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  row.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE2604F' } };
  row.alignment = { vertical: 'middle', horizontal: 'center' };
}

async function loadClassAndAuthorize(req, res, next) {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.classId).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };
    const role = req.session.user.role;
    if (role === 'teacher' && cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }
    req.cls = cls;
    next();
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal memuat data kelas: ' + err.message);
  }
}

// ==================== 1. EXPORT SISWA (Excel) ====================
router.get('/export/siswa', isAdmin, async (req, res) => {
  try {
    const snap = await db.collection('users').where('role', '==', 'user').get();
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Merah Putih ILS';
    const sheet = workbook.addWorksheet('Siswa');

    sheet.columns = [
      { header: 'Nama', key: 'name', width: 26 },
      { header: 'Email', key: 'email', width: 28 },
      { header: 'No. HP', key: 'phone', width: 16 },
      { header: 'Alamat', key: 'address', width: 32 },
      { header: 'Nama Orang Tua/Wali', key: 'parentName', width: 24 },
      { header: 'No. HP Orang Tua', key: 'parentPhone', width: 18 },
      { header: 'Status', key: 'status', width: 12 },
    ];
    styleHeaderRow(sheet.getRow(1));

    snap.docs.forEach(d => {
      const u = d.data();
      sheet.addRow({
        name: u.name || '-', email: u.email || '-', phone: u.phone || '-',
        address: u.address || '-', parentName: u.parentName || '-',
        parentPhone: u.parentPhone || '-', status: u.status || '-'
      });
    });
    sheet.eachRow(row => { row.alignment = { ...row.alignment, wrapText: true, vertical: 'top' }; });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="daftar-siswa.xlsx"');
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal membuat file Excel: ' + err.message);
  }
});

// ==================== 2. EXPORT ENROLLMENT (Excel) ====================
router.get('/admin/export/enrollments', isAdmin, async (req, res) => {
  try {
    const snap = await db.collection('enrollments').orderBy('enrolledAt', 'desc').get();
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Enrollment');
    sheet.columns = [
      { header: 'Nama Siswa', key: 'name', width: 26 },
      { header: 'Program', key: 'program', width: 26 },
      { header: 'Tanggal Mulai', key: 'startDate', width: 16 },
      { header: 'Nilai Akhir', key: 'score', width: 12 },
      { header: 'Status', key: 'status', width: 14 },
      { header: 'Sertifikat', key: 'cert', width: 14 },
    ];
    styleHeaderRow(sheet.getRow(1));

    for (const doc of snap.docs) {
      const enr = doc.data();
      const userDoc = await db.collection('users').doc(enr.userId).get();
      const progDoc = await db.collection('programs').doc(enr.programId).get();
      sheet.addRow({
        name: userDoc.exists ? userDoc.data().name : '(dihapus)',
        program: progDoc.exists ? progDoc.data().name : '(dihapus)',
        startDate: enr.startDate ? new Date(enr.startDate).toLocaleDateString('id-ID') : '-',
        score: enr.overallScore || 0,
        status: enr.status || 'active',
        cert: enr.certificateId ? 'Sudah terbit' : 'Belum terbit'
      });
    }

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="daftar-enrollment.xlsx"');
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal membuat file Excel: ' + err.message);
  }
});

// ==================== 3. EXPORT ABSENSI PER KELAS (Excel) ====================
router.get('/classes/:classId/export/absensi', isAdminOrTeacher, loadClassAndAuthorize, async (req, res) => {
  try {
    const cls = req.cls;
    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }
    const sessSnap = await db.collection('class_sessions').where('classId', '==', cls.id).orderBy('meetingNumber', 'asc').get();
    const sessions = sessSnap.docs.map(d => ({ id: d.id, ...d.data() }));

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Absensi');

    const columns = [{ header: 'Nama Siswa', key: 'name', width: 26 }];
    sessions.forEach(s => columns.push({ header: `P${s.meetingNumber} (${s.date})`, key: `p${s.meetingNumber}`, width: 16 }));
    columns.push({ header: '% Hadir', key: 'percentage', width: 12 });
    sheet.columns = columns;
    styleHeaderRow(sheet.getRow(1));

    students.forEach(s => {
      const row = { name: s.name };
      let hadir = 0, tercatat = 0;
      sessions.forEach(sess => {
        const rec = (sess.attendance || {})[s.id];
        row[`p${sess.meetingNumber}`] = rec ? STATUS_LABELS[rec.status] : '-';
        if (rec) { tercatat++; if (rec.status === 'hadir') hadir++; }
      });
      row.percentage = tercatat === 0 ? 0 : Math.round((hadir / tercatat) * 100);
      sheet.addRow(row);
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="absensi-${cls.name.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx"`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal membuat file Excel: ' + err.message);
  }
});

// ==================== 4. EXPORT NILAI AKHIR PER KELAS (Excel) ====================
router.get('/classes/:classId/export/nilai', isAdminOrTeacher, loadClassAndAuthorize, async (req, res) => {
  try {
    const cls = req.cls;
    const components = cls.gradeComponents || [];
    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }
    const gradesDoc = await db.collection('class_final_grades').doc(cls.id).get();
    const gradesMap = gradesDoc.exists ? (gradesDoc.data().grades || {}) : {};

    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Nilai Akhir');

    const columns = [{ header: 'Nama Siswa', key: 'name', width: 26 }];
    components.forEach(c => columns.push({ header: `${c.name} (${c.weight}%)`, key: c.id, width: 18 }));
    columns.push({ header: 'Nilai Akhir', key: 'final', width: 14 }, { header: 'Grade', key: 'grade', width: 10 });
    sheet.columns = columns;
    styleHeaderRow(sheet.getRow(1));

    students.forEach(s => {
      const scores = gradesMap[s.id] || {};
      const row = { name: s.name };
      let weightedSum = 0, totalWeight = 0;
      components.forEach(c => {
        const val = scores[c.id];
        row[c.id] = val !== undefined ? val : '-';
        if (val !== undefined && val !== null && val !== '') {
          weightedSum += Number(val) * Number(c.weight);
          totalWeight += Number(c.weight);
        }
      });
      const finalScore = totalWeight === 0 ? null : Math.round(weightedSum / totalWeight);
      row.final = finalScore !== null ? finalScore : '-';
      row.grade = finalScore !== null ? getGradeClassification(finalScore).grade : '-';
      sheet.addRow(row);
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="nilai-${cls.name.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx"`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal membuat file Excel: ' + err.message);
  }
});

// ==================== 5. LAPORAN KELAS (PDF) ====================
// Satu halaman ringkas: info kelas + rata-rata kehadiran + rata-rata nilai akhir.
router.get('/classes/:classId/export/laporan-pdf', isAdminOrTeacher, loadClassAndAuthorize, async (req, res) => {
  try {
    const cls = req.cls;
    const programDoc = await db.collection('programs').doc(cls.programId).get();
    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }
    const sessSnap = await db.collection('class_sessions').where('classId', '==', cls.id).orderBy('meetingNumber', 'asc').get();
    const sessions = sessSnap.docs.map(d => d.data());
    const gradesDoc = await db.collection('class_final_grades').doc(cls.id).get();
    const gradesMap = gradesDoc.exists ? (gradesDoc.data().grades || {}) : {};
    const components = cls.gradeComponents || [];

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="laporan-${cls.name.replace(/[^a-zA-Z0-9]/g, '_')}.pdf"`);

    const doc = new PDFDocument({ margin: 45, size: 'A4' });
    doc.pipe(res);

    doc.fontSize(18).fillColor('#E2604F').text('Laporan Kelas', { align: 'center' });
    doc.moveDown(0.3);
    doc.fontSize(11).fillColor('#3A2A22').text('Merah Putih International Language School', { align: 'center' });
    doc.moveDown(1.2);

    doc.fontSize(13).fillColor('#3A2A22').text(cls.name, { underline: true });
    doc.moveDown(0.4);
    doc.fontSize(10).fillColor('#3A2A22');
    doc.text(`Program: ${programDoc.exists ? programDoc.data().name : '-'}`);
    doc.text(`Level: ${cls.level || '-'}`);
    doc.text(`Jadwal: ${cls.schedule || 'Belum diatur'}`);
    doc.text(`Jumlah Siswa: ${students.length}`);
    doc.text(`Jumlah Pertemuan Tercatat: ${sessions.length}`);
    doc.moveDown(1);

    doc.fontSize(12).fillColor('#E2604F').text('Ringkasan per Siswa');
    doc.moveDown(0.4);

    students.forEach((s, idx) => {
      let hadir = 0, tercatat = 0;
      sessions.forEach(sess => {
        const rec = (sess.attendance || {})[s.id];
        if (rec) { tercatat++; if (rec.status === 'hadir') hadir++; }
      });
      const attendancePct = tercatat === 0 ? '-' : Math.round((hadir / tercatat) * 100) + '%';

      const scores = gradesMap[s.id] || {};
      let weightedSum = 0, totalWeight = 0;
      components.forEach(c => {
        const val = scores[c.id];
        if (val !== undefined && val !== null && val !== '') {
          weightedSum += Number(val) * Number(c.weight);
          totalWeight += Number(c.weight);
        }
      });
      const finalScore = totalWeight === 0 ? '-' : Math.round(weightedSum / totalWeight);

      doc.fontSize(10).fillColor('#3A2A22')
        .text(`${idx + 1}. ${s.name}  —  Kehadiran: ${attendancePct}   Nilai Akhir: ${finalScore}`);
    });

    doc.moveDown(1.5);
    doc.fontSize(8).fillColor('#96887A')
      .text(`Dicetak otomatis oleh sistem pada ${new Date().toLocaleString('id-ID')}`, { align: 'center' });

    doc.end();
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal membuat laporan PDF: ' + err.message);
  }
});

module.exports = router;
