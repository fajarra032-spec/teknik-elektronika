// ==================== NILAI AKHIR (KOMPONEN & BOBOT) PER KELAS ====================
// Beda dengan "Rekap Nilai (Gradebook)" yang otomatis dari Tugas/Quiz/CBT —
// fitur ini untuk topik penilaian BEBAS yang didefinisikan sendiri oleh
// admin/guru (misal: Kehadiran 10%, Sikap 10%, UTS 30%, UAS 50%), nilai diisi
// manual, lalu dihitung otomatis jadi satu Nilai Akhir berbobot per siswa.
// Nilai Akhir ini yang bisa diterapkan langsung jadi overallScore di Enrollment
// dan menerbitkan sertifikat (menggantikan skema lama per-materi kalau dipakai).
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdmin, isAdminOrTeacher } = require('../middleware/auth');
const { generateShortId, getGradeClassification } = require('../utils/helpers');
const { issueCertificate } = require('../utils/certificateHelper');
const { notifyUser } = require('../utils/notificationHelper');

const router = express.Router();

// Hitung nilai akhir berbobot dari { componentId: score } dan daftar komponen.
// Dinormalisasi terhadap total bobot komponen yang ADA NILAINYA saja — supaya
// tetap bisa dihitung meski belum semua komponen diisi (ditandai "belum lengkap").
function computeWeightedScore(componentScores, components) {
  let weightedSum = 0, totalWeight = 0, filledCount = 0;
  components.forEach(comp => {
    const score = componentScores ? componentScores[comp.id] : undefined;
    if (score !== undefined && score !== null && score !== '') {
      weightedSum += Number(score) * Number(comp.weight);
      totalWeight += Number(comp.weight);
      filledCount++;
    }
  });
  const isComplete = filledCount === components.length && components.length > 0;
  const finalScore = totalWeight === 0 ? null : Math.round(weightedSum / totalWeight);
  return { finalScore, isComplete, filledCount };
}

async function loadClassAndAuthorize(req, res, next) {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.classId).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };

    const role = req.session.user.role;
    if (role === 'teacher' && cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }

    req.cls = cls;
    req.backUrl = role === 'admin' ? `/admin/classes/${cls.id}` : `/teacher/classes/${cls.id}`;
    next();
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat data kelas: ' + err.message);
  }
}

router.use('/classes/:classId/final-grades', isAdminOrTeacher, loadClassAndAuthorize);

// ==================== HALAMAN UTAMA: KOMPONEN + MATRIX NILAI ====================
router.get('/classes/:classId/final-grades', async (req, res) => {
  try {
    const cls = req.cls;
    const components = cls.gradeComponents || [];
    const totalWeight = components.reduce((s, c) => s + Number(c.weight), 0);

    const progDoc = await db.collection('programs').doc(cls.programId).get();
    const passingScore = progDoc.exists ? (progDoc.data().passingScore || 70) : 70;

    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }

    const gradesDoc = await db.collection('class_final_grades').doc(cls.id).get();
    const gradesMap = gradesDoc.exists ? (gradesDoc.data().grades || {}) : {};

    // Cari enrollment tiap siswa untuk program kelas ini, untuk tampilkan status
    // sertifikat & overallScore yang sedang berlaku sekarang.
    const enrollSnap = await db.collection('enrollments').where('programId', '==', cls.programId).get();
    const enrollByUser = {};
    enrollSnap.docs.forEach(d => { enrollByUser[d.data().userId] = { id: d.id, ...d.data() }; });

    const rows = students.map(s => {
      const scores = gradesMap[s.id] || {};
      const { finalScore, isComplete, filledCount } = computeWeightedScore(scores, components);
      const enrollment = enrollByUser[s.id] || null;
      const gradeInfo = finalScore !== null ? getGradeClassification(finalScore) : null;
      return { student: s, scores, finalScore, isComplete, filledCount, enrollment, gradeInfo };
    });

    res.render('classes/final-grades', {
      cls, components, totalWeight, rows, role: req.session.user.role, backUrl: req.backUrl, passingScore,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat nilai akhir: ' + err.message);
  }
});

// ==================== KELOLA KOMPONEN PENILAIAN ====================
// Tambah/hapus TOPIK penilaian (komponen & bobot) — KHUSUS ADMIN. Guru bisa
// mengisi nilai untuk topik yang sudah ada (lihat route /save & /apply di bawah),
// tapi tidak menentukan sendiri topik & bobotnya, supaya standar penilaian tetap
// seragam & terkontrol dari admin.
router.post('/classes/:classId/final-grades/components', isAdmin, async (req, res) => {
  const { name, weight } = req.body;
  if (!name || !weight) {
    return res.redirect(`/classes/${req.params.classId}/final-grades?error=` + encodeURIComponent('Nama topik dan bobot wajib diisi'));
  }
  try {
    const components = req.cls.gradeComponents || [];
    components.push({ id: generateShortId('comp'), name, weight: Number(weight) });
    await db.collection('classes').doc(req.params.classId).update({ gradeComponents: components });
    res.redirect(`/classes/${req.params.classId}/final-grades?success=` + encodeURIComponent('Topik penilaian ditambahkan'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/final-grades?error=` + encodeURIComponent(err.message));
  }
});

router.post('/classes/:classId/final-grades/components/:componentId/delete', isAdmin, async (req, res) => {
  try {
    const components = (req.cls.gradeComponents || []).filter(c => c.id !== req.params.componentId);
    await db.collection('classes').doc(req.params.classId).update({ gradeComponents: components });
    res.redirect(`/classes/${req.params.classId}/final-grades?success=` + encodeURIComponent('Topik penilaian dihapus (nilai yang sudah diisi untuk topik ini diabaikan dari perhitungan)'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/final-grades?error=` + encodeURIComponent(err.message));
  }
});

// ==================== SIMPAN NILAI (BULK, SEMUA SISWA x KOMPONEN SEKALIGUS) ====================
router.post('/classes/:classId/final-grades/save', async (req, res) => {
  try {
    const cls = req.cls;
    const components = cls.gradeComponents || [];
    const studentIds = cls.studentIds || [];

    const gradesRef = db.collection('class_final_grades').doc(cls.id);
    const gradesDoc = await gradesRef.get();
    const gradesMap = gradesDoc.exists ? (gradesDoc.data().grades || {}) : {};

    studentIds.forEach(sid => {
      if (!gradesMap[sid]) gradesMap[sid] = {};
      components.forEach(comp => {
        const fieldName = `score_${sid}_${comp.id}`;
        const val = req.body[fieldName];
        if (val !== undefined && val !== '') {
          gradesMap[sid][comp.id] = Number(val);
        }
      });
    });

    await gradesRef.set({ classId: cls.id, grades: gradesMap, updatedAt: admin.firestore.FieldValue.serverTimestamp() });
    res.redirect(`/classes/${cls.id}/final-grades?success=` + encodeURIComponent('Nilai berhasil disimpan'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/final-grades?error=` + encodeURIComponent(err.message));
  }
});

// ==================== TERAPKAN NILAI AKHIR SATU SISWA KE ENROLLMENT + SERTIFIKAT ====================
router.post('/classes/:classId/final-grades/:studentId/apply', async (req, res) => {
  try {
    const cls = req.cls;
    const components = cls.gradeComponents || [];
    if (components.length === 0) {
      return res.redirect(`/classes/${cls.id}/final-grades?error=` + encodeURIComponent('Belum ada topik penilaian dibuat'));
    }

    const gradesDoc = await db.collection('class_final_grades').doc(cls.id).get();
    const gradesMap = gradesDoc.exists ? (gradesDoc.data().grades || {}) : {};
    const scores = gradesMap[req.params.studentId] || {};
    const { finalScore, isComplete } = computeWeightedScore(scores, components);

    if (!isComplete || finalScore === null) {
      return res.redirect(`/classes/${cls.id}/final-grades?error=` + encodeURIComponent('Nilai siswa ini belum lengkap di semua topik — lengkapi dulu sebelum diterapkan'));
    }

    const enrollSnap = await db.collection('enrollments')
      .where('programId', '==', cls.programId).where('userId', '==', req.params.studentId).limit(1).get();
    if (enrollSnap.empty) {
      return res.redirect(`/classes/${cls.id}/final-grades?error=` + encodeURIComponent('Siswa ini belum punya Akun Siswa untuk program kelas ini — buat dulu di menu Akun Siswa'));
    }
    const enrollDoc = enrollSnap.docs[0];
    const enrollment = enrollDoc.data();

    const progDoc = await db.collection('programs').doc(cls.programId).get();
    const passingScore = progDoc.exists ? (progDoc.data().passingScore || 70) : 70;

    if (enrollment.certificateId) {
      // Sudah pernah terbit sertifikat sebelumnya — cukup update nilainya saja,
      // TIDAK menerbitkan sertifikat baru/duplikat.
      await db.collection('enrollments').doc(enrollDoc.id).update({ overallScore: finalScore });
      await notifyUser({
        userId: req.params.studentId, type: 'grade',
        title: 'Nilai Akhir Diperbarui',
        message: `Nilai akhir kelas ${cls.name} diperbarui: ${finalScore}`,
        link: '/user/dashboard'
      });
      return res.redirect(`/classes/${cls.id}/final-grades?success=` + encodeURIComponent('Nilai akhir diperbarui (sertifikat yang sudah terbit sebelumnya tidak diterbitkan ulang)'));
    }

    if (finalScore < passingScore) {
      // Nilai tetap disimpan supaya siswa/guru bisa lihat, tapi sertifikat
      // TIDAK diterbitkan karena belum mencapai nilai minimum kelulusan program.
      await db.collection('enrollments').doc(enrollDoc.id).update({ overallScore: finalScore });
      return res.redirect(`/classes/${cls.id}/final-grades?error=` + encodeURIComponent(
        `Nilai akhir (${finalScore}) belum mencapai nilai minimum kelulusan program ini (${passingScore}). Nilai tetap tersimpan, tapi sertifikat belum diterbitkan.`
      ));
    }

    await issueCertificate({
      db, enrollmentId: enrollDoc.id, userId: req.params.studentId, overallScore: finalScore,
      breakdown: components.map(c => ({ label: c.name, weight: c.weight, score: scores[c.id] ?? null }))
    });
    await notifyUser({
      userId: req.params.studentId, type: 'grade',
      title: 'Sertifikat Terbit!',
      message: `Selamat! Nilai akhir kelas ${cls.name}: ${finalScore}. Sertifikat kelulusan sudah bisa dilihat.`,
      link: '/user/dashboard'
    });
    res.redirect(`/classes/${cls.id}/final-grades?success=` + encodeURIComponent('Nilai akhir diterapkan & sertifikat berhasil diterbitkan'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/final-grades?error=` + encodeURIComponent(err.message));
  }
});

module.exports = router;
