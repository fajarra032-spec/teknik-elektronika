// ==================== NOTIFIKASI (lonceng in-app) ====================
// Mencakup 2 sumber:
// 1. Koleksi `notifications` — dipicu server (Admin SDK) saat ada event:
//    nilai baru, tagihan baru, pengumuman baru (lihat utils/notificationHelper.js
//    dan titik pemicunya di routes/assignments.js, final-grades.js, payments.js,
//    announcements.js, student-assignments.js).
// 2. Chat belum dibaca — DIHITUNG LANGSUNG dari koleksi `conversations`
//    (bandingkan lastMessageAt vs readBy.{uid}), bukan disimpan sebagai
//    notifikasi terpisah, supaya tidak dobel-catat dengan halaman Chat sendiri.
const express = require('express');
const { db } = require('../config/firebase');
const { isAuthenticated } = require('../middleware/auth');

const router = express.Router();

async function countUnreadChat(uid, role) {
  let query;
  if (role === 'user') query = db.collection('conversations').where('studentId', '==', uid);
  else if (role === 'teacher') query = db.collection('conversations').where('teacherId', '==', uid);
  else query = db.collection('conversations').where('type', '==', 'admin_student');

  const snap = await query.get();
  let count = 0;
  snap.forEach(doc => {
    const c = doc.data();
    if (!c.lastMessageAt || c.lastSenderId === uid) return; // tidak ada pesan, atau pesan terakhir dari diri sendiri
    const readAt = c.readBy ? c.readBy[uid] : null;
    if (!readAt || c.lastMessageAt.toMillis() > readAt.toMillis()) count++;
  });
  return count;
}

// ==================== API ringkasan untuk lonceng (dipoll berkala oleh frontend) ====================
router.get('/api/notifications/summary', isAuthenticated, async (req, res) => {
  try {
    const { uid, role } = req.session.user;
    const snap = await db.collection('notifications')
      .where('userId', '==', uid).where('isRead', '==', false)
      .orderBy('createdAt', 'desc').limit(10).get();
    const items = snap.docs.map(d => {
      const n = d.data();
      return {
        id: d.id, type: n.type, title: n.title, message: n.message, link: n.link,
        createdAt: n.createdAt && n.createdAt.toDate ? n.createdAt.toDate().toISOString() : null
      };
    });
    const unreadChatCount = await countUnreadChat(uid, role);

    res.json({ items, unreadCount: items.length, unreadChatCount, totalBadge: items.length + unreadChatCount });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

router.post('/api/notifications/:id/read', isAuthenticated, async (req, res) => {
  try {
    const doc = await db.collection('notifications').doc(req.params.id).get();
    if (doc.exists && doc.data().userId === req.session.user.uid) {
      await doc.ref.update({ isRead: true });
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/api/notifications/read-all', isAuthenticated, async (req, res) => {
  try {
    const snap = await db.collection('notifications')
      .where('userId', '==', req.session.user.uid).where('isRead', '==', false).get();
    const batch = db.batch();
    snap.forEach(doc => batch.update(doc.ref, { isRead: true }));
    await batch.commit();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== HALAMAN DAFTAR NOTIFIKASI LENGKAP ====================
router.get('/notifications', isAuthenticated, async (req, res) => {
  try {
    const snap = await db.collection('notifications')
      .where('userId', '==', req.session.user.uid)
      .orderBy('createdAt', 'desc').limit(50).get();
    const notifications = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    const role = req.session.user.role;
    res.render('notifications', {
      user: req.session.user, notifications,
      dashboardUrl: role === 'admin' ? '/admin/dashboard' : role === 'teacher' ? '/teacher/dashboard' : '/user/dashboard'
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat notifikasi: ' + err.message);
  }
});

module.exports = router;
