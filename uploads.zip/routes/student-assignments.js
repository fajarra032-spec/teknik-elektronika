// ==================== SISWA: KERJAKAN TUGAS / QUIZ / CBT ====================
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isStudent } = require('../middleware/auth');
const { autoGradeQuiz } = require('../utils/helpers');
const { notifyUser } = require('../utils/notificationHelper');

const router = express.Router();

// LIST semua tugas/quiz/CBT yang published, dari semua kelas yang diikuti siswa ini
router.get('/student/assignments', isStudent, async (req, res) => {
  try {
    const uid = req.session.user.uid;
    const classesSnap = await db.collection('classes').where('studentIds', 'array-contains', uid).get();

    const items = [];
    for (const clsDoc of classesSnap.docs) {
      const cls = { id: clsDoc.id, ...clsDoc.data() };
      const asgSnap = await db.collection('assignments')
        .where('classId', '==', cls.id)
        .where('status', '==', 'published')
        .get();
      for (const aDoc of asgSnap.docs) {
        const a = { id: aDoc.id, ...aDoc.data(), className: cls.name };
        const subDoc = await db.collection('submissions').doc(`${a.id}_${uid}`).get();
        a.submission = subDoc.exists ? subDoc.data() : null;
        items.push(a);
      }
    }
    items.sort((x, y) => (y.createdAt?.toMillis?.() || 0) - (x.createdAt?.toMillis?.() || 0));

    res.render('student/assignments', { user: req.session.user, items });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil daftar tugas: ' + err.message);
  }
});

// DETAIL: kerjakan (kalau belum) atau lihat hasil (kalau sudah dikumpulkan/dinilai)
router.get('/student/assignments/:id', isStudent, async (req, res) => {
  try {
    const uid = req.session.user.uid;
    const aDoc = await db.collection('assignments').doc(req.params.id).get();
    if (!aDoc.exists || aDoc.data().status !== 'published') return res.status(404).send('Tidak ditemukan');
    const assignmentData = { id: aDoc.id, ...aDoc.data() };

    const clsDoc = await db.collection('classes').doc(assignmentData.classId).get();
    if (!clsDoc.exists || !(clsDoc.data().studentIds || []).includes(uid)) {
      return res.status(403).send('Anda tidak terdaftar di kelas ini');
    }
    const cls = { id: clsDoc.id, ...clsDoc.data() };

    let questions = [];
    if (assignmentData.questionIds && assignmentData.questionIds.length > 0) {
      const qDocs = await Promise.all(assignmentData.questionIds.map(qid => db.collection('questions').doc(qid).get()));
      questions = qDocs.filter(d => d.exists).map(d => ({ id: d.id, ...d.data() }));
    }

    const subDoc = await db.collection('submissions').doc(`${assignmentData.id}_${uid}`).get();
    const submission = subDoc.exists ? subDoc.data() : null;

    res.render('student/assignment-take', {
      user: req.session.user, cls, assignment: assignmentData, questions, submission,
      error: req.query.error || null, success: req.query.success || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat soal: ' + err.message);
  }
});

// SUBMIT jawaban
router.post('/student/assignments/:id/submit', isStudent, async (req, res) => {
  const uid = req.session.user.uid;
  try {
    const aDoc = await db.collection('assignments').doc(req.params.id).get();
    if (!aDoc.exists) return res.status(404).send('Tidak ditemukan');
    const assignmentData = { id: aDoc.id, ...aDoc.data() };

    const subRef = db.collection('submissions').doc(`${assignmentData.id}_${uid}`);
    const existing = await subRef.get();
    if (existing.exists) {
      return res.redirect(`/student/assignments/${req.params.id}?error=` + encodeURIComponent('Anda sudah pernah mengumpulkan jawaban ini'));
    }

    if (assignmentData.type === 'tugas') {
      const { essayAnswer } = req.body;
      if (!essayAnswer) {
        return res.redirect(`/student/assignments/${req.params.id}?error=` + encodeURIComponent('Jawaban tidak boleh kosong'));
      }
      await subRef.set({
        assignmentId: assignmentData.id, classId: assignmentData.classId, studentId: uid, type: 'tugas',
        essayAnswer, status: 'dikumpulkan',
        submittedAt: admin.firestore.FieldValue.serverTimestamp()
      });
    } else {
      // quiz / cbt -> auto-grade
      const qDocs = await Promise.all((assignmentData.questionIds || []).map(qid => db.collection('questions').doc(qid).get()));
      const questions = qDocs.filter(d => d.exists).map(d => ({ id: d.id, ...d.data() }));
      const answers = {};
      questions.forEach(q => {
        const val = req.body[`q_${q.id}`];
        if (val !== undefined) answers[q.id] = parseInt(val);
      });
      const result = autoGradeQuiz(answers, questions);
      await subRef.set({
        assignmentId: assignmentData.id, classId: assignmentData.classId, studentId: uid, type: assignmentData.type,
        answers, score: result.score, status: 'dinilai',
        submittedAt: admin.firestore.FieldValue.serverTimestamp(),
        gradedAt: admin.firestore.FieldValue.serverTimestamp()
      });
      await notifyUser({
        userId: uid, type: 'grade',
        title: assignmentData.type === 'quiz' ? 'Nilai Quiz' : 'Nilai CBT',
        message: `"${assignmentData.title}" selesai dinilai otomatis: ${result.score}`,
        link: `/student/assignments/${req.params.id}`
      });
    }
    res.redirect(`/student/assignments/${req.params.id}?success=1`);
  } catch (err) {
    console.error(err);
    res.redirect(`/student/assignments/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

module.exports = router;
