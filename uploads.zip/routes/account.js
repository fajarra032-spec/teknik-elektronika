// ==================== AKUN SAYA (PROFIL & GANTI PASSWORD) ====================
// Dipakai oleh SEMUA role (admin, guru, siswa) — belum ada sebelumnya.
const express = require('express');
const multer = require('multer');
const { db, admin } = require('../config/firebase');
const { isAuthenticated } = require('../middleware/auth');
const { isDriveConfigured, getNestedFolder, uploadBufferToDrive, deleteDriveFile } = require('../utils/localStorageHelper');
const { compressImage } = require('../utils/imageHelper');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } }); // maks 10MB sebelum kompresi

function dashboardUrlFor(role) {
  if (role === 'admin') return '/admin/dashboard';
  if (role === 'teacher') return '/teacher/dashboard';
  return '/user/dashboard';
}

router.get('/account/profile', isAuthenticated, async (req, res) => {
  try {
    const userDoc = await db.collection('users').doc(req.session.user.uid).get();
    const profile = userDoc.exists ? userDoc.data() : {};
    res.render('account/profile', {
      user: req.session.user, profile,
      dashboardUrl: dashboardUrlFor(req.session.user.role),
      driveConfigured: isDriveConfigured(),
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil profil: ' + err.message);
  }
});

// UPDATE nama, nomor HP & foto (dipakai untuk foto di sertifikat)
router.post('/account/profile/update', isAuthenticated, upload.single('photoFile'), async (req, res) => {
  const { name, phone, photoUrl, address, parentName, parentPhone } = req.body;
  const file = req.file;
  if (!name) {
    return res.redirect('/account/profile?error=' + encodeURIComponent('Nama tidak boleh kosong'));
  }
  try {
    const userRef = db.collection('users').doc(req.session.user.uid);
    const oldData = (await userRef.get()).data() || {};
    const updateData = { name, phone: phone || '' };

    // Biodata singkat (alamat, orang tua) hanya bermakna untuk siswa, tapi
    // disimpan apa adanya kalau field ini memang dikirim dari form.
    if (address !== undefined) updateData.address = address || '';
    if (parentName !== undefined) updateData.parentName = parentName || '';
    if (parentPhone !== undefined) updateData.parentPhone = parentPhone || '';

    if (file) {
      // Foto diunggah lewat sistem -> kompres dulu, lalu upload ke Google Drive
      if (!isDriveConfigured()) {
        return res.redirect('/account/profile?error=' + encodeURIComponent('Upload foto belum bisa dipakai — integrasi Google Drive belum di-setup di server. Sementara pakai opsi "Link Foto" dulu.'));
      }
      if (oldData.photoFileId) await deleteDriveFile(oldData.photoFileId); // hapus foto lama supaya tidak menumpuk

      const compressed = await compressImage(file.buffer, { width: 800, quality: 80 });
      const folderId = await getNestedFolder(['ELMS', 'Foto Akun', `${req.session.user.uid}_${name}`.replace(/[^a-zA-Z0-9_]/g, '_')]);
      const uploaded = await uploadBufferToDrive({
        buffer: compressed, fileName: `foto_${Date.now()}.jpg`, mimeType: 'image/jpeg', folderId
      });
      updateData.photoUrl = uploaded.fileUrl;
      updateData.photoFileId = uploaded.fileId;
    } else if (photoUrl !== undefined) {
      // Tidak upload file -> pakai link yang ditempel manual (atau dikosongkan)
      updateData.photoUrl = photoUrl || '';
    }

    await userRef.update(updateData);
    await admin.auth().updateUser(req.session.user.uid, { displayName: name });
    req.session.user.name = name; // sinkronkan session supaya nama baru langsung terlihat di nav
    res.redirect('/account/profile?success=' + encodeURIComponent('Profil berhasil diperbarui'));
  } catch (err) {
    console.error(err);
    res.redirect('/account/profile?error=' + encodeURIComponent(err.message));
  }
});

// GANTI PASSWORD
router.post('/account/profile/password', isAuthenticated, async (req, res) => {
  const { newPassword, confirmPassword } = req.body;
  if (!newPassword || newPassword.length < 6) {
    return res.redirect('/account/profile?error=' + encodeURIComponent('Password baru minimal 6 karakter'));
  }
  if (newPassword !== confirmPassword) {
    return res.redirect('/account/profile?error=' + encodeURIComponent('Konfirmasi password tidak cocok'));
  }
  try {
    await admin.auth().updateUser(req.session.user.uid, { password: newPassword });
    res.redirect('/account/profile?success=' + encodeURIComponent('Password berhasil diganti'));
  } catch (err) {
    console.error(err);
    res.redirect('/account/profile?error=' + encodeURIComponent(err.message));
  }
});

module.exports = router;
