/**
 * routes/admin/mahasiswa.js
 * Kelola data mahasiswa dengan progres semester (1-12), status magang, dan status mahasiswa terpisah
 */

const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../../middleware/auth');
const { db, auth } = require('../../config/firebaseAdmin');
const drive = require('../../config/googleDrive');
const { Readable } = require('stream');
const multer = require('multer');
const { KONSENTRASI_OPTIONS, AGAMA_OPTIONS, DEFAULT_AGAMA, parseSemesterNumber, aktifkanPaketKrs, SEMESTER_MULAI_KONSENTRASI } = require('../../helpers/paketKurikulumHelper');
const { isBiodataLengkap, getBiodataKosong, BIODATA_FIELDS, GROUP_LABELS } = require('../../helpers/biodataHelper');
const { getCurrentAcademicSemester, normalizeKelas } = require('../../helpers/academicHelper');
const { buatDokumenSkPa } = require('../../helpers/skPaHelper');
const { dosenCache, mahasiswaCache, getAllMahasiswa } = require('../../helpers/cache');
const upload = multer({ storage: multer.memoryStorage() });

router.use(verifyToken);
router.use(isAdmin);

// ============================================================================
// FUNGSI BANTU
// ============================================================================

/**
 * Daftar dosen (untuk dropdown assign "Dosen PA" / Pembimbing Akademik) -
 * dipakai di form tambah/edit mahasiswa, assign massal, dan detail.
 */
async function getAllDosenPa() {
  // ✅ CACHE: fungsi ini dipanggil di hampir setiap route halaman ini
  // (daftar, tambah, edit, sk-pa) - tanpa cache, satu kunjungan admin bisa
  // memicu query 'dosen' berkali-kali walau datanya sama. Daftar dosen
  // jarang berubah, aman di-cache 10 menit (lihat helpers/cache.js).
  return dosenCache.getOrFetch('daftarDosenPa', async () => {
    const snapshot = await db.collection('dosen').orderBy('nama').get();
    return snapshot.docs.map(doc => {
      const d = doc.data();
      return {
        id: doc.id,
        nama: d.nama,
        // Dosen yang dibuat lewat form standar (/admin/dosen atau /admin/users)
        // menyimpan identitasnya di field `nip`, sementara sebagian data lama
        // (mis. hasil impor SK) memakai `nidn`/`nuptk` - tampilkan yang ada.
        nidn: d.nidn || d.nip || d.nuptk || ''
      };
    });
  });
}

async function getMahasiswaFotoFolderId() {
  const folderName = 'Foto_Mahasiswa';
  const query = await drive.files.list({
    q: `name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    fields: 'files(id)',
  });
  if (query.data.files.length > 0) return query.data.files[0].id;
  const folder = await drive.files.create({
    resource: { name: folderName, mimeType: 'application/vnd.google-apps.folder' },
    fields: 'id',
  });
  return folder.data.id;
}

function getAngkatanFromNim(nim) {
  if (nim && nim.length >= 2) return '20' + nim.substring(0, 2);
  return new Date().getFullYear().toString();
}

const SEMESTER_OPTIONS = Array.from({ length: 12 }, (_, i) => `Semester ${i + 1}`);
const MAGANG_OPTIONS = ['Magang 1', 'Magang 2', 'Magang 3', 'Selesai Magang'];
const STATUS_MAHASISWA_OPTIONS = ['Aktif', 'Lulus', 'Cuti', 'Keluar'];

// "Kelas" di sini murni label pengelompokan administratif (rombel) untuk
// jadwal/presensi, mis. "ELK1A", "ELK1B", "ELK3A", "ELK1ON" - TIDAK
// mengubah/membatasi mata kuliah yang bisa diambil mahasiswa. Tidak ada
// daftar baku (bebas diisi admin), jadi tidak ada KELAS_OPTIONS di sini -
// nilai unik yang sudah dipakai dikumpulkan dinamis dari data mahasiswa
// yang ada (lihat kelasSet di GET '/').
//
// "Konsentrasi" (KONSENTRASI_OPTIONS, dari paketKurikulumHelper) BEDA -
// ini menentukan PAKET KRS mana yang otomatis diaktifkan mulai semester 3
// (lihat helpers/paketKurikulumHelper.js), jadi nilainya baku/tetap.

// ============================================================================
// DAFTAR MAHASISWA (dengan filter lengkap)
// ============================================================================

/**
 * Ambil daftar mahasiswa sesuai filter query (angkatan, semester,
 * statusMagang, statusMahasiswa, kelas, search) - dipakai bareng oleh
 * halaman daftar ('/') dan halaman cetak ('/print') supaya filter yang
 * sedang aktif di layar bisa langsung dicetak persis yang terlihat.
 */
async function getFilteredMahasiswaList(query) {
  const { angkatan, semester, statusMagang, statusMahasiswa, kelas, search } = query;

  // ✅ CACHE: sebelumnya query 'users' (role=mahasiswa) dibaca ULANG dari
  // Firestore setiap kali fungsi ini dipanggil (halaman daftar, cetak,
  // sk-pa masing-masing memanggilnya sendiri-sendiri). getAllMahasiswa()
  // pakai cache bersama 10 menit (helpers/cache.js) - satu kunjungan yang
  // memicu beberapa pemanggilan sekaligus cukup 1x baca Firestore.
  const allMahasiswa = await getAllMahasiswa(db);
  const sorted = [...allMahasiswa].sort((a, b) => (a.nim || '').localeCompare(b.nim || ''));

  const mahasiswaList = [];
  const angkatanSet = new Set();
  const kelasSet = new Set();

  for (const data of sorted) {
    const m = { ...data };
    m.biodataLengkap = isBiodataLengkap(m);
    const angkatanMhs = getAngkatanFromNim(m.nim);
    angkatanSet.add(angkatanMhs);
    if (m.kelas) kelasSet.add(m.kelas);

    if (angkatan && angkatanMhs !== angkatan) continue;
    if (semester && m.semester !== semester) continue;
    if (statusMagang && m.statusMagang !== statusMagang) continue;
    if (statusMahasiswa && m.statusMahasiswa !== statusMahasiswa) continue;
    if (kelas && m.kelas !== kelas) continue;
    if (search) {
      const lower = search.toLowerCase();
      const matchNama = m.nama && m.nama.toLowerCase().includes(lower);
      const matchNim = m.nim && m.nim.includes(search);
      if (!matchNama && !matchNim) continue;
    }
    mahasiswaList.push(m);
  }

  return {
    mahasiswaList,
    angkatanList: Array.from(angkatanSet).sort().reverse(),
    kelasList: Array.from(kelasSet).sort()
  };
}

router.get('/', async (req, res) => {
  try {
    const { angkatan, semester, statusMagang, statusMahasiswa, kelas, search } = req.query;

    let importResult = null, importError = null;
    if (req.query.import === 'done' && req.session.importResult) {
      importResult = req.session.importResult;
      delete req.session.importResult;
    }
    if (req.session.importError) {
      importError = req.session.importError;
      delete req.session.importError;
    }

    const { mahasiswaList: fullMahasiswaList, angkatanList, kelasList } = await getFilteredMahasiswaList(req.query);
    const dosenPaList = await getAllDosenPa();

    // ✅ PAGINASI: jangan render SEMUA mahasiswa terfilter sekaligus ke
    // tabel - default 10/halaman, ada tombol "Tampilkan Semua" (mis. saat
    // admin mau assign kelas/Dosen PA massal ke lebih dari 10 mahasiswa
    // sekaligus). Ini paginasi di memori atas hasil yang sudah di-cache
    // (getFilteredMahasiswaList), jadi TIDAK menambah baca Firestore.
    const MAHASISWA_PAGE_SIZE = 10;
    const showAll = req.query.all === '1';
    const totalMahasiswa = fullMahasiswaList.length;

    const buildListUrl = (params) => {
      const usp = new URLSearchParams();
      if (angkatan) usp.set('angkatan', angkatan);
      if (semester) usp.set('semester', semester);
      if (statusMagang) usp.set('statusMagang', statusMagang);
      if (statusMahasiswa) usp.set('statusMahasiswa', statusMahasiswa);
      if (kelas) usp.set('kelas', kelas);
      if (search) usp.set('search', search);
      Object.entries(params).forEach(([k, v]) => usp.set(k, v));
      return `/admin/mahasiswa?${usp.toString()}`;
    };

    let mahasiswaList = fullMahasiswaList;
    let pageInfo = null;
    if (!showAll) {
      const page = Math.max(1, parseInt(req.query.page, 10) || 1);
      const start = (page - 1) * MAHASISWA_PAGE_SIZE;
      const paged = fullMahasiswaList.slice(start, start + MAHASISWA_PAGE_SIZE);
      const hasPrev = page > 1;
      const hasNext = start + MAHASISWA_PAGE_SIZE < totalMahasiswa;
      pageInfo = {
        hasPrev,
        hasNext,
        prevUrl: hasPrev ? buildListUrl({ page: page - 1 }) : null,
        nextUrl: hasNext ? buildListUrl({ page: page + 1 }) : null,
        allUrl: buildListUrl({ all: '1' }),
        count: paged.length,
        total: totalMahasiswa
      };
      mahasiswaList = paged;
    }

    res.render('admin/mahasiswa_list', {
      title: 'Kelola Mahasiswa',
      mahasiswa: mahasiswaList,
      totalMahasiswa,
      angkatanList,
      kelasList,
      dosenPaList,
      filterAngkatan: angkatan || '',
      filterSemester: semester || '',
      filterStatusMagang: statusMagang || '',
      filterStatusMahasiswa: statusMahasiswa || '',
      filterKelas: kelas || '',
      search: search || '',
      importResult,
      importError,
      pageInfo,
      showAll,
      pageListUrl: buildListUrl({ page: 1 }),
    });
  } catch (error) {
    console.error('Error mengambil data mahasiswa:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal mengambil data mahasiswa'
    });
  }
});

// ============================================================================
// CETAK DAFTAR MAHASISWA (foto, nama, kelas, Dosen PA) - pakai filter yang
// sama dengan yang lagi aktif di halaman daftar, supaya cetakannya persis
// apa yang sedang dilihat admin.
// ============================================================================

router.get('/print', async (req, res) => {
  try {
    const { mahasiswaList } = await getFilteredMahasiswaList(req.query);
    mahasiswaList.sort((a, b) => (a.nim || '').localeCompare(b.nim || ''));

    res.render('admin/mahasiswa_cetak', {
      title: 'Cetak Daftar Mahasiswa',
      mahasiswaList,
      filterInfo: {
        angkatan: req.query.angkatan || null,
        semester: req.query.semester || null,
        kelas: req.query.kelas || null,
        statusMahasiswa: req.query.statusMahasiswa || null,
        search: req.query.search || null
      },
      generatedAt: new Date().toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' })
    });
  } catch (error) {
    console.error('Error mencetak daftar mahasiswa:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat halaman cetak'
    });
  }
});

// ============================================================================
// RILIS SK PA (Surat Keputusan Penetapan Dosen Pembimbing Akademik) - .docx
// Hanya mengikutkan mahasiswa berstatus "Aktif" yang SUDAH punya Dosen PA.
// ============================================================================

router.get('/sk-pa', async (req, res) => {
  try {
    const { mahasiswaList, angkatanList, kelasList } = await getFilteredMahasiswaList({});
    const aktifPunyaPa = mahasiswaList.filter(m => m.statusMahasiswa === 'Aktif' && m.dosenPaNama);
    const aktifBelumPa = mahasiswaList.filter(m => m.statusMahasiswa === 'Aktif' && !m.dosenPaNama);

    const academic = getCurrentAcademicSemester(); // { label, semester, tahunAwal, tahunAkhir, tahunAkademik }

    res.render('admin/mahasiswa_sk_pa', {
      title: 'Rilis SK PA',
      angkatanList,
      kelasList,
      jumlahAktifPunyaPa: aktifPunyaPa.length,
      jumlahAktifBelumPa: aktifBelumPa.length,
      daftarBelumPa: aktifBelumPa,
      semesterDefault: academic.semester || 'Ganjil',
      tahunAjaranDefault: academic.tahunAkademik || ''
    });
  } catch (error) {
    console.error('Error memuat form SK PA:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat form Rilis SK PA' });
  }
});

router.post('/sk-pa/generate', async (req, res) => {
  try {
    const { nomorSk, semester, tahunAjaran, tanggal, kota, namaKaprodi, nidnKaprodi, angkatan, kelas } = req.body;

    if (!nomorSk || !semester || !tahunAjaran || !namaKaprodi) {
      return res.status(400).send('Nomor SK, Semester, Tahun Ajaran, dan Nama Ketua Program Studi wajib diisi.');
    }

    // Filter: SELALU cuma mahasiswa Aktif (dipaksa, terlepas dari input form)
    // + opsional angkatan/kelas kalau admin mau mempersempit lampirannya.
    const { mahasiswaList } = await getFilteredMahasiswaList({ angkatan, kelas });
    const daftarMahasiswa = mahasiswaList
      .filter(m => m.statusMahasiswa === 'Aktif' && m.dosenPaNama)
      .map(m => ({ nim: m.nim, nama: m.nama, dosenPaNama: m.dosenPaNama, dosenPaNidn: m.dosenPaNidn }))
      .sort((a, b) => {
        const cmp = (a.dosenPaNama || '').localeCompare(b.dosenPaNama || '');
        return cmp !== 0 ? cmp : (a.nim || '').localeCompare(b.nim || '');
      });

    if (daftarMahasiswa.length === 0) {
      return res.status(400).send('Tidak ada mahasiswa Aktif yang sudah punya Dosen PA sesuai filter ini - tidak ada yang bisa dicetak di lampiran.');
    }

    const tanggalTampil = tanggal
      ? new Date(tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })
      : new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

    const buffer = await buatDokumenSkPa({
      nomorSk,
      semester,
      tahunAjaran,
      tanggal: tanggalTampil,
      kota: kota || 'Palopo',
      namaKaprodi,
      nidnKaprodi: nidnKaprodi || '-',
      logoUrl: 'https://polidewa.ac.id/wp-content/uploads/2025/11/Desain-tanpa-judul-1.png'
    }, daftarMahasiswa);

    const namaFile = `SK_PA_${semester}_${tahunAjaran.replace('/', '-')}.docx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${namaFile}"`);
    res.send(buffer);
  } catch (error) {
    console.error('Error generate SK PA:', error);
    res.status(500).send('Gagal membuat dokumen SK PA: ' + error.message);
  }
});

// ============================================================================
// TAMBAH MAHASISWA
// ============================================================================

router.get('/create', async (req, res) => {
  res.render('admin/mahasiswa_form', {
    title: 'Tambah Mahasiswa',
    mahasiswa: null,
    semesterOptions: SEMESTER_OPTIONS,
    magangOptions: MAGANG_OPTIONS,
    statusMahasiswaOptions: STATUS_MAHASISWA_OPTIONS,
    konsentrasiOptions: KONSENTRASI_OPTIONS,
    agamaOptions: AGAMA_OPTIONS,
    defaultAgama: DEFAULT_AGAMA,
    dosenPaList: await getAllDosenPa()
  });
});

router.post('/', upload.single('foto'), async (req, res) => {
  try {
    const { nim, nama, email, password, semester, statusMagang, statusMahasiswa, kelas, konsentrasi, agama, dosenPaId } = req.body;
    const file = req.file;

    if (!nim || !nama || !email || !password) {
      return res.status(400).send('NIM, Nama, Email, dan Password wajib diisi');
    }

    let userRecord;
    try {
      userRecord = await auth.createUser({ email, password, displayName: nama });
    } catch (authError) {
      console.error('Gagal membuat user di Auth:', authError);
      return res.status(400).send('Email sudah terdaftar atau password tidak valid');
    }

    let fotoUrl = null, fotoFileId = null;
    if (file) {
      const folderId = await getMahasiswaFotoFolderId();
      const ext = file.originalname.split('.').pop();
      const fileName = `${nim}_${Date.now()}.${ext}`;
      const fileMetadata = { name: fileName, parents: [folderId] };
      const media = { mimeType: file.mimetype, body: Readable.from(file.buffer) };
      const response = await drive.files.create({
        resource: fileMetadata,
        media,
        fields: 'id, webViewLink',
      });
      fotoUrl = response.data.webViewLink;
      fotoFileId = response.data.id;
    }

    const finalSemester = SEMESTER_OPTIONS.includes(semester) ? semester : null;
    const finalMagang = MAGANG_OPTIONS.includes(statusMagang) ? statusMagang : null;
    const finalStatus = STATUS_MAHASISWA_OPTIONS.includes(statusMahasiswa) ? statusMahasiswa : 'Aktif';

    // Dosen PA (Pembimbing Akademik): simpan id + nama/nidn ter-denormalisasi
    // supaya tidak perlu join tiap kali ditampilkan (mis. di cetak KRS).
    let dosenPaData = { dosenPaId: null, dosenPaNama: null, dosenPaNidn: null };
    if (dosenPaId) {
      const dosenDoc = await db.collection('dosen').doc(dosenPaId).get();
      if (dosenDoc.exists) {
        dosenPaData = {
          dosenPaId,
          dosenPaNama: dosenDoc.data().nama || null,
          dosenPaNidn: dosenDoc.data().nidn || null
        };
      }
    }

    await db.collection('users').doc(userRecord.uid).set({
      nim,
      nama,
      email,
      foto: fotoUrl,
      fotoFileId,
      role: 'mahasiswa',
      semester: finalSemester,
      statusMagang: finalMagang,
      statusMahasiswa: finalStatus,
      kelas: normalizeKelas(kelas),
      konsentrasi: KONSENTRASI_OPTIONS.includes(konsentrasi) ? konsentrasi : null,
      // Agama: kalau tidak dipilih/tidak valid, default ke Islam (bisa
      // diubah admin kapan saja lewat form edit).
      agama: AGAMA_OPTIONS.includes(agama) ? agama : DEFAULT_AGAMA,
      ...dosenPaData,
      createdAt: new Date().toISOString(),
    });

    await db.collection('tagihan').doc(userRecord.uid).set({
      mahasiswaId: userRecord.uid,
      semester: [],
    });

    mahasiswaCache.delete('all'); // data mahasiswa berubah -> cache lama tidak valid lagi
    res.redirect('/admin/mahasiswa');
  } catch (error) {
    console.error('Error menambah mahasiswa:', error);
    res.status(500).send('Gagal menambah mahasiswa: ' + error.message);
  }
});

// ============================================================================
// DETAIL MAHASISWA
// ============================================================================

router.get('/:id', async (req, res) => {
  try {
    const mahasiswaDoc = await db.collection('users').doc(req.params.id).get();
    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const mahasiswa = { id: mahasiswaDoc.id, ...mahasiswaDoc.data() };

    const tagihanDoc = await db.collection('tagihan').doc(req.params.id).get();
    const tagihan = tagihanDoc.exists ? tagihanDoc.data() : { semester: [] };

    res.render('admin/mahasiswa_detail', {
      title: 'Detail Mahasiswa',
      mahasiswa,
      tagihan,
      biodataFields: BIODATA_FIELDS,
      groupLabels: GROUP_LABELS,
      biodataKosong: getBiodataKosong(mahasiswa),
      krsSuccess: req.query.krsSuccess || null,
      error: req.query.error || null
    });
  } catch (error) {
    console.error('Error mengambil detail mahasiswa:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat detail mahasiswa'
    });
  }
});

// ============================================================================
// EDIT MAHASISWA
// ============================================================================

router.get('/:id/edit', async (req, res) => {
  try {
    const mahasiswaDoc = await db.collection('users').doc(req.params.id).get();
    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const mahasiswa = { id: mahasiswaDoc.id, ...mahasiswaDoc.data() };
    res.render('admin/mahasiswa_form', {
      title: 'Edit Mahasiswa',
      mahasiswa,
      semesterOptions: SEMESTER_OPTIONS,
      magangOptions: MAGANG_OPTIONS,
      statusMahasiswaOptions: STATUS_MAHASISWA_OPTIONS,
      konsentrasiOptions: KONSENTRASI_OPTIONS,
      agamaOptions: AGAMA_OPTIONS,
      defaultAgama: DEFAULT_AGAMA,
      dosenPaList: await getAllDosenPa()
    });
  } catch (error) {
    console.error('Error memuat form edit mahasiswa:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat form edit'
    });
  }
});

router.post('/:id/update', upload.single('foto'), async (req, res) => {
  try {
    const { nim, nama, email, semester, statusMagang, statusMahasiswa, kelas, konsentrasi, agama, dosenPaId } = req.body;
    const file = req.file;
    const mahasiswaRef = db.collection('users').doc(req.params.id);
    const mahasiswaDoc = await mahasiswaRef.get();

    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const oldData = mahasiswaDoc.data();

    const updateData = {
      nim,
      nama,
      email,
      semester: SEMESTER_OPTIONS.includes(semester) ? semester : (oldData.semester || null),
      statusMagang: MAGANG_OPTIONS.includes(statusMagang) ? statusMagang : (oldData.statusMagang || null),
      statusMahasiswa: STATUS_MAHASISWA_OPTIONS.includes(statusMahasiswa) ? statusMahasiswa : (oldData.statusMahasiswa || 'Aktif'),
      kelas: kelas !== undefined ? normalizeKelas(kelas) : (oldData.kelas || null),
      konsentrasi: konsentrasi !== undefined ? (KONSENTRASI_OPTIONS.includes(konsentrasi) ? konsentrasi : null) : (oldData.konsentrasi || null),
      // Agama: admin bisa ubah kapan saja lewat form ini. Kalau field tidak
      // dikirim/tidak valid, pertahankan nilai lama - kalau belum pernah
      // diisi sama sekali, jatuh ke default (Islam).
      agama: agama !== undefined
        ? (AGAMA_OPTIONS.includes(agama) ? agama : (oldData.agama || DEFAULT_AGAMA))
        : (oldData.agama || DEFAULT_AGAMA),
      updatedAt: new Date().toISOString(),
    };

    // Dosen PA (Pembimbing Akademik): kalau field dikirim dan kosong berarti
    // admin sengaja mengosongkan penugasan. Kalau diisi, lookup nama/nidn
    // dosennya untuk disimpan ter-denormalisasi (dipakai di cetak KRS, dll).
    if (dosenPaId !== undefined) {
      if (dosenPaId) {
        const dosenDoc = await db.collection('dosen').doc(dosenPaId).get();
        if (dosenDoc.exists) {
          updateData.dosenPaId = dosenPaId;
          updateData.dosenPaNama = dosenDoc.data().nama || null;
          updateData.dosenPaNidn = dosenDoc.data().nidn || null;
        } else {
          updateData.dosenPaId = null;
          updateData.dosenPaNama = null;
          updateData.dosenPaNidn = null;
        }
      } else {
        updateData.dosenPaId = null;
        updateData.dosenPaNama = null;
        updateData.dosenPaNidn = null;
      }
    }

    if (file) {
      const folderId = await getMahasiswaFotoFolderId();
      const ext = file.originalname.split('.').pop();
      const fileName = `${nim}_${Date.now()}.${ext}`;
      const fileMetadata = { name: fileName, parents: [folderId] };
      const media = { mimeType: file.mimetype, body: Readable.from(file.buffer) };
      const response = await drive.files.create({
        resource: fileMetadata,
        media,
        fields: 'id, webViewLink',
      });
      updateData.foto = response.data.webViewLink;
      updateData.fotoFileId = response.data.id;

      if (oldData.fotoFileId) {
        try {
          await drive.files.delete({ fileId: oldData.fotoFileId });
        } catch (err) {
          console.error('Gagal hapus foto lama:', err);
        }
      }
    }

    if (email !== oldData.email) {
      try {
        await auth.updateUser(req.params.id, { email });
      } catch (authError) {
        console.error('Gagal update email di Auth:', authError);
      }
    }

    await mahasiswaRef.update(updateData);

    // ========================================================================
    // AUTO-AKTIFKAN PAKET KRS: begitu progres semester mahasiswa berubah
    // (atau status berubah jadi Aktif) DAN hasil akhirnya adalah semester
    // tertentu + status Aktif, otomatis aktifkan paket KRS semester itu -
    // lihat helpers/paketKurikulumHelper.js. Hanya jalan kalau semester
    // atau statusMahasiswa BENAR-BENAR berubah (bukan tiap kali admin
    // simpan form), supaya tidak membuat KRS duplikat tiap edit data lain.
    // ========================================================================
    let krsAutoMessage = null;
    let krsAutoOk = true;
    const semesterBerubah = oldData.semester !== updateData.semester;
    const statusBerubah = oldData.statusMahasiswa !== updateData.statusMahasiswa;
    if ((semesterBerubah || statusBerubah) && updateData.statusMahasiswa === 'Aktif') {
      const semesterNumber = parseSemesterNumber(updateData.semester);
      if (semesterNumber) {
        try {
          const hasil = await aktifkanPaketKrs(
            db, req.params.id, semesterNumber, updateData.konsentrasi,
            getCurrentAcademicSemester().label, req.user.id
          );
          krsAutoMessage = hasil.message;
          krsAutoOk = hasil.ok;
        } catch (krsError) {
          console.error('Gagal auto-aktifkan paket KRS:', krsError);
          krsAutoMessage = 'Gagal mengaktifkan paket KRS otomatis: ' + krsError.message;
          krsAutoOk = false;
        }
      }
    }

    mahasiswaCache.delete('all'); // data mahasiswa berubah -> cache lama tidak valid lagi

    if (krsAutoMessage) {
      const param = krsAutoOk ? 'krsSuccess' : 'error';
      return res.redirect(`/admin/mahasiswa/${req.params.id}?${param}=` + encodeURIComponent(krsAutoMessage));
    }
    res.redirect('/admin/mahasiswa');
  } catch (error) {
    console.error('Error update mahasiswa:', error);
    res.status(500).send('Gagal update mahasiswa: ' + error.message);
  }
});

// ============================================================================
// RESET PASSWORD
// ============================================================================

router.post('/:id/reset-password', async (req, res) => {
  try {
    const mahasiswaDoc = await db.collection('users').doc(req.params.id).get();
    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const email = mahasiswaDoc.data().email;
    await auth.generatePasswordResetLink(email);
    res.redirect(`/admin/mahasiswa/${req.params.id}?reset=email_sent`);
  } catch (error) {
    console.error('Error reset password:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal reset password'
    });
  }
});

// ============================================================================
// KELOLA TAGIHAN SPP
// ============================================================================

router.get('/:id/tagihan/tambah', async (req, res) => {
  try {
    const mahasiswaDoc = await db.collection('users').doc(req.params.id).get();
    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const mahasiswa = mahasiswaDoc.data();
    res.render('admin/tagihan_form', {
      title: 'Tambah Tagihan',
      mahasiswaId: req.params.id,
      mahasiswa,
      tagihan: null
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat form'
    });
  }
});

router.post('/:id/tagihan', async (req, res) => {
  try {
    const { semester, jumlah, jatuhTempo, status } = req.body;
    const mahasiswaId = req.params.id;

    if (!semester || !jumlah) {
      return res.status(400).send('Semester dan jumlah wajib diisi');
    }

    const tagihanRef = db.collection('tagihan').doc(mahasiswaId);
    const tagihanDoc = await tagihanRef.get();
    const existing = tagihanDoc.exists ? tagihanDoc.data() : { semester: [] };

    existing.semester.push({
      id: Date.now().toString(),
      semester,
      jumlah: parseInt(jumlah),
      jatuhTempo: jatuhTempo || null,
      status: status || 'belum lunas',
      createdAt: new Date().toISOString()
    });

    await tagihanRef.set(existing);
    res.redirect(`/admin/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error tambah tagihan:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal menambah tagihan'
    });
  }
});

router.get('/:id/tagihan/:tagihanId/edit', async (req, res) => {
  try {
    const mahasiswaDoc = await db.collection('users').doc(req.params.id).get();
    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const mahasiswa = mahasiswaDoc.data();

    const tagihanDoc = await db.collection('tagihan').doc(req.params.id).get();
    if (!tagihanDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Tagihan tidak ditemukan'
      });
    }

    const tagihanList = tagihanDoc.data().semester || [];
    const tagihan = tagihanList.find(t => t.id === req.params.tagihanId);
    if (!tagihan) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Tagihan tidak ditemukan'
      });
    }

    res.render('admin/tagihan_form', {
      title: 'Edit Tagihan',
      mahasiswaId: req.params.id,
      mahasiswa,
      tagihan,
      tagihanId: req.params.tagihanId
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat form edit'
    });
  }
});

router.post('/:id/tagihan/:tagihanId/update', async (req, res) => {
  try {
    const { semester, jumlah, jatuhTempo, status } = req.body;
    const tagihanRef = db.collection('tagihan').doc(req.params.id);
    const tagihanDoc = await tagihanRef.get();
    if (!tagihanDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Data tagihan tidak ditemukan'
      });
    }

    const data = tagihanDoc.data();
    const index = data.semester.findIndex(t => t.id === req.params.tagihanId);
    if (index === -1) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Tagihan tidak ditemukan'
      });
    }

    data.semester[index] = {
      ...data.semester[index],
      semester,
      jumlah: parseInt(jumlah),
      jatuhTempo: jatuhTempo || data.semester[index].jatuhTempo,
      status,
      updatedAt: new Date().toISOString()
    };

    await tagihanRef.set(data);
    res.redirect(`/admin/mahasiswa/${req.params.id}`);
  } catch (error) {
    console.error('Error update tagihan:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal update tagihan'
    });
  }
});

router.post('/:id/tagihan/:tagihanId/delete', async (req, res) => {
  try {
    const tagihanRef = db.collection('tagihan').doc(req.params.id);
    const tagihanDoc = await tagihanRef.get();
    if (!tagihanDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Data tagihan tidak ditemukan'
      });
    }

    const data = tagihanDoc.data();
    data.semester = data.semester.filter(t => t.id !== req.params.tagihanId);
    await tagihanRef.set(data);

    res.redirect(`/admin/mahasiswa/${req.params.id}`);
  } catch (error) {
    console.error('Error hapus tagihan:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal hapus tagihan'
    });
  }
});

// ============================================================================
// HAPUS MAHASISWA
// ============================================================================

router.post('/:id/delete', async (req, res) => {
  try {
    const mahasiswaRef = db.collection('users').doc(req.params.id);
    const mahasiswaDoc = await mahasiswaRef.get();
    if (!mahasiswaDoc.exists) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: 'Mahasiswa tidak ditemukan'
      });
    }
    const data = mahasiswaDoc.data();

    if (data.fotoFileId) {
      try {
        await drive.files.delete({ fileId: data.fotoFileId });
      } catch (err) {
        console.error('Gagal hapus foto mahasiswa:', err);
      }
    }

    try {
      await auth.deleteUser(req.params.id);
    } catch (authError) {
      console.error('Gagal hapus dari Auth:', authError);
    }

    await db.collection('tagihan').doc(req.params.id).delete();
    await mahasiswaRef.delete();

    mahasiswaCache.delete('all'); // data mahasiswa berubah -> cache lama tidak valid lagi
    res.redirect('/admin/mahasiswa');
  } catch (error) {
    console.error('Error hapus mahasiswa:', error);
    res.status(500).send('Gagal hapus mahasiswa: ' + error.message);
  }
});


// ============================================================================
// IMPORT & EXPORT CSV (dengan kolom nama)
// ============================================================================

/**
 * GET /admin/mahasiswa/template
 * Download template CSV untuk update data mahasiswa
 */
// ============================================================================
// ASSIGN KELAS MASSAL (pilih beberapa mahasiswa via checkbox di daftar,
// lalu set field `kelas` mereka sekaligus - pelengkap import CSV untuk
// penugasan cepat tanpa perlu bikin file)
// ============================================================================

router.post('/bulk-kelas', async (req, res) => {
  try {
    let { mahasiswaIds, kelas } = req.body;
    if (!mahasiswaIds) {
      req.session.importError = 'Tidak ada mahasiswa yang dipilih';
      return res.redirect('/admin/mahasiswa');
    }
    if (!Array.isArray(mahasiswaIds)) mahasiswaIds = [mahasiswaIds];

    const kelasFinal = normalizeKelas(kelas);

    // Firestore batch max 500 operasi - chunking untuk jaga-jaga kalau
    // suatu saat dipakai untuk angkatan besar sekaligus.
    const chunkSize = 450;
    for (let i = 0; i < mahasiswaIds.length; i += chunkSize) {
      const chunk = mahasiswaIds.slice(i, i + chunkSize);
      const batch = db.batch();
      chunk.forEach(id => {
        batch.update(db.collection('users').doc(id), {
          kelas: kelasFinal,
          updatedAt: new Date().toISOString()
        });
      });
      await batch.commit();
    }

    mahasiswaCache.delete('all'); // data mahasiswa berubah -> cache lama tidak valid lagi
    req.session.importResult = {
      success: mahasiswaIds.length,
      failed: 0,
      errors: [],
      pesan: kelasFinal
        ? `${mahasiswaIds.length} mahasiswa berhasil dimasukkan ke kelas ${kelasFinal}`
        : `Kelas berhasil dikosongkan untuk ${mahasiswaIds.length} mahasiswa`
    };
    res.redirect('/admin/mahasiswa?import=done');
  } catch (error) {
    console.error('Error bulk assign kelas:', error);
    req.session.importError = 'Gagal mengubah kelas mahasiswa: ' + error.message;
    res.redirect('/admin/mahasiswa');
  }
});

// ============================================================================
// ASSIGN DOSEN PA MASSAL (pilih beberapa mahasiswa via checkbox di daftar,
// lalu set Dosen Pembimbing Akademik mereka sekaligus)
// ============================================================================

router.post('/bulk-dosen-pa', async (req, res) => {
  try {
    let { mahasiswaIds, dosenPaId } = req.body;
    if (!mahasiswaIds) {
      req.session.importError = 'Tidak ada mahasiswa yang dipilih';
      return res.redirect('/admin/mahasiswa');
    }
    if (!Array.isArray(mahasiswaIds)) mahasiswaIds = [mahasiswaIds];

    let dosenPaData = { dosenPaId: null, dosenPaNama: null, dosenPaNidn: null };
    if (dosenPaId) {
      const dosenDoc = await db.collection('dosen').doc(dosenPaId).get();
      if (!dosenDoc.exists) {
        req.session.importError = 'Dosen PA yang dipilih tidak ditemukan';
        return res.redirect('/admin/mahasiswa');
      }
      dosenPaData = {
        dosenPaId,
        dosenPaNama: dosenDoc.data().nama || null,
        dosenPaNidn: dosenDoc.data().nidn || null
      };
    }

    // Firestore batch max 500 operasi - chunking untuk jaga-jaga kalau
    // suatu saat dipakai untuk angkatan besar sekaligus.
    const chunkSize = 450;
    for (let i = 0; i < mahasiswaIds.length; i += chunkSize) {
      const chunk = mahasiswaIds.slice(i, i + chunkSize);
      const batch = db.batch();
      chunk.forEach(id => {
        batch.update(db.collection('users').doc(id), {
          ...dosenPaData,
          updatedAt: new Date().toISOString()
        });
      });
      await batch.commit();
    }

    mahasiswaCache.delete('all'); // data mahasiswa berubah -> cache lama tidak valid lagi
    req.session.importResult = {
      success: mahasiswaIds.length,
      failed: 0,
      errors: [],
      pesan: dosenPaData.dosenPaNama
        ? `${mahasiswaIds.length} mahasiswa berhasil ditugaskan ke Dosen PA ${dosenPaData.dosenPaNama}`
        : `Dosen PA berhasil dikosongkan untuk ${mahasiswaIds.length} mahasiswa`
    };
    res.redirect('/admin/mahasiswa?import=done');
  } catch (error) {
    console.error('Error bulk assign dosen PA:', error);
    req.session.importError = 'Gagal menugaskan Dosen PA: ' + error.message;
    res.redirect('/admin/mahasiswa');
  }
});

router.get('/template', (req, res) => {
  const headers = ['nim', 'nama', 'noHp', 'semester', 'statusMagang', 'statusMahasiswa', 'kelas', 'konsentrasi', 'agama'];
  const example = ['20230101', 'Budi Santoso', '08123456789', 'Semester 1', 'Magang 1', 'Aktif', 'ELK1A', 'Instrumentasi', 'Islam'];
  const csvContent = [headers, example].map(row => row.join(',')).join('\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename=template_update_mahasiswa.csv');
  res.send('\uFEFF' + csvContent);
});

/**
 * POST /admin/mahasiswa/import
 * Upload CSV untuk update data mahasiswa (nim sebagai identifier)
 */
router.post('/import', upload.single('file'), async (req, res) => {
  try {
    const file = req.file;
    if (!file || file.mimetype !== 'text/csv') {
      req.session.importError = 'File harus berformat CSV';
      return res.redirect('/admin/mahasiswa');
    }

    let csvContent = file.buffer.toString('utf8');
    if (csvContent.charCodeAt(0) === 0xFEFF) csvContent = csvContent.substring(1);
    const lines = csvContent.split(/\r?\n/);
    if (lines.length < 2) {
      req.session.importError = 'File CSV kosong';
      return res.redirect('/admin/mahasiswa');
    }

    // Normalisasi header
    const normalizeHeader = (h) => {
      let header = h.trim().toLowerCase().replace(/\s/g, '');
      if (header === 'nohp') return 'noHp';
      if (header === 'statusmagang') return 'statusMagang';
      if (header === 'statusmahasiswa') return 'statusMahasiswa';
      if (header === 'kelas') return 'kelas';
      if (header === 'konsentrasi') return 'konsentrasi';
      if (header === 'agama') return 'agama';
      if (header === 'nim') return 'nim';
      if (header === 'nama') return 'nama';
      if (header === 'semester') return 'semester';
      return null;
    };

    const rawHeaders = lines[0].split(',').map(h => normalizeHeader(h)).filter(h => h !== null);
    const required = ['nim']; // minimal nim untuk identifikasi
    const missing = required.filter(r => !rawHeaders.includes(r));
    if (missing.length) {
      req.session.importError = `Header tidak lengkap: ${missing.join(', ')}. Header terbaca: ${rawHeaders.join(', ')}. Pastikan file CSV memiliki kolom: nim, dan minimal satu kolom update (nama, noHp, semester, statusMagang, statusMahasiswa, kelas)`;
      return res.redirect('/admin/mahasiswa');
    }

    let success = 0, failed = 0, errors = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (line === '') continue;
      const values = line.split(',').map(v => v.trim());
      if (values.length < rawHeaders.length) {
        failed++;
        errors.push(`Baris ${i}: Jumlah kolom tidak sesuai (${values.length} kolom, seharusnya ${rawHeaders.length})`);
        continue;
      }
      const row = {};
      rawHeaders.forEach((h, idx) => { row[h] = values[idx] || ''; });

      const nim = row.nim;
      if (!nim) {
        failed++;
        errors.push(`Baris ${i}: NIM tidak boleh kosong`);
        continue;
      }

      // Cari mahasiswa berdasarkan NIM
      const userSnapshot = await db.collection('users')
        .where('nim', '==', nim)
        .where('role', '==', 'mahasiswa')
        .limit(1)
        .get();
      if (userSnapshot.empty) {
        failed++;
        errors.push(`Baris ${i}: NIM ${nim} tidak ditemukan`);
        continue;
      }
      const userDoc = userSnapshot.docs[0];
      const updateData = {};

      // Update nama jika ada dan tidak kosong
      if (rawHeaders.includes('nama') && row.nama && row.nama.trim() !== '') {
        updateData.nama = row.nama.trim();
      }
      // Update noHp jika ada (boleh kosong)
      if (rawHeaders.includes('noHp')) {
        updateData.noHp = row.noHp || '';
      }
      // Update semester
      if (rawHeaders.includes('semester')) {
        let semester = row.semester?.trim();
        if (semester) {
          const match = semester.match(/\d+/);
          if (match) {
            const num = parseInt(match[0]);
            if (num >= 1 && num <= 12) updateData.semester = `Semester ${num}`;
            else updateData.semester = null;
          } else if (SEMESTER_OPTIONS.includes(semester)) {
            updateData.semester = semester;
          } else {
            updateData.semester = null;
          }
        } else {
          updateData.semester = null;
        }
      }
      // Update statusMagang
      if (rawHeaders.includes('statusMagang')) {
        let magang = row.statusMagang?.trim();
        if (magang) {
          const lower = magang.toLowerCase();
          if (lower.includes('magang 1') || lower === 'magang1') updateData.statusMagang = 'Magang 1';
          else if (lower.includes('magang 2') || lower === 'magang2') updateData.statusMagang = 'Magang 2';
          else if (lower.includes('magang 3') || lower === 'magang3') updateData.statusMagang = 'Magang 3';
          else if (lower.includes('selesai')) updateData.statusMagang = 'Selesai Magang';
          else if (MAGANG_OPTIONS.includes(magang)) updateData.statusMagang = magang;
          else updateData.statusMagang = null;
        } else {
          updateData.statusMagang = null;
        }
      }
      // Update statusMahasiswa
      if (rawHeaders.includes('statusMahasiswa')) {
        let status = row.statusMahasiswa?.trim();
        if (status) {
          const lower = status.toLowerCase();
          if (lower === 'aktif') updateData.statusMahasiswa = 'Aktif';
          else if (lower === 'lulus') updateData.statusMahasiswa = 'Lulus';
          else if (lower === 'cuti') updateData.statusMahasiswa = 'Cuti';
          else if (lower === 'keluar') updateData.statusMahasiswa = 'Keluar';
          else if (STATUS_MAHASISWA_OPTIONS.includes(status)) updateData.statusMahasiswa = status;
          else updateData.statusMahasiswa = null;
        } else {
          updateData.statusMahasiswa = null;
        }
      }

      // Update kelas (rombel, mis. "ELK1A") - boleh dikosongkan utk hapus
      if (rawHeaders.includes('kelas')) {
        updateData.kelas = normalizeKelas(row.kelas);
      }

      // Update konsentrasi (hanya diterima kalau sesuai KONSENTRASI_OPTIONS,
      // dipakai untuk menentukan paket KRS semester 3 ke atas)
      if (rawHeaders.includes('konsentrasi')) {
        const konsentrasi = row.konsentrasi?.trim();
        updateData.konsentrasi = KONSENTRASI_OPTIONS.includes(konsentrasi) ? konsentrasi : null;
      }

      // Update agama (hanya diterima kalau sesuai AGAMA_OPTIONS, dipakai
      // untuk memilih otomatis mata kuliah Pendidikan Agama semester 1).
      // Kosong/tidak valid -> dibiarkan (tidak menimpa dengan null, karena
      // agama tidak boleh "dikosongkan" seperti kelas/konsentrasi).
      if (rawHeaders.includes('agama')) {
        const agama = row.agama?.trim();
        if (AGAMA_OPTIONS.includes(agama)) updateData.agama = agama;
      }

      if (Object.keys(updateData).length === 0) {
        failed++;
        errors.push(`Baris ${i}: Tidak ada data yang akan diupdate (semua kolom kosong)`);
        continue;
      }

      try {
        await userDoc.ref.update(updateData);
        success++;
      } catch (err) {
        failed++;
        errors.push(`Baris ${i}: ${err.message}`);
      }
    }

    if (success > 0) mahasiswaCache.delete('all'); // ada data mahasiswa yang berubah -> cache lama tidak valid lagi
    req.session.importResult = { success, failed, errors };
    res.redirect('/admin/mahasiswa?import=done');
  } catch (error) {
    console.error('Import error:', error);
    req.session.importError = 'Gagal memproses file: ' + error.message;
    res.redirect('/admin/mahasiswa');
  }
});

/**
 * GET /admin/mahasiswa/export/csv
 * Ekspor data mahasiswa sesuai filter ke CSV (kolom: nim, nama, noHp, semester, statusMagang, statusMahasiswa)
 */
router.get('/export/csv', async (req, res) => {
  try {
    const { angkatan, search, semester, statusMagang, statusMahasiswa, kelas } = req.query;
    const snapshot = await db.collection('users')
      .where('role', '==', 'mahasiswa')
      .orderBy('nim')
      .get();

    const mahasiswaList = [];
    for (const doc of snapshot.docs) {
      const data = doc.data();
      const m = { id: doc.id, ...data };
      const angkatanMhs = getAngkatanFromNim(m.nim);
      if (angkatan && angkatanMhs !== angkatan) continue;
      if (semester && m.semester !== semester) continue;
      if (statusMagang && m.statusMagang !== statusMagang) continue;
      if (statusMahasiswa && m.statusMahasiswa !== statusMahasiswa) continue;
      if (kelas && m.kelas !== kelas) continue;
      if (search) {
        const lower = search.toLowerCase();
        if (!(m.nama && m.nama.toLowerCase().includes(lower)) &&
            !(m.nim && m.nim.includes(search))) continue;
      }
      mahasiswaList.push(m);
    }

    const rows = [
      ['nim', 'nama', 'noHp', 'semester', 'statusMagang', 'statusMahasiswa', 'kelas', 'konsentrasi', 'agama']
    ];
    for (const m of mahasiswaList) {
      rows.push([
        m.nim || '',
        m.nama || '',
        m.noHp || '',
        m.semester || '',
        m.statusMagang || '',
        m.statusMahasiswa || '',
        m.kelas || '',
        m.konsentrasi || '',
        m.agama || ''
      ]);
    }

    const csvContent = rows.map(row =>
      row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=mahasiswa_export.csv');
    res.send('\uFEFF' + csvContent);
  } catch (error) {
    console.error('Error export CSV:', error);
    res.status(500).send('Gagal export CSV');
  }
});

module.exports = router;