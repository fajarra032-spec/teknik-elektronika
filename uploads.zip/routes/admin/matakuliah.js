/**
 * routes/admin/matakuliah.js
 * Kelola mata kuliah (CRUD + dosen pengampu + jadwal + materi per pertemuan)
 * Dilengkapi route seeding untuk menambah PDK 1,2,3
 */

const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const { mataKuliahCache, getAllMataKuliah, getAllDosen, getAllMahasiswa } = require('../../helpers/cache');
const academicHelper = require('../../helpers/academicHelper');

router.use(verifyToken);
router.use(isAdmin);

// ============================================================================
// HELPER: mendapatkan daftar dosen untuk dropdown
// ============================================================================
async function getDosenList() {
  // ✅ CACHE: dosen jarang berubah - pakai getAllDosen() (cache 10 menit,
  // dipakai bersama dengan routes/admin/dosen.js) alih-alih baca ulang
  // koleksi 'dosen' setiap kali form/daftar MK dibuka.
  return getAllDosen(db);
}

/**
 * Daftar kelas yang sedang dipakai mahasiswa (mis. ELK1A, ELK1B, ELK1ON) -
 * dipakai sebagai saran (datalist) saat admin membuat/mengedit mata kuliah
 * untuk kelas paralel tertentu. Sumbernya field `kelas` di collection
 * `users`, SAMA seperti yang dipakai di /admin/mahasiswa, supaya konsisten.
 */
async function getDistinctKelasMahasiswa() {
  // ✅ CACHE: pakai getAllMahasiswa() (cache bersama, sama seperti dipakai
  // /admin/mahasiswa & /admin/khs) alih-alih query 'users' sendiri di sini.
  const semuaMahasiswa = await getAllMahasiswa(db);
  const kelasSet = new Set();
  semuaMahasiswa.forEach(m => { if (m.kelas) kelasSet.add(m.kelas); });
  return Array.from(kelasSet).sort();
}

// Konsentrasi mata kuliah semester 3 disimpan sebagai bagian dari teks
// bebas field `jenis` (mis. "Pilihan Teknik Elektronika (Instrumentasi)"),
// BUKAN field terpisah - fungsi ini menerjemahkannya jadi label singkat
// untuk ditampilkan sebagai badge (read-only, belum ada di form edit).
// Kalau `jenis` tidak menyebut konsentrasi tertentu, MK itu dianggap
// berlaku untuk SEMUA konsentrasi (label "Umum").
function getKonsentrasiLabel(jenis) {
  if (!jenis) return 'Umum';
  if (jenis.includes('(Instrumentasi)')) return 'Instrumentasi';
  if (jenis.includes('(Telekomunikasi)')) return 'Telekomunikasi';
  return 'Umum';
}

// ============================================================================
// HELPER: PENGAMPU PER PERIODE (Ganjil/Genap tahun ajaran)
// ============================================================================
// Setiap MK bisa punya dosen pengampu berbeda tiap periode. Riwayatnya
// disimpan di subcollection mataKuliah/{id}/pengampuPeriode/{periodeId}.
// Field mataKuliah.dosenIds tetap dipertahankan sebagai "cermin" pengampu
// periode AKTIF saat ini, supaya fitur lain (dashboard dosen, elearning,
// nilai, rubrik, kurikulum, dll) yang selama ini membaca mk.dosenIds tidak
// perlu diubah sama sekali.

/**
 * Simpan/perbarui pengampu untuk satu periode tertentu.
 * Jika periode tsb adalah periode aktif saat ini, mk.dosenIds ikut disinkronkan.
 */
async function savePengampuPeriode(mkId, periodeId, dosenArray) {
  const semuaPeriode = academicHelper.generatePeriodeOptions(50, 5);
  const info = semuaPeriode.find(p => p.id === periodeId);

  const label = info ? info.label : periodeId;
  const semester = info ? info.semester : null;
  const tahunAwal = info ? info.tahunAwal : null;
  const tahunAkhir = info ? info.tahunAkhir : null;
  const urutan = info ? info.urutan : 0;

  await db.collection('mataKuliah').doc(mkId)
    .collection('pengampuPeriode').doc(periodeId)
    .set({
      periodeId,
      label,
      semester,
      tahunAwal,
      tahunAkhir,
      urutan,
      dosenIds: dosenArray,
      updatedAt: new Date().toISOString()
    }, { merge: true });

  // Sinkronkan ke field utama jika ini periode yang sedang berjalan
  const activePeriodeId = academicHelper.getActivePeriodeId();
  if (periodeId === activePeriodeId) {
    await db.collection('mataKuliah').doc(mkId).update({
      dosenIds: dosenArray,
      periodeAktifId: periodeId,
      periodeAktifLabel: label
    });
  }

  mataKuliahCache.delete('all');
}

/**
 * Ambil dosenIds yang tersimpan untuk satu periode tertentu.
 * Kalau periode itu belum pernah disimpan tapi kebetulan periode aktif,
 * fallback ke mk.dosenIds (data lama sebelum fitur per-periode ada).
 */
async function getPengampuUntukPeriode(mkId, periodeId, fallbackDosenIds) {
  const doc = await db.collection('mataKuliah').doc(mkId)
    .collection('pengampuPeriode').doc(periodeId).get();
  if (doc.exists) return doc.data().dosenIds || [];

  const activePeriodeId = academicHelper.getActivePeriodeId();
  if (periodeId === activePeriodeId && fallbackDosenIds) return fallbackDosenIds;
  return [];
}

/**
 * Ambil seluruh riwayat pengampu (semua periode) untuk ditampilkan di form/detail.
 */
async function getRiwayatPengampu(mkId, dosenMap) {
  const snap = await db.collection('mataKuliah').doc(mkId)
    .collection('pengampuPeriode').orderBy('urutan', 'desc').get();
  return snap.docs.map(doc => {
    const data = doc.data();
    const dosenNames = (data.dosenIds || []).map(id => dosenMap[id] || 'Unknown');
    return { ...data, dosenNames };
  });
}

// ============================================================================
// DAFTAR MATA KULIAH
// ============================================================================
router.get('/', async (req, res) => {
  try {
    // Filter berdasarkan semester if ada
    const { semester, semesterAktif, search } = req.query;

    // ========================================================================
    // FILTER "SEMESTER AKTIF" (Ganjil/Genap) - dosen yang mengajar biasanya
    // beda antara semester ganjil & genap, jadi daftar MK yang ditampilkan
    // default disaring cuma yang relevan untuk periode yang SEDANG berjalan
    // (semester ganjil = nomor semester 1,3,5,7..., genap = 2,4,6,8...).
    // MK Praktik Dunia Kerja (isPDK) SELALU tampil apa pun filternya - PDK
    // tidak terikat semester ganjil/genap.
    //
    // req.query.semesterAktif === undefined  -> belum pernah difilter user
    //   (kunjungan pertama ke halaman) -> DEFAULT ke periode yang sedang
    //   aktif sekarang (otomatis, dari academicHelper).
    // req.query.semesterAktif === ''         -> user SENGAJA pilih "Semua"
    //   di dropdown -> jangan difilter sama sekali.
    // req.query.semesterAktif === 'Ganjil'/'Genap' -> filter sesuai pilihan.
    // ========================================================================
    const semesterAktifDipilihEksplisit = semesterAktif !== undefined;
    const semesterAktifDipakai = semesterAktifDipilihEksplisit
      ? semesterAktif
      : academicHelper.getCurrentAcademicSemester().semester; // default: periode aktif sekarang

    // ✅ OPTIMISASI: sebelumnya tiap kombinasi filter `semester` memicu
    // query Firestore BARU (where('semester', '==', ...)), dan dosen dibaca
    // ulang penuh setiap kunjungan. Sekarang ambil SEKALI dari cache
    // (getAllMataKuliah/getAllDosen - 10 menit, lihat helpers/cache.js) lalu
    // filter semester & search di memori - koleksi ini kecil (puluhan MK),
    // jadi filter di JS jauh lebih murah daripada bolak-balik ke Firestore.
    const [semuaMataKuliah, dosenList] = await Promise.all([
      getAllMataKuliah(db),
      getAllDosen(db)
    ]);

    let matakuliah = [...semuaMataKuliah].sort((a, b) => (a.kode || '').localeCompare(b.kode || ''));

    // Filter berdasarkan semester jika ada
    if (semester) {
      const semesterNum = parseInt(semester);
      matakuliah = matakuliah.filter(mk => mk.semester === semesterNum);
    }

    // Filter berdasarkan search (manual karena Firestore tidak mendukung partial text search)
    if (search) {
      const lowerSearch = search.toLowerCase();
      matakuliah = matakuliah.filter(mk => 
        mk.kode.toLowerCase().includes(lowerSearch) || 
        mk.nama.toLowerCase().includes(lowerSearch)
      );
    }

    // Ambil data dosen untuk ditampilkan
    const dosenMap = {};
    dosenList.forEach(d => { dosenMap[d.id] = d.nama; });

    // Untuk setiap matakuliah, tambahkan field dosenNames (array nama dosen)
    // dan label konsentrasi (derivasi read-only dari field `jenis`)
    let matakuliahWithDosen = matakuliah.map(mk => {
      const dosenNames = (mk.dosenIds || []).map(id => dosenMap[id] || 'Unknown').filter(Boolean);
      return { ...mk, dosenNames, konsentrasiLabel: getKonsentrasiLabel(mk.jenis) };
    });

    // Terapkan filter Semester Aktif (Ganjil/Genap) - PDK selalu lolos filter ini
    if (semesterAktifDipakai) {
      matakuliahWithDosen = matakuliahWithDosen.filter(mk => {
        if (mk.isPDK) return true; // Praktik Dunia Kerja tidak terikat ganjil/genap
        if (!mk.semester) return true; // jangan sembunyikan data yang semesternya belum keisi
        const parity = mk.semester % 2 === 1 ? 'Ganjil' : 'Genap';
        return parity === semesterAktifDipakai;
      });
    }

    res.render('admin/matakuliah_list', {
      title: 'Daftar Mata Kuliah',
      matakuliah: matakuliahWithDosen,
      filterSemester: semester || '',
      filterSemesterAktif: semesterAktifDipakai || '',
      tahunAjaranAktif: academicHelper.getCurrentAcademicSemester().tahunAkademik, // mis. "2026/2027"
      search: search || ''
    });
  } catch (error) {
    console.error('Error mengambil MK:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat data MK' });
  }
});

// ============================================================================
// TAMBAH MATA KULIAH
// ============================================================================
router.get('/create', async (req, res) => {
  try {
    const dosenList = await getDosenList();
    const periodeOptions = academicHelper.generatePeriodeOptions();
    const activePeriodeId = academicHelper.getActivePeriodeId();
    const selectedPeriodeId = req.query.periode || activePeriodeId;
    const kelasList = await getDistinctKelasMahasiswa();

    res.render('admin/matakuliah_form', {
      title: 'Tambah Mata Kuliah',
      mk: null,
      dosenList,
      periodeOptions,
      activePeriodeId,
      selectedPeriodeId,
      selectedDosenIds: [],
      pengampuHistori: [],
      kelasList
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat form' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { kode, nama, sks, semester, periodeId, dosenIds, jadwal, isPDK, kelas } = req.body;

    // Validasi
    if (!kode || !nama || !sks || !semester) {
      return res.status(400).send('Kode, Nama, SKS, dan Semester wajib diisi');
    }

    const kelasFinal = academicHelper.normalizeKelas(kelas);

    // Cek duplikasi kode+kelas (BUKAN kode saja) - supaya satu kode MK boleh
    // punya beberapa dokumen untuk kelas paralel berbeda (mis. WUD3208 untuk
    // ELK1A dan ELK1B, masing-masing dengan dosen/jadwal sendiri), tapi tetap
    // mencegah entri persis sama (kode+kelas identik) dibuat dobel.
    const existingSnapshot = await db.collection('mataKuliah').where('kode', '==', kode).get();
    const sudahAdaKelasSama = existingSnapshot.docs.some(doc => academicHelper.normalizeKelas(doc.data().kelas) === kelasFinal);
    if (sudahAdaKelasSama) {
      return res.status(400).send(
        kelasFinal
          ? `Kode MK "${kode}" untuk kelas "${kelasFinal}" sudah ada. Kalau mau tambah kelas paralel lain untuk kode yang sama, isi field Kelas dengan nama kelas yang BEDA (mis. ELK1B).`
          : `Kode MK "${kode}" sudah ada (tanpa kelas spesifik). Kalau mau membuat versi per-kelas, isi field Kelas.`
      );
    }

    // Proses isPDK (checkbox)
    const isPDKFlag = isPDK === '1' || isPDK === true; // karena dari form berupa string '1'

    // Buat array materi default
    const materi = Array.from({ length: 16 }, (_, i) => ({
      pertemuan: i + 1,
      topik: ''
    }));

    const docRef = await db.collection('mataKuliah').add({
      kode,
      nama,
      sks: parseInt(sks),
      semester: parseInt(semester),
      kelas: kelasFinal,
      dosenIds: [], // akan diisi lewat savePengampuPeriode di bawah kalau ada
      jadwal: jadwal || '',
      isPDK: isPDKFlag,
      materi,
      createdAt: new Date().toISOString()
    });

    // Simpan pengampu untuk periode yang dipilih di form (kalau diisi)
    if (periodeId) {
      let dosenArray = [];
      if (dosenIds) {
        dosenArray = Array.isArray(dosenIds) ? dosenIds : [dosenIds];
      }
      await savePengampuPeriode(docRef.id, periodeId, dosenArray);
    }

    mataKuliahCache.delete('all');
    res.redirect('/admin/matakuliah');
  } catch (error) {
    console.error('Error tambah MK:', error);
    res.status(500).send('Gagal menambah MK: ' + error.message);
  }
});

// ============================================================================
// DETAIL MATA KULIAH (untuk melihat & mengedit materi)
// ============================================================================
router.get('/:id', async (req, res) => {
  try {
    const mkDoc = await db.collection('mataKuliah').doc(req.params.id).get();
    if (!mkDoc.exists) {
      return res.status(404).send('Mata kuliah tidak ditemukan');
    }
    const mk = { id: mkDoc.id, ...mkDoc.data() };
    mk.konsentrasiLabel = getKonsentrasiLabel(mk.jenis);

    // Ambil nama dosen untuk ditampilkan
    const dosenMap = {};
    const dosenSnapshot = await db.collection('dosen').get();
    dosenSnapshot.docs.forEach(doc => {
      dosenMap[doc.id] = doc.data().nama;
    });

    const pengampuHistori = await getRiwayatPengampu(mk.id, dosenMap);

    // Modul pembelajaran (dibuat & dikustomisasi bebas oleh dosen di sisi
    // dosen) - di sini admin hanya melihat, tidak mengedit.
    const modulSnapshot = await db.collection('mataKuliah').doc(mk.id).collection('modul').get();
    const modulList = modulSnapshot.docs
      .map(doc => ({ id: doc.id, ...doc.data() }))
      .sort((a, b) => (a.urutan || 0) - (b.urutan || 0));

    res.render('admin/matakuliah_detail', {
      title: `Detail MK: ${mk.kode}`,
      mk,
      dosenMap,
      pengampuHistori,
      modulList
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat detail MK' });
  }
});

// ============================================================================
// EDIT MATA KULIAH (metadata)
// ============================================================================
router.get('/:id/edit', async (req, res) => {
  try {
    const mkDoc = await db.collection('mataKuliah').doc(req.params.id).get();
    if (!mkDoc.exists) {
      return res.status(404).send('Mata kuliah tidak ditemukan');
    }
    const mk = { id: mkDoc.id, ...mkDoc.data() };
    const dosenList = await getDosenList();

    const periodeOptions = academicHelper.generatePeriodeOptions();
    const activePeriodeId = academicHelper.getActivePeriodeId();
    const selectedPeriodeId = req.query.periode || activePeriodeId;

    const selectedDosenIds = await getPengampuUntukPeriode(mk.id, selectedPeriodeId, mk.dosenIds);

    const dosenMap = {};
    dosenList.forEach(d => { dosenMap[d.id] = d.nama; });
    const pengampuHistori = await getRiwayatPengampu(mk.id, dosenMap);
    const kelasList = await getDistinctKelasMahasiswa();

    res.render('admin/matakuliah_form', {
      title: 'Edit Mata Kuliah',
      mk,
      dosenList,
      periodeOptions,
      activePeriodeId,
      selectedPeriodeId,
      selectedDosenIds,
      pengampuHistori,
      kelasList
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat form edit' });
  }
});

router.post('/:id/update', async (req, res) => {
  try {
    const { kode, nama, sks, semester, periodeId, dosenIds, jadwal, isPDK, kelas } = req.body;
    const mkRef = db.collection('mataKuliah').doc(req.params.id);
    const kelasFinal = academicHelper.normalizeKelas(kelas);

    // Validasi kode+kelas unik (lihat penjelasan lengkap di POST '/' - satu
    // kode boleh dipakai lebih dari sekali asal kelasnya beda)
    const mkDoc = await mkRef.get();
    const oldData = mkDoc.data();
    if (kode !== oldData.kode || kelasFinal !== academicHelper.normalizeKelas(oldData.kelas)) {
      const existingSnapshot = await db.collection('mataKuliah').where('kode', '==', kode).get();
      const bentrok = existingSnapshot.docs.some(doc => doc.id !== req.params.id && academicHelper.normalizeKelas(doc.data().kelas) === kelasFinal);
      if (bentrok) {
        return res.status(400).send(
          kelasFinal
            ? `Kode MK "${kode}" untuk kelas "${kelasFinal}" sudah dipakai MK lain.`
            : `Kode MK "${kode}" (tanpa kelas spesifik) sudah dipakai MK lain.`
        );
      }
    }

    const isPDKFlag = isPDK === '1' || isPDK === true;

    await mkRef.update({
      kode,
      nama,
      sks: parseInt(sks),
      semester: parseInt(semester),
      kelas: kelasFinal,
      jadwal: jadwal || '',
      isPDK: isPDKFlag,
      updatedAt: new Date().toISOString()
    });

    // Simpan pengampu untuk periode yang sedang dipilih di form
    if (periodeId) {
      let dosenArray = [];
      if (dosenIds) {
        dosenArray = Array.isArray(dosenIds) ? dosenIds : [dosenIds];
      }
      await savePengampuPeriode(req.params.id, periodeId, dosenArray);
    }

    mataKuliahCache.delete('all');
    res.redirect(`/admin/matakuliah/${req.params.id}/edit?periode=${periodeId || ''}`);
  } catch (error) {
    console.error('Error update MK:', error);
    res.status(500).send('Gagal update MK: ' + error.message);
  }
});

// ============================================================================
// UPDATE MATERI PER PERTEMUAN
// ============================================================================
router.post('/:id/materi', async (req, res) => {
  try {
    const { pertemuan, topik } = req.body;
    if (!pertemuan || !topik) {
      return res.status(400).send('Pertemuan dan topik harus diisi');
    }

    const mkRef = db.collection('mataKuliah').doc(req.params.id);
    const mkDoc = await mkRef.get();
    if (!mkDoc.exists) return res.status(404).send('MK tidak ditemukan');

    const mkData = mkDoc.data();
    const materi = mkData.materi || [];

    // Pastikan pertemuan dalam range 1-16
    const idx = parseInt(pertemuan) - 1;
    if (idx < 0 || idx >= 16) {
      return res.status(400).send('Pertemuan harus antara 1-16');
    }

    materi[idx] = { pertemuan: parseInt(pertemuan), topik };

    await mkRef.update({ materi });

    mataKuliahCache.delete('all');
    res.redirect(`/admin/matakuliah/${req.params.id}`);
  } catch (error) {
    console.error('Error update materi:', error);
    res.status(500).send('Gagal update materi');
  }
});

// ============================================================================
// HAPUS MATA KULIAH
// ============================================================================
router.post('/:id/delete', async (req, res) => {
  try {
    const mkRef = db.collection('mataKuliah').doc(req.params.id);
    // Periksa apakah MK digunakan di dokumen lain? (tugas, enrollment, dll) – opsional
    // Bisa juga hapus data terkait, tapi untuk sederhana hapus saja
    await mkRef.delete();
    mataKuliahCache.delete('all');
    res.redirect('/admin/matakuliah');
  } catch (error) {
    console.error('Error hapus MK:', error);
    res.status(500).send('Gagal hapus MK: ' + error.message);
  }
});

// ============================================================================
// SEED DATA PDK (Praktik Dunia Kerja) 1, 2, 3
// ============================================================================
/**
 * GET /admin/matakuliah/seed-pdk
 * Menambahkan 3 mata kuliah PDK jika belum ada.
 * Hanya untuk admin, berguna untuk inisialisasi data.
 */
router.get('/seed-pdk', async (req, res) => {
  try {
    // Cek apakah sudah ada mata kuliah dengan kode berawalan "PDK"
    const existing = await db.collection('mataKuliah')
      .where('kode', '>=', 'PDK')
      .where('kode', '<=', 'PDK\uf8ff')
      .get();

    if (!existing.empty) {
      return res.send('Data PDK sudah ada. Tidak perlu ditambahkan lagi.');
    }

    // Data PDK 1,2,3
    const pdkData = [
      { kode: 'PDK101', nama: 'Praktik Dunia Kerja 1', sks: 3, semester: 4 },
      { kode: 'PDK102', nama: 'Praktik Dunia Kerja 2', sks: 3, semester: 5 },
      { kode: 'PDK103', nama: 'Praktik Dunia Kerja 3', sks: 3, semester: 6 }
    ];

    for (const data of pdkData) {
      await db.collection('mataKuliah').add({
        ...data,
        dosenIds: [],
        jadwal: '',
        materi: Array.from({ length: 16 }, (_, i) => ({
          pertemuan: i + 1,
          topik: ''
        })),
        createdAt: new Date().toISOString()
      });
    }

    res.send('Data PDK 1,2,3 berhasil ditambahkan!');
  } catch (error) {
    console.error('Error seeding PDK:', error);
    res.status(500).send('Gagal menambahkan data PDK');
  }
});

module.exports = router;