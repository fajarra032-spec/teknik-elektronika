/**
 * routes/admin/nilai.js
 * Rekap Nilai Seluruh Mata Kuliah (Admin)
 * Menampilkan daftar MK, lalu detail nilai per MK
 */

const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const { filterIdMahasiswaAktif } = require('../../helpers/statusMahasiswaHelper');
const { saveGradeFinal, deleteGradeFinal, getTranskripMahasiswa, getPeriodeAktif, getHasilRubrikSemuaMahasiswa, getHasilRubrikSatuMahasiswa, getRincianTugasByMkId, saveKomponenRubrik, saveNilai, TIPE_RUBRIK_KOMPONEN } = require('../../helpers/nilaiHelper');
const { getAllMataKuliah, getAllMahasiswa } = require('../../helpers/cache');
const { getAngkatanFromNim } = require('../../helpers/academicHelper');

router.use(verifyToken);
router.use(isAdmin);

// ============================================================================
// FUNGSI BANTU
// ============================================================================

/**
 * Mendapatkan data mahasiswa dari UID
 */
async function getMahasiswaById(uid) {
  try {
    const userDoc = await db.collection('users').doc(uid).get();
    if (userDoc.exists) {
      return { id: uid, ...userDoc.data() };
    }
    return { id: uid, nama: 'Unknown', nim: '-' };
  } catch (error) {
    console.error('Error getMahasiswaById:', error);
    return { id: uid, nama: 'Error', nim: '-' };
  }
}

/**
 * Daftar MK untuk dropdown "Pilih Mata Kuliah" di form Input Nilai.
 *
 * getAllMataKuliah() bisa mengembalikan BEBERAPA dokumen dengan `kode` yang
 * sama - itu bukan bug, memang disengaja untuk kelas paralel (mis. WUD3208
 * dipecah jadi dokumen terpisah untuk kelas ELK1A & ELK1B, lihat
 * routes/admin/matakuliah.js). Untuk form ini kelasnya tidak relevan sama
 * sekali: nilai akhir disimpan/di-upsert berdasarkan (userId, kodeMk,
 * semester) saja lewat saveGradeFinal() - TANPA kelas - jadi kalau dropdown
 * ikut menampilkan satu opsi per dokumen, satu MK yang punya 3 kelas
 * paralel akan muncul 3x dengan teks identik ("kelihatan dobel" padahal
 * datanya valid). Di sini kita ambil satu MK per `kode` saja.
 */
function dedupCoursesByKode(semuaMk) {
  const map = new Map();
  semuaMk.forEach(mk => {
    if (mk.kode && !map.has(mk.kode)) map.set(mk.kode, mk);
  });
  return Array.from(map.values());
}

// ============================================================================
// DAFTAR MATA KULIAH
// ============================================================================

/**
 * GET /admin/nilai
 * Menampilkan daftar semua mata kuliah
 */
/**
 * GET /admin/nilai
 * Daftar mata kuliah - pilih satu untuk lihat/edit rekap nilainya.
 */
router.get('/', async (req, res) => {
  try {
    // Data MK diambil dari cache (helpers/cache.js, TTL 10 menit, otomatis
    // di-invalidate saat CRUD di routes/admin/matakuliah.js), lalu difilter
    // dan dipaginasi di memori => 0 read Firestore tambahan per halaman/search.
    const PAGE_SIZE = 10; // sama dengan halaman Kelola Mahasiswa
    const semuaMk = await getAllMataKuliah(db);

    const search = String(req.query.search || '').trim();
    const semester = String(req.query.semester || '').trim();
    const showAll = req.query.all === '1';
    const q = search.toLowerCase();

    const filtered = semuaMk.filter(mk => {
      if (semester && String(mk.semester || '') !== semester) return false;
      if (q) {
        const teks = `${mk.kode || ''} ${mk.nama || ''}`.toLowerCase();
        if (!teks.includes(q)) return false;
      }
      return true;
    });

    const total = filtered.length;
    const buildUrl = (params) => {
      const usp = new URLSearchParams();
      if (search) usp.set('search', search);
      if (semester) usp.set('semester', semester);
      Object.entries(params).forEach(([k, v]) => usp.set(k, v));
      return `/admin/nilai?${usp.toString()}`;
    };

    let mkList = filtered;
    let pageInfo = null;
    if (!showAll) {
      const maxPage = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const page = Math.min(maxPage, Math.max(1, parseInt(req.query.page, 10) || 1));
      const start = (page - 1) * PAGE_SIZE;
      mkList = filtered.slice(start, start + PAGE_SIZE);
      const hasPrev = page > 1;
      const hasNext = start + PAGE_SIZE < total;
      pageInfo = {
        hasPrev,
        hasNext,
        prevUrl: hasPrev ? buildUrl({ page: page - 1 }) : null,
        nextUrl: hasNext ? buildUrl({ page: page + 1 }) : null,
        allUrl: buildUrl({ all: '1' }),
        count: mkList.length,
        total
      };
    }

    res.render('admin/nilai_list', {
      title: 'Rekap Nilai',
      mkList,
      totalMk: total,
      pageInfo,
      showAll,
      pageListUrl: buildUrl({ page: 1 }),
      filters: { search, semester }
    });
  } catch (error) {
    console.error('Error mengambil MK:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat data MK' });
  }
});

// ============================================================================
// NILAI PER MAHASISWA - daftar mahasiswa, lalu per mahasiswa tampil daftar
// MK + nilainya (dikelompokkan per semester).
//
// Beda dengan '/' (rekap nilai per MK): di sini sudut pandangnya mahasiswa.
// Daftar mahasiswa diambil dari cache getAllMahasiswa() (0 read tambahan),
// sedangkan rincian MK & nilai tiap mahasiswa baru diambil ketika barisnya
// dibuka (AJAX ke /mahasiswa/:userId/data) memakai getTranskripMahasiswa()
// yang SAMA dengan KHS/Transkrip - jadi angkanya pasti identik dan kita tidak
// membaca nilai ratusan mahasiswa sekaligus setiap halaman dibuka.
// Didaftarkan SEBELUM '/:mkId' supaya '/mahasiswa' tidak tertelan rute itu.
// ============================================================================

/**
 * GET /admin/nilai/mahasiswa
 * Daftar mahasiswa (filter: cari nama/NIM, angkatan, status) + paginasi.
 */
router.get('/mahasiswa', async (req, res) => {
  try {
    const PAGE_SIZE = 10;
    const search = String(req.query.search || '').trim();
    const angkatan = String(req.query.angkatan || '').trim();
    const statusMahasiswa = String(req.query.statusMahasiswa || '').trim();
    const showAll = req.query.all === '1';
    const q = search.toLowerCase();

    const semua = (await getAllMahasiswa(db))
      .slice()
      .sort((a, b) => String(a.nim || '').localeCompare(String(b.nim || '')));

    const angkatanSet = new Set();
    const filtered = [];
    semua.forEach(m => {
      const ang = getAngkatanFromNim(m.nim);
      if (ang) angkatanSet.add(String(ang));
      if (angkatan && String(ang) !== angkatan) return;
      if (statusMahasiswa && m.statusMahasiswa !== statusMahasiswa) return;
      if (q) {
        const teks = `${m.nama || ''} ${m.nim || ''}`.toLowerCase();
        if (!teks.includes(q)) return;
      }
      filtered.push({
        id: m.id,
        nim: m.nim || '-',
        nama: m.nama || '(tanpa nama)',
        angkatan: ang || '-',
        kelas: m.kelas || '',
        semester: m.semester || '',
        statusMahasiswa: m.statusMahasiswa || ''
      });
    });

    const total = filtered.length;
    const buildUrl = (params) => {
      const usp = new URLSearchParams();
      if (search) usp.set('search', search);
      if (angkatan) usp.set('angkatan', angkatan);
      if (statusMahasiswa) usp.set('statusMahasiswa', statusMahasiswa);
      Object.entries(params).forEach(([k, v]) => usp.set(k, v));
      return `/admin/nilai/mahasiswa?${usp.toString()}`;
    };

    let mahasiswaList = filtered;
    let pageInfo = null;
    if (!showAll) {
      const maxPage = Math.max(1, Math.ceil(total / PAGE_SIZE));
      const page = Math.min(maxPage, Math.max(1, parseInt(req.query.page, 10) || 1));
      const start = (page - 1) * PAGE_SIZE;
      mahasiswaList = filtered.slice(start, start + PAGE_SIZE);
      const hasPrev = page > 1;
      const hasNext = start + PAGE_SIZE < total;
      pageInfo = {
        hasPrev,
        hasNext,
        prevUrl: hasPrev ? buildUrl({ page: page - 1 }) : null,
        nextUrl: hasNext ? buildUrl({ page: page + 1 }) : null,
        allUrl: buildUrl({ all: '1' }),
        count: mahasiswaList.length,
        total
      };
    }

    // Nilai tiap mahasiswa di halaman ini langsung diambil di server (tanpa
    // expand/AJAX). Dibatasi 5 mahasiswa diproses bersamaan supaya Firestore
    // tidak kewalahan, terutama saat mode "Tampilkan Semua".
    const hasilNilai = new Array(mahasiswaList.length);
    let cursor = 0;
    async function worker() {
      while (cursor < mahasiswaList.length) {
        const i = cursor++;
        const m = mahasiswaList[i];
        try {
          const { perSemester, ipk, totalSKS } = await getTranskripMahasiswa(m.id);
          hasilNilai[i] = { ...m, ipk, totalSKS, semesterList: perSemester };
        } catch (err) {
          console.error('Gagal memuat nilai', m.nim, err.message);
          hasilNilai[i] = { ...m, ipk: '0.00', totalSKS: 0, semesterList: [], error: err.message };
        }
      }
    }
    await Promise.all([worker(), worker(), worker(), worker(), worker()]);
    mahasiswaList = hasilNilai;

    res.render('admin/nilai_mahasiswa_list', {
      title: 'Nilai per Mahasiswa',
      mahasiswaList,
      totalMahasiswa: total,
      angkatanList: Array.from(angkatanSet).sort().reverse(),
      pageInfo,
      showAll,
      pageListUrl: buildUrl({ page: 1 }),
      filters: { search, angkatan, statusMahasiswa }
    });
  } catch (error) {
    console.error('Error daftar nilai per mahasiswa:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat daftar mahasiswa: ' + error.message });
  }
});

/**
 * GET /admin/nilai/mahasiswa/:userId/data
 * JSON rincian MK + nilai satu mahasiswa (dipakai saat baris dibuka).
 */
router.get('/mahasiswa/:userId/data', async (req, res) => {
  try {
    const { userId } = req.params;
    const { perSemester, ipk, totalSKS } = await getTranskripMahasiswa(userId);
    res.json({
      success: true,
      ipk,
      totalSKS,
      semester: perSemester.map(s => ({
        semester: s.semester,
        ips: s.ips,
        totalSKS: s.totalSKS,
        totalSKSDiprogram: s.totalSKSDiprogram,
        jumlahBelumNilai: s.jumlahBelumNilai,
        matkul: s.matkul.map(m => ({
          kode: m.kodeMk,
          nama: m.namaMk,
          sks: m.sks,
          nilai: m.nilai,
          huruf: m.huruf,
          indeks: m.indeks,
          belumAdaNilai: m.belumAdaNilai
        }))
      }))
    });
  } catch (error) {
    console.error('Error data nilai mahasiswa:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// ============================================================================
// CETAK SEMUA TRANSKRIP (massal)
// Satu mahasiswa = satu halaman A4, format sama persis dengan transkrip
// mahasiswa (views/mahasiswa/transkrip_print.ejs) dan data dari
// getTranskripMahasiswa() yang sama. Mengikuti filter di halaman "Nilai per
// Mahasiswa" (search, angkatan, statusMahasiswa) - BUKAN hanya halaman yang
// sedang tampil, tapi SEMUA mahasiswa yang cocok dengan filter.
// Mahasiswa yang belum punya satu pun nilai dilewati (kecuali
// ?lewatiKosong=0). Nilai diambil 5 mahasiswa bersamaan.
// ============================================================================

/**
 * GET /admin/nilai/transkrip/cetak-semua?search=&angkatan=&statusMahasiswa=&lewatiKosong=
 */
router.get('/transkrip/cetak-semua', async (req, res) => {
  try {
    const search = String(req.query.search || '').trim();
    const angkatan = String(req.query.angkatan || '').trim();
    const statusMahasiswa = String(req.query.statusMahasiswa || '').trim();
    const lewatiKosong = req.query.lewatiKosong !== '0';
    const q = search.toLowerCase();

    const daftar = (await getAllMahasiswa(db))
      .slice()
      .sort((a, b) => String(a.nim || '').localeCompare(String(b.nim || '')))
      .filter(m => {
        if (angkatan && String(getAngkatanFromNim(m.nim)) !== angkatan) return false;
        if (statusMahasiswa && m.statusMahasiswa !== statusMahasiswa) return false;
        if (q && !`${m.nama || ''} ${m.nim || ''}`.toLowerCase().includes(q)) return false;
        return true;
      });

    const hasil = new Array(daftar.length);
    let cursor = 0;
    async function worker() {
      while (cursor < daftar.length) {
        const i = cursor++;
        const m = daftar[i];
        try {
          const t = await getTranskripMahasiswa(m.id);
          hasil[i] = {
            user: m,
            angkatan: getAngkatanFromNim(m.nim),
            grades: t.items,
            ipk: t.ipk,
            totalSKS: t.totalSKS,
            totalSksIndeks: t.perSemester.reduce((sum, s) => sum + (s.totalSksIndeks || 0), 0),
            adaNilai: t.items.some(it => !it.belumAdaNilai)
          };
        } catch (err) {
          console.error('Gagal memuat transkrip', m.nim, err.message);
          hasil[i] = { user: m, error: err.message };
        }
      }
    }
    await Promise.all([worker(), worker(), worker(), worker(), worker()]);

    const gagal = hasil.filter(h => h.error).map(h => ({ nim: h.user.nim, nama: h.user.nama, error: h.error }));
    const valid = hasil.filter(h => !h.error);
    const transkripList = valid.filter(h => !lewatiKosong || h.adaNilai);
    const dilewati = valid.filter(h => lewatiKosong && !h.adaNilai).map(h => ({ nim: h.user.nim, nama: h.user.nama }));

    const backParams = new URLSearchParams();
    if (search) backParams.set('search', search);
    if (angkatan) backParams.set('angkatan', angkatan);
    if (statusMahasiswa) backParams.set('statusMahasiswa', statusMahasiswa);
    const toggleParams = new URLSearchParams(backParams);
    toggleParams.set('lewatiKosong', lewatiKosong ? '0' : '1');

    res.render('admin/nilai_transkrip_semua', {
      title: 'Cetak Semua Transkrip',
      transkripList,
      dilewati,
      gagal,
      lewatiKosong,
      filters: { search, angkatan, statusMahasiswa },
      backUrl: '/admin/nilai/mahasiswa' + (backParams.toString() ? '?' + backParams.toString() : ''),
      toggleUrl: '/admin/nilai/transkrip/cetak-semua?' + toggleParams.toString()
    });
  } catch (error) {
    console.error('Error cetak semua transkrip:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat transkrip: ' + error.message });
  }
});

// ============================================================================
// INPUT NILAI AKHIR (FINAL) PER MAHASISWA -> koleksi 'grades'
// Sebelumnya view ini (nilai_form.ejs) sudah ada tapi tidak punya rute sama
// sekali, sehingga tidak bisa diakses dan koleksi 'grades' tidak pernah terisi.
// ============================================================================

/**
 * GET /admin/nilai/mahasiswa/:userId/tambah
 * Menampilkan form untuk menambah/mengubah nilai akhir seorang mahasiswa
 */
router.get('/mahasiswa/:userId/tambah', async (req, res) => {
  try {
    const mahasiswa = await getMahasiswaById(req.params.userId);

    const courses = dedupCoursesByKode(await getAllMataKuliah(db));

    const { items, perSemester, ipk, totalSKS } = await getTranskripMahasiswa(req.params.userId);

    // Daftar semester untuk dropdown - gabungan semester yang sudah pernah
    // dipakai mahasiswa ini (dari KRS/enrollment/nilai) + periode aktif saat
    // ini (supaya tetap bisa input nilai untuk semester berjalan meski
    // belum ada histori sama sekali). Ini menggantikan input teks bebas
    // yang sebelumnya rawan typo (bikin data nilai "nyasar" karena string
    // semester tidak persis sama dengan yang dipakai KRS/enrollment).
    const semesterSet = new Set(perSemester.map(s => s.semester));
    semesterSet.add(getPeriodeAktif());
    const semesterOptions = Array.from(semesterSet).sort();

    res.render('admin/nilai_form', {
      title: `Input Nilai - ${mahasiswa.nama || mahasiswa.id}`,
      mahasiswa,
      courses,
      grades: items,
      semesterOptions,
      semesterCetak: perSemester.map(s => s.semester),
      ipk,
      totalSKS,
      success: req.query.success,
      error: req.query.error
    });
  } catch (error) {
    console.error('Error menampilkan form nilai:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat form input nilai' });
  }
});

/**
 * POST /admin/nilai
 * Menyimpan (atau memperbarui, kalau kombinasi mahasiswa+kodeMk+semester
 * sudah ada) nilai akhir mahasiswa ke koleksi 'grades'.
 */
router.post('/', async (req, res) => {
  const { userId, kodeMk, namaMk, sks, nilai, semester } = req.body;
  try {
    const { isNew } = await saveGradeFinal({ userId, kodeMk, namaMk, sks, nilai, semester });
    res.redirect(`/admin/nilai/mahasiswa/${userId}/tambah?success=${isNew ? 'ditambahkan' : 'diperbarui'}`);
  } catch (error) {
    console.error('Error menyimpan nilai akhir:', error);
    const mahasiswa = await getMahasiswaById(userId);
    const courses = dedupCoursesByKode(await getAllMataKuliah(db));
    const { items, perSemester, ipk, totalSKS } = await getTranskripMahasiswa(userId);
    const semesterSet = new Set(perSemester.map(s => s.semester));
    semesterSet.add(getPeriodeAktif());
    res.status(400).render('admin/nilai_form', {
      title: `Input Nilai - ${mahasiswa.nama || mahasiswa.id}`,
      mahasiswa,
      courses,
      grades: items,
      semesterOptions: Array.from(semesterSet).sort(),
      semesterCetak: perSemester.map(s => s.semester),
      ipk,
      totalSKS,
      error: error.message
    });
  }
});

/**
 * POST /admin/nilai/:gradeId/delete
 * Menghapus satu nilai akhir mahasiswa dari koleksi 'grades'.
 * Body: { userId } - dipakai untuk verifikasi kepemilikan & redirect balik
 * ke form input nilai mahasiswa yang sama.
 */
router.post('/:gradeId/delete', async (req, res) => {
  const { gradeId } = req.params;
  const { userId } = req.body;
  try {
    await deleteGradeFinal(gradeId, userId);
    res.redirect(`/admin/nilai/mahasiswa/${userId}/tambah?success=dihapus`);
  } catch (error) {
    console.error('Error menghapus nilai akhir:', error);
    res.redirect(`/admin/nilai/mahasiswa/${userId}/tambah?error=${encodeURIComponent(error.message)}`);
  }
});

// ============================================================================
// CETAK TRANSKRIP & KHS PER MAHASISWA (dibuka dari halaman Input Nilai)
// Memakai ulang view cetak mahasiswa (views/mahasiswa/transkrip_print.ejs &
// views/mahasiswa/khs_detail.ejs) - bedanya cuma `user` diisi data mahasiswa
// yang dipilih admin (bukan req.user) dan tombol "Kembali" diarahkan lagi
// ke halaman Input Nilai lewat `backUrl`. Data tetap dari
// getTranskripMahasiswa() yang sama dengan yang dipakai sisi mahasiswa,
// jadi angka di dokumen cetak admin pasti identik dengan yang dilihat mahasiswa.
// Rute ini didaftarkan SEBELUM '/:mkId' supaya tidak tertelan rute itu.
// ============================================================================

/**
 * Ambil data mahasiswa untuk dokumen cetak. null kalau tidak ada.
 */
async function getMahasiswaUntukCetak(userId) {
  const doc = await db.collection('users').doc(userId).get();
  return doc.exists ? { id: userId, ...doc.data() } : null;
}

/**
 * GET /admin/nilai/mahasiswa/:userId/transkrip/cetak?semester=...
 * Transkrip kumulatif dari semester 1 s.d. semester yang dipilih
 * (default: semester terbaru yang punya data).
 */
router.get('/mahasiswa/:userId/transkrip/cetak', async (req, res) => {
  try {
    const { userId } = req.params;
    const mahasiswa = await getMahasiswaUntukCetak(userId);
    if (!mahasiswa) {
      return res.status(404).render('error', { title: 'Tidak Ditemukan', message: 'Mahasiswa tidak ditemukan' });
    }

    const { perSemester, items, ipk: ipkTotal, totalSKS: totalSKSTotal } = await getTranskripMahasiswa(userId);
    const semesterList = perSemester.map(s => s.semester);
    const semesterDipilih = (req.query.semester && semesterList.includes(req.query.semester))
      ? req.query.semester
      : (semesterList.length > 0 ? semesterList[semesterList.length - 1] : null);

    let grades = items;
    let ipk = ipkTotal;
    let totalSKS = totalSKSTotal;
    let totalSksIndeks = perSemester.reduce((sum, s) => sum + (s.totalSksIndeks || 0), 0);

    if (semesterDipilih) {
      const idx = semesterList.indexOf(semesterDipilih);
      const sampaiSemesterIni = perSemester.slice(0, idx + 1);
      grades = sampaiSemesterIni.flatMap(s => s.matkul);
      let sksKum = 0, bobotKum = 0;
      sampaiSemesterIni.forEach(s => { sksKum += s.totalSKS; bobotKum += s.totalSksIndeks; });
      totalSKS = sksKum;
      totalSksIndeks = bobotKum;
      ipk = sksKum > 0 ? (bobotKum / sksKum).toFixed(2) : '0.00';
    }

    res.render('mahasiswa/transkrip_print', {
      title: `Transkrip - ${mahasiswa.nama || mahasiswa.id}`,
      user: mahasiswa,
      angkatan: getAngkatanFromNim(mahasiswa.nim),
      grades, ipk, totalSKS, totalSksIndeks,
      semesterList, semesterDipilih,
      backUrl: `/admin/nilai/mahasiswa/${encodeURIComponent(userId)}/tambah`
    });
  } catch (error) {
    console.error('Error cetak transkrip (admin):', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat transkrip: ' + error.message });
  }
});

/**
 * GET /admin/nilai/mahasiswa/:userId/khs/cetak?semester=...
 * KHS satu semester (default: semester terbaru yang punya data).
 * Label semester dikirim lewat query string (bukan segmen path) karena
 * mengandung spasi & slash, mis. "Ganjil 2025/2026".
 */
router.get('/mahasiswa/:userId/khs/cetak', async (req, res) => {
  try {
    const { userId } = req.params;
    const mahasiswa = await getMahasiswaUntukCetak(userId);
    if (!mahasiswa) {
      return res.status(404).render('error', { title: 'Tidak Ditemukan', message: 'Mahasiswa tidak ditemukan' });
    }

    const { perSemester, ipk, totalSKS } = await getTranskripMahasiswa(userId);
    if (perSemester.length === 0) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: `Belum ada data nilai untuk ${mahasiswa.nama || 'mahasiswa ini'}, KHS belum bisa dicetak`
      });
    }

    const semesterLabel = req.query.semester || perSemester[perSemester.length - 1].semester;
    const idx = perSemester.findIndex(s => s.semester === semesterLabel);
    if (idx === -1) {
      return res.status(404).render('error', {
        title: 'Tidak Ditemukan',
        message: `Belum ada data nilai untuk ${mahasiswa.nama || 'mahasiswa ini'} pada semester "${semesterLabel}"`
      });
    }
    const khs = perSemester[idx];

    // SKS & IPK kumulatif "s.d. semester ini"
    let sksKum = 0, bobotKum = 0;
    perSemester.slice(0, idx + 1).forEach(s => { sksKum += s.totalSKS; bobotKum += s.totalSksIndeks; });
    const ipkSampaiSemesterIni = sksKum > 0 ? (bobotKum / sksKum).toFixed(2) : '0.00';

    res.render('mahasiswa/khs_detail', {
      title: `KHS - ${mahasiswa.nama || mahasiswa.id} - ${semesterLabel}`,
      user: mahasiswa,
      khs,
      ipkSampaiSemesterIni,
      sksKumulatif: sksKum,
      ipkAkhir: ipk,
      totalSKSAkhir: totalSKS,
      backUrl: `/admin/nilai/mahasiswa/${encodeURIComponent(userId)}/tambah`
    });
  } catch (error) {
    console.error('Error cetak KHS (admin):', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat KHS: ' + error.message });
  }
});

// ============================================================================
// DETAIL NILAI PER MATA KULIAH - bisa diedit langsung dari sini.
// Nilai Akhir dihitung pakai rumus RESMI yang sama dengan Rubrik Penilaian
// (getHasilRubrikSemuaMahasiswa -> hitungRubrik, bobot bisa diatur per
// prodi), BUKAN rumus 40/30/30 tetap yang lama - supaya "Nilai Akhir" yang
// tampil di sini selalu sama persis dengan yang tampil di Rubrik, dan
// mengedit nilai di sini otomatis nyambung ke perhitungan Rubrik juga
// (keduanya baca/tulis koleksi 'nilai' yang sama).
// ============================================================================

/**
 * GET /admin/nilai/:mkId
 * Menampilkan grid nilai (kehadiran/sikap/keaktifan/kuis/UTS/UAS/tugas)
 * semua mahasiswa di MK ini, siap diedit inline.
 */
router.get('/:mkId', async (req, res) => {
  try {
    const mkId = req.params.mkId;
    const periode = req.query.periode || getPeriodeAktif();
    const mkDoc = await db.collection('mataKuliah').doc(mkId).get();
    if (!mkDoc.exists) {
      return res.status(404).render('error', { title: 'Tidak Ditemukan', message: 'Mata kuliah tidak ditemukan' });
    }
    const mk = { id: mkId, ...mkDoc.data() };

    // Semua periode yang PERNAH punya enrollment untuk MK ini (termasuk
    // periode histori, mis. dari input nilai lama lewat script) - dipakai
    // untuk dropdown pemilih periode, supaya admin tidak perlu menebak-nebak
    // atau mengedit URL manual untuk melihat data semester yang sudah lewat.
    const semuaEnrollmentMkSnapshot = await db.collection('enrollment')
      .where('mkId', '==', mkId)
      .where('status', '==', 'active')
      .get();
    const periodeSet = new Set(semuaEnrollmentMkSnapshot.docs.map(d => d.data().semester).filter(Boolean));
    periodeSet.add(getPeriodeAktif()); // selalu sertakan periode aktif sekarang walau belum ada enrollment-nya
    periodeSet.add(periode); // jaga-jaga kalau periode dari URL belum ada di enrollment manapun
    const periodeOptions = Array.from(periodeSet).sort().reverse();

    // Mahasiswa yang terdaftar aktif (KRS disetujui) untuk MK+periode ini
    const enrollmentSnapshot = await db.collection('enrollment')
      .where('mkId', '==', mkId)
      .where('semester', '==', periode)
      .where('status', '==', 'active')
      .get();
    const mahasiswaIds = await filterIdMahasiswaAktif(db, enrollmentSnapshot.docs.map(d => d.data().userId));

    const [{ komponenMap, hasilMap }, { tugasList, perMahasiswa: tugasPerMahasiswa }, mahasiswaArr] = await Promise.all([
      getHasilRubrikSemuaMahasiswa(mkId, periode),
      getRincianTugasByMkId(mkId, periode),
      Promise.all(mahasiswaIds.map(uid => getMahasiswaById(uid)))
    ]);

    const mahasiswaList = mahasiswaIds.map((uid, i) => ({
      mahasiswaId: uid,
      mahasiswa: mahasiswaArr[i],
      komponen: komponenMap[uid] || {},
      tugas: tugasPerMahasiswa[uid] || {},
      hasil: hasilMap[uid] || { nilaiAkhir: null, huruf: null }
    })).sort((a, b) => (a.mahasiswa.nim || '').localeCompare(b.mahasiswa.nim || ''));

    res.render('admin/nilai_detail', {
      title: `Rekap Nilai - ${mk.kode} ${mk.nama} (${periode})`,
      mk,
      mahasiswaList,
      tugasList,
      tipeKomponen: TIPE_RUBRIK_KOMPONEN,
      periode,
      periodeOptions
    });
  } catch (error) {
    console.error('Error detail nilai:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat detail nilai: ' + error.message });
  }
});

/**
 * POST /admin/nilai/:mkId/set
 * Menyimpan SATU nilai komponen (kehadiran/sikap/keaktifan/kuis/UTS/UAS)
 * atau satu nilai tugas, dipanggil lewat AJAX tiap kali admin selesai
 * mengedit satu kotak (auto-save, sama seperti pola di halaman Rubrik).
 * Body: { mahasiswaId, tipe, nilai, periode, judulTugas? }
 * `tipe` = salah satu TIPE_RUBRIK_KOMPONEN (komponen rubrik), ATAU
 * `tugas_<tugasId>` (nilai tugas individual).
 */
router.post('/:mkId/set', async (req, res) => {
  try {
    const mkId = req.params.mkId;
    const { mahasiswaId, tipe, nilai, periode, judulTugas } = req.body;
    if (!mahasiswaId || !tipe || nilai === undefined || nilai === '') {
      return res.status(400).json({ success: false, message: 'Data tidak lengkap' });
    }
    const p = periode || getPeriodeAktif();

    if (TIPE_RUBRIK_KOMPONEN.includes(tipe)) {
      await saveKomponenRubrik(mahasiswaId, mkId, tipe, nilai, p);
    } else if (tipe.startsWith('tugas_')) {
      const tugasId = tipe.replace('tugas_', '');
      await saveNilai(mahasiswaId, mkId, tugasId, judulTugas || 'Tugas', nilai, p);
    } else {
      return res.status(400).json({ success: false, message: 'Tipe nilai tidak dikenali' });
    }

    const hasil = await getHasilRubrikSatuMahasiswa(mahasiswaId, mkId, p);
    res.json({ success: true, hasil });
  } catch (error) {
    console.error('Error menyimpan nilai (grid admin):', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;