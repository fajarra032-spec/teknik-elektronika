// ==================== BANK SOAL (PER PROGRAM) ====================
// Bank soal melekat ke Program (bukan ke kelas), supaya bisa dipakai ulang oleh
// semua kelas yang memakai program yang sama. Admin dan Guru sama-sama bisa
// menambah soal (guru biasanya yang paling paham materi kelasnya).
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdminOrTeacher } = require('../middleware/auth');
const { generateShortId } = require('../utils/helpers');

const router = express.Router();

function backUrlFor(role) {
  return role === 'admin' ? '/admin/programs' : '/teacher/dashboard';
}

// LIST soal dalam bank soal sebuah program
router.get('/programs/:programId/questions', isAdminOrTeacher, async (req, res) => {
  try {
    const progDoc = await db.collection('programs').doc(req.params.programId).get();
    if (!progDoc.exists) return res.status(404).send('Program tidak ditemukan');
    const program = { id: progDoc.id, ...progDoc.data() };

    const snap = await db.collection('questions')
      .where('programId', '==', req.params.programId)
      .orderBy('createdAt', 'desc')
      .get();
    const questions = snap.docs.map(d => ({ id: d.id, ...d.data() }));

    res.render('programs/questions', {
      program, questions, role: req.session.user.role, backUrl: backUrlFor(req.session.user.role),
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil bank soal: ' + err.message);
  }
});

// TAMBAH soal baru (pilihan ganda atau esai)
router.post('/programs/:programId/questions', isAdminOrTeacher, async (req, res) => {
  const { type, question, points, optionA, optionB, optionC, optionD, correctAnswer } = req.body;
  if (!question || !type) {
    return res.redirect(`/programs/${req.params.programId}/questions?error=` + encodeURIComponent('Pertanyaan dan tipe soal wajib diisi'));
  }
  try {
    const data = {
      programId: req.params.programId,
      type, // 'pilihan_ganda' | 'esai'
      question,
      points: parseInt(points) || 10,
      createdBy: req.session.user.uid,
      createdByName: req.session.user.name,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    if (type === 'pilihan_ganda') {
      if (!optionA || !optionB || !optionC || !optionD || correctAnswer === undefined) {
        return res.redirect(`/programs/${req.params.programId}/questions?error=` + encodeURIComponent('Untuk pilihan ganda, 4 opsi dan kunci jawaban wajib diisi'));
      }
      data.options = [optionA, optionB, optionC, optionD];
      data.correctAnswer = parseInt(correctAnswer);
    }
    await db.collection('questions').add(data);
    res.redirect(`/programs/${req.params.programId}/questions?success=` + encodeURIComponent('Soal berhasil ditambahkan ke bank soal'));
  } catch (err) {
    console.error(err);
    res.redirect(`/programs/${req.params.programId}/questions?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS soal
router.post('/programs/:programId/questions/:questionId/delete', isAdminOrTeacher, async (req, res) => {
  try {
    await db.collection('questions').doc(req.params.questionId).delete();
    res.redirect(`/programs/${req.params.programId}/questions?success=` + encodeURIComponent('Soal dihapus dari bank soal'));
  } catch (err) {
    console.error(err);
    res.redirect(`/programs/${req.params.programId}/questions?error=` + encodeURIComponent(err.message));
  }
});

module.exports = router;
