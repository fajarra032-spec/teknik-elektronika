// ==================== DASHBOARD ANALITIK ====================
// Mengumpulkan data dari koleksi yang SUDAH ADA (tidak menyimpan data baru):
// enrollments, programs, classes, class_sessions, invoices, submissions.
// Semua dihitung on-the-fly setiap halaman dibuka supaya selalu akurat/real-time,
// bukan angka yang di-cache dan bisa basi.
const express = require('express');
const { db } = require('../config/firebase');
const { isAdmin } = require('../middleware/auth');

const router = express.Router();

const MONTH_LABELS = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];

// Ambil 6 bulan terakhir (termasuk bulan ini) sebagai label & key "YYYY-M"
function last6Months() {
  const result = [];
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    result.push({ key: `${d.getFullYear()}-${d.getMonth()}`, label: MONTH_LABELS[d.getMonth()] + ' ' + String(d.getFullYear()).slice(2) });
  }
  return result;
}

router.get('/admin/analytics', isAdmin, async (req, res) => {
  try {
    const months = last6Months();
    const monthIndex = {};
    months.forEach(m => monthIndex[m.key] = 0);

    // ---------- Siswa per Program (dari enrollments) ----------
    const enrollSnap = await db.collection('enrollments').get();
    const programCount = {};
    const registrationsPerMonth = { ...monthIndex };
    for (const doc of enrollSnap.docs) {
      const e = doc.data();
      programCount[e.programId] = (programCount[e.programId] || 0) + 1;
      if (e.enrolledAt && e.enrolledAt.toDate) {
        const d = e.enrolledAt.toDate();
        const key = `${d.getFullYear()}-${d.getMonth()}`;
        if (key in registrationsPerMonth) registrationsPerMonth[key]++;
      }
    }
    const programsSnap = await db.collection('programs').get();
    const studentsPerProgram = programsSnap.docs.map(d => ({
      name: d.data().name,
      count: programCount[d.id] || 0
    })).filter(p => p.count > 0).sort((a, b) => b.count - a.count);

    // ---------- Pendapatan per bulan (dari invoices berstatus paid) ----------
    const invoicesSnap = await db.collection('invoices').get();
    const revenuePerMonth = { ...monthIndex };
    let totalRevenue = 0, totalOutstanding = 0, countPaid = 0, countUnpaid = 0, countOverdue = 0;
    invoicesSnap.forEach(doc => {
      const inv = doc.data();
      const isOverdue = inv.status !== 'paid' && inv.dueDate && new Date(inv.dueDate) < new Date();
      if (inv.status === 'paid') {
        countPaid++;
        totalRevenue += inv.amount || 0;
        if (inv.paidAt && inv.paidAt.toDate) {
          const d = inv.paidAt.toDate();
          const key = `${d.getFullYear()}-${d.getMonth()}`;
          if (key in revenuePerMonth) revenuePerMonth[key] += (inv.amount || 0);
        }
      } else {
        totalOutstanding += inv.amount || 0;
        if (isOverdue) countOverdue++; else countUnpaid++;
      }
    });

    // ---------- Rata-rata kehadiran per kelas ----------
    const classesSnap = await db.collection('classes').get();
    const sessionsSnap = await db.collection('class_sessions').get();
    const sessionsByClass = {};
    sessionsSnap.forEach(doc => {
      const s = doc.data();
      if (!sessionsByClass[s.classId]) sessionsByClass[s.classId] = [];
      sessionsByClass[s.classId].push(s);
    });
    const attendanceByClass = [];
    for (const doc of classesSnap.docs) {
      const cls = doc.data();
      const sessions = sessionsByClass[doc.id] || [];
      let hadir = 0, total = 0;
      sessions.forEach(s => {
        const values = Object.values(s.attendance || {});
        total += values.length;
        hadir += values.filter(v => v.status === 'hadir').length;
      });
      if (total > 0) {
        attendanceByClass.push({ name: cls.name, percentage: Math.round((hadir / total) * 100) });
      }
    }
    attendanceByClass.sort((a, b) => b.percentage - a.percentage);
    const overallAttendance = attendanceByClass.length === 0 ? 0 :
      Math.round(attendanceByClass.reduce((s, c) => s + c.percentage, 0) / attendanceByClass.length);

    // ---------- Rata-rata nilai Tugas/Quiz/CBT (dari submissions yang sudah dinilai) ----------
    const submissionsSnap = await db.collection('submissions').where('status', '==', 'dinilai').get();
    let totalScore = 0, scoredCount = 0;
    submissionsSnap.forEach(doc => {
      const s = doc.data();
      if (typeof s.score === 'number') { totalScore += s.score; scoredCount++; }
    });
    const avgAssignmentScore = scoredCount === 0 ? 0 : Math.round(totalScore / scoredCount);

    // ---------- Ringkasan umum ----------
    const totalStudents = (await db.collection('users').where('role', '==', 'user').get()).size;
    const totalTeachers = (await db.collection('users').where('role', '==', 'teacher').get()).size;
    const totalClasses = classesSnap.size;

    res.render('admin/analytics', {
      monthLabels: months.map(m => m.label),
      registrationsPerMonth: months.map(m => registrationsPerMonth[m.key]),
      revenuePerMonth: months.map(m => revenuePerMonth[m.key]),
      studentsPerProgram,
      attendanceByClass,
      overallAttendance,
      avgAssignmentScore,
      totalRevenue, totalOutstanding, countPaid, countUnpaid, countOverdue,
      totalStudents, totalTeachers, totalClasses
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal membuat dashboard analitik: ' + err.message);
  }
});

module.exports = router;
