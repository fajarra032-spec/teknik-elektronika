// ==================== ROUTES TEACHER (GURU) ====================
const express = require('express');
const { db } = require('../config/firebase');
const { isTeacher } = require('../middleware/auth');

const router = express.Router();

// Dashboard guru: daftar kelas yang diampu + ringkasan tugas yang perlu dinilai
router.get('/teacher/dashboard', isTeacher, async (req, res) => {
  try {
    const snapshot = await db.collection('classes').where('teacherId', '==', req.session.user.uid).get();
    const classes = [];
    let totalPendingGrading = 0;
    for (const doc of snapshot.docs) {
      const cls = { id: doc.id, ...doc.data() };
      const progDoc = await db.collection('programs').doc(cls.programId).get();
      cls.programName = progDoc.exists ? progDoc.data().name : '(program dihapus)';
      cls.studentCount = (cls.studentIds || []).length;

      // Hitung tugas (esai) yang statusnya "dikumpulkan" tapi belum dinilai guru
      const asgSnap = await db.collection('assignments').where('classId', '==', cls.id).where('type', '==', 'tugas').get();
      let pendingForClass = 0;
      for (const aDoc of asgSnap.docs) {
        const subsSnap = await db.collection('submissions').where('assignmentId', '==', aDoc.id).where('status', '==', 'dikumpulkan').get();
        pendingForClass += subsSnap.size;
      }
      cls.pendingGrading = pendingForClass;
      totalPendingGrading += pendingForClass;

      // Rata-rata kehadiran kelas ini (dari class_sessions)
      const sessSnap = await db.collection('class_sessions').where('classId', '==', cls.id).get();
      let hadirCount = 0, totalRecorded = 0;
      sessSnap.forEach(sDoc => {
        const values = Object.values(sDoc.data().attendance || {});
        totalRecorded += values.length;
        hadirCount += values.filter(v => v.status === 'hadir').length;
      });
      cls.attendancePercentage = totalRecorded === 0 ? null : Math.round((hadirCount / totalRecorded) * 100);

      classes.push(cls);
    }
    const classesWithAttendance = classes.filter(c => c.attendancePercentage !== null);
    const avgAttendance = classesWithAttendance.length === 0 ? null :
      Math.round(classesWithAttendance.reduce((s, c) => s + c.attendancePercentage, 0) / classesWithAttendance.length);

    // Ambil foto profil guru sendiri, untuk ditampilkan di header dashboard
    const teacherDoc = await db.collection('users').doc(req.session.user.uid).get();
    const myPhotoUrl = teacherDoc.exists ? (teacherDoc.data().photoUrl || null) : null;

    res.render('teacher/dashboard', { user: req.session.user, classes, totalPendingGrading, avgAttendance, myPhotoUrl });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil data kelas: ' + err.message);
  }
});

// Detail kelas milik guru: daftar siswa + materi (dari program)
router.get('/teacher/classes/:id', isTeacher, async (req, res) => {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.id).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };
    if (cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }
    const progDoc = await db.collection('programs').doc(cls.programId).get();
    const program = progDoc.exists ? { id: progDoc.id, ...progDoc.data() } : null;

    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }
    res.render('teacher/class-detail', { user: req.session.user, cls, program, students });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil detail kelas: ' + err.message);
  }
});

module.exports = router;
