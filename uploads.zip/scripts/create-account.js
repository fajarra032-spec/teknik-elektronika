// ==================== BUAT AKUN: ADMIN / GURU / SISWA ====================
// Jalankan interaktif (akan tanya satu-satu):
//   node scripts/create-account.js
//   npm run create-account
//
// Atau langsung lewat argumen (tanpa tanya-jawab, cocok untuk skrip otomatis):
//   node scripts/create-account.js --role=admin --username=admin1 --name="Nama Admin" --password=passwordAman123
//   node scripts/create-account.js --role=teacher --username=bugur1 --name="Bu Guru" --password=passwordAman123 --email=guru@sekolah.com
//   node scripts/create-account.js --role=user --username=budi1 --name="Budi" --password=passwordAman123
//
// Catatan:
// - role "user" = siswa (sesuai penamaan role di seluruh aplikasi ini)
// - LOGIN SEKARANG PAKAI USERNAME + PASSWORD (bukan email lagi). Email bersifat
//   opsional, cuma disimpan sebagai catatan kontak.
// - Tidak ada lagi pendaftaran akun sendiri (self-register) — semua akun WAJIB
//   dibuat lewat script ini (atau menu admin terkait).
require('dotenv').config();
const readline = require('readline');
const { db, admin } = require('../config/firebase');

const VALID_ROLES = ['admin', 'teacher', 'user'];
const ROLE_LABEL = { admin: 'Admin', teacher: 'Guru/Pengajar', user: 'Siswa' };

function parseArgs() {
  const args = {};
  for (const raw of process.argv.slice(2)) {
    const m = raw.match(/^--([a-zA-Z]+)=(.*)$/);
    if (m) args[m[1]] = m[2];
  }
  return args;
}

function ask(rl, question) {
  return new Promise((resolve) => rl.question(question, (answer) => resolve(answer.trim())));
}

// Sembunyikan input password di terminal (tampilkan * saja) supaya tidak
// kelihatan orang lain saat mengetik lewat SSH.
function askHidden(rl, question) {
  return new Promise((resolve) => {
    const stdin = process.stdin;
    process.stdout.write(question);
    let input = '';
    const onData = (char) => {
      char = char.toString('utf8');
      if (char === '\n' || char === '\r' || char === '\u0004') {
        stdin.setRawMode(false);
        stdin.pause();
        stdin.removeListener('data', onData);
        process.stdout.write('\n');
        resolve(input);
        return;
      }
      if (char === '\u0003') { process.exit(1); } // Ctrl+C
      if (char === '\u007f' || char === '\b') { // backspace
        if (input.length > 0) {
          input = input.slice(0, -1);
          process.stdout.write('\b \b');
        }
        return;
      }
      input += char;
      process.stdout.write('*');
    };
    stdin.setRawMode(true);
    stdin.resume();
    stdin.on('data', onData);
  });
}

async function main() {
  const argv = parseArgs();
  let { role, name, username, email, password } = argv;

  const isInteractive = !(role && name && username && password);
  let rl = null;
  if (isInteractive) {
    rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    console.log('\n==================== BUAT AKUN BARU ====================');
  }

  try {
    if (!role) {
      const answer = (await ask(rl, 'Peran akun — admin / teacher (guru) / user (siswa): ')).toLowerCase();
      role = answer;
    }
    role = String(role).toLowerCase();
    if (!VALID_ROLES.includes(role)) {
      console.error(`\n❌ Peran tidak valid: "${role}". Pilih salah satu: ${VALID_ROLES.join(', ')}`);
      process.exit(1);
    }

    if (!name) name = await ask(rl, 'Nama lengkap: ');
    if (!name) { console.error('\n❌ Nama tidak boleh kosong.'); process.exit(1); }

    if (!username) username = await ask(rl, 'Username untuk login (huruf/angka, tanpa spasi): ');
    username = String(username || '').trim().toLowerCase().replace(/\s+/g, '');
    if (!username || !/^[a-z0-9_.\-]+$/.test(username)) {
      console.error('\n❌ Username tidak valid. Gunakan huruf/angka/underscore/titik/strip, tanpa spasi.');
      process.exit(1);
    }

    if (email === undefined && isInteractive) {
      email = await ask(rl, 'Email (opsional, boleh dikosongkan): ');
    }
    email = email || null;

    if (!password) {
      password = isInteractive ? await askHidden(rl, 'Password (min. 6 karakter): ') : undefined;
    }
    if (!password || password.length < 6) {
      console.error('\n❌ Password minimal 6 karakter.');
      process.exit(1);
    }

    if (rl) rl.close();

    console.log(`\nMembuat akun ${ROLE_LABEL[role]} untuk "${name}" (username: ${username}) ...`);

    const userRecord = await admin.auth().createUser({ username, email, password, displayName: name });
    await db.collection('users').doc(userRecord.uid).update({ role, status: 'active' });

    console.log('\n✅ Akun berhasil dibuat!');
    console.log(`   Peran    : ${ROLE_LABEL[role]}`);
    console.log(`   Nama     : ${name}`);
    console.log(`   Username : ${username}`);
    if (email) console.log(`   Email    : ${email}`);
    console.log(`   User ID  : ${userRecord.uid}`);
    console.log('\nAkun ini sudah bisa langsung dipakai untuk login di halaman /login (pakai USERNAME, bukan email).\n');
    process.exit(0);
  } catch (err) {
    if (rl) rl.close();
    if (err.code === 'auth/username-already-exists') {
      console.error(`\n❌ Gagal: username "${username}" sudah dipakai. Coba username lain.`);
    } else if (err.code === 'auth/email-already-exists') {
      console.error(`\n❌ Gagal: email "${email}" sudah terdaftar di akun lain.`);
    } else {
      // Ditulis selengkap mungkin (kode, pesan, sqlMessage kalau ada, dan stack)
      // supaya kalau errornya "kosong" (mis. masalah koneksi database), tetap
      // ada petunjuk penyebabnya di terminal.
      console.error('\n❌ Gagal membuat akun.');
      console.error('   code       :', err.code || '(tidak ada)');
      console.error('   message    :', err.message || '(kosong)');
      if (err.sqlMessage) console.error('   sqlMessage :', err.sqlMessage);
      if (err.errno) console.error('   errno      :', err.errno);
      console.error('\n--- detail teknis (stack) ---');
      console.error(err.stack || err);
      console.error('\nKemungkinan penyebab paling umum:');
      console.error('  1. MariaDB belum jalan -> cek: systemctl status mariadb');
      console.error('  2. File .env tidak ada / DB_* salah di folder project ini');
      console.error('  3. User/password MariaDB di .env tidak cocok dengan yang dibuat di database');
    }
    process.exit(1);
  }
}

main();

