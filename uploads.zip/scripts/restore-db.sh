#!/bin/bash
# ==================== RESTORE DATABASE DARI BACKUP ====================
# Cara pakai: bash scripts/restore-db.sh /path/ke/nama-file-backup.sql.gz
#
# PERINGATAN: ini akan MENIMPA seluruh isi database yang sekarang dengan isi
# dari file backup. Data yang belum sempat di-backup akan HILANG. Pastikan
# yakin sebelum lanjut — script ini akan minta konfirmasi dulu.

set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Cara pakai: bash scripts/restore-db.sh /path/ke/backup.sql.gz"
  echo ""
  echo "Daftar backup yang tersedia:"
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
  find "$PROJECT_ROOT" -maxdepth 3 -name "*.sql.gz" 2>/dev/null | sort
  exit 1
fi

BACKUP_FILE="$1"
if [ ! -f "$BACKUP_FILE" ]; then
  echo "❌ File backup tidak ditemukan: $BACKUP_FILE"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
ENV_FILE="$PROJECT_ROOT/.env"

DB_HOST=$(grep -E '^DB_HOST=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_PORT=$(grep -E '^DB_PORT=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_USER=$(grep -E '^DB_USER=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_PASSWORD=$(grep -E '^DB_PASSWORD=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_NAME=$(grep -E '^DB_NAME=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_PORT="${DB_PORT:-3306}"

echo "⚠️  Ini akan MENIMPA seluruh data di database '$DB_NAME' dengan isi dari:"
echo "    $BACKUP_FILE"
read -p "Yakin lanjut? Ketik 'YA' untuk konfirmasi: " CONFIRM
if [ "$CONFIRM" != "YA" ]; then
  echo "Dibatalkan."
  exit 0
fi

echo "📥 Memulihkan database ..."
gunzip -c "$BACKUP_FILE" | mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASSWORD" "$DB_NAME"
echo "✅ Restore selesai. Restart aplikasinya: pm2 restart english-course"
