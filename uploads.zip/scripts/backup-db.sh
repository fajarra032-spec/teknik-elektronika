#!/bin/bash
# ==================== BACKUP OTOMATIS DATABASE MARIADB ====================
# Cara pakai manual: bash scripts/backup-db.sh
# Cara pakai otomatis (disarankan): daftarkan lewat cron, lihat instruksi di
# bagian bawah file ini / di MIGRATION_STATUS.md.
#
# Backup disimpan sebagai file .sql.gz (dikompres) di folder BACKUP_DIR, dengan
# nama menyertakan tanggal+jam. Backup yang lebih tua dari RETENTION_DAYS hari
# otomatis dihapus supaya tidak memenuhi storage.

set -euo pipefail

# ---- Baca konfigurasi dari .env di root project ----
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
ENV_FILE="$PROJECT_ROOT/.env"

if [ ! -f "$ENV_FILE" ]; then
  echo "❌ File .env tidak ditemukan di $ENV_FILE"
  exit 1
fi

# Ambil nilai DB_* dari .env tanpa meng-export semuanya (aman dari baris lain di .env)
DB_HOST=$(grep -E '^DB_HOST=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_PORT=$(grep -E '^DB_PORT=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_USER=$(grep -E '^DB_USER=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_PASSWORD=$(grep -E '^DB_PASSWORD=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_NAME=$(grep -E '^DB_NAME=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r')
DB_PORT="${DB_PORT:-3306}"

if [ -z "${DB_USER:-}" ] || [ -z "${DB_NAME:-}" ]; then
  echo "❌ DB_USER / DB_NAME belum diisi di .env — cek dulu konfigurasinya."
  exit 1
fi

# ---- Lokasi backup: pakai UPLOAD_DIR (storage eksternal) kalau ada, biar
#      backup juga tidak menumpuk di eMMC internal ----
UPLOAD_DIR_VAL=$(grep -E '^UPLOAD_DIR=' "$ENV_FILE" | tail -1 | cut -d '=' -f2- | tr -d '\r' || true)
if [ -n "${UPLOAD_DIR_VAL:-}" ]; then
  BACKUP_DIR="$(dirname "$UPLOAD_DIR_VAL")/db-backups"
else
  BACKUP_DIR="$PROJECT_ROOT/db-backups"
fi
RETENTION_DAYS=7

mkdir -p "$BACKUP_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUT_FILE="$BACKUP_DIR/${DB_NAME}_${TIMESTAMP}.sql.gz"

echo "📦 Backup database '$DB_NAME' ke $OUT_FILE ..."
mysqldump -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" | gzip > "$OUT_FILE"

SIZE=$(du -h "$OUT_FILE" | cut -f1)
echo "✅ Backup selesai ($SIZE)"

# ---- Hapus backup yang lebih tua dari RETENTION_DAYS hari ----
DELETED=$(find "$BACKUP_DIR" -name "${DB_NAME}_*.sql.gz" -mtime +"$RETENTION_DAYS" -print -delete | wc -l)
if [ "$DELETED" -gt 0 ]; then
  echo "🗑️  Menghapus $DELETED backup lama (>$RETENTION_DAYS hari)"
fi

echo "Selesai. Backup tersimpan di: $BACKUP_DIR"

# ============================================================
# CARA MENJADWALKAN OTOMATIS (CRON) — jalankan sekali di server:
#
#   crontab -e
#
# Lalu tambahkan baris ini (backup tiap hari jam 2 pagi):
#
#   0 2 * * * /bin/bash /root/english-course/scripts/backup-db.sh >> /root/english-course/db-backups/backup.log 2>&1
#
# (sesuaikan path /root/english-course dengan lokasi project kamu yang sebenarnya)
# ============================================================
