# Modul SOP Prodi - cara pasang

Zip ini sudah berisi semua file dengan struktur folder yang sama dengan proyek Anda, termasuk 3 file yang sudah diedit (menu dan route sudah terpasang).

## Opsi A - timpa langsung (paling cepat)
Syarat: app.js, views/partials/header.ejs, dan views/partials/header-landing.ejs di server Anda masih sama dengan yang ada di routes.zip yang Anda kirim.
1. Ekstrak zip ini ke folder proyek dan setuju menimpa 3 file tersebut.
2. Restart aplikasi.

## Opsi B - aman bila 3 file itu sudah Anda ubah sendiri
1. Ekstrak zip ke folder proyek, tetapi JANGAN menimpa app.js, header.ejs, header-landing.ejs.
2. Jalankan: node scripts/pasang-menu-sop.js  (menambah 2 baris di app.js dan 2 tautan menu; membuat cadangan .bak; aman diulang)
3. Restart aplikasi.

## Hasilnya
- Menu admin: Layanan > Buku Induk SOP (halaman /admin/sop)
- Menu publik: Layanan > Dokumen > Semua SOP Prodi (halaman /sop)
- Unduh Word: /sop/SOP-TE-021/docx dan /sop/SOP-TE-023/docx

## File baru
data/sop/*, helpers/sopDocx.js, routes/sop.js, routes/admin/sop.js, views/sop/*, views/admin/sop/index.ejs, scripts/pasang-menu-sop.js

## Data Firestore
Koleksi baru sop_status (otomatis dibuat saat admin menekan Simpan). Tidak perlu index baru.

## Menambah SOP baru
Salin data/sop/detail/sop-te-021.js menjadi sop-te-0XX.js, ubah kode (harus ada di master.js) dan isinya, restart.

## Perlu diputuskan sebelum disahkan
Lihat bagian konfirmasi di tiap file detail (juga tampil bagi admin di halaman SOP). Terpenting: bobot nilai akhir magang (sistem 50:50 dua komponen vs halaman pedoman 3 komponen).

## Pembaruan 14 November 2026
SOP baru: SOP-TE-002 (KRS) dan SOP-TE-012 (Penyelesaian Studi). Bila modul sudah terpasang, cukup salin folder data/sop (master.js dan detail/*.js) lalu restart; tidak ada file lain yang berubah.

## Pembaruan 14 November 2026 (2)
SOP baru: SOP-TE-029 (Persuratan Mahasiswa) dan SOP-TE-033 (Penugasan Mengajar dan Penerbitan SK; akses internal dosen/admin). Bila modul sudah terpasang, cukup salin folder data/sop lalu restart.

## Pembaruan 14 November 2026 (3)
SOP baru: SOP-TE-016 (Peminjaman dan Pengembalian Alat Laboratorium) dan SOP-TE-046 (Koreksi dan Perubahan Data Akademik; akses internal dosen/admin). Bila modul sudah terpasang, cukup salin folder data/sop lalu restart.

## Pembaruan 14 November 2026 (4)
SOP baru: SOP-TE-043 (Tracer Study dan Kepuasan Pengguna Lulusan) dan SOP-TE-045 (Backup dan Keamanan Data; akses internal dosen/admin). Bila modul sudah terpasang, cukup salin folder data/sop lalu restart.

## Pembaruan 14 November 2026 (5)
SOP baru: SOP-TE-041 (Pengendalian Dokumen dan Arsip) dan SOP-TE-042 (Pengumpulan Data dan Bukti Akreditasi; akses internal dosen/admin). Bila modul sudah terpasang, cukup salin folder data/sop lalu restart.

## Pembaruan 14 November 2026 (6)
SOP baru: SOP-TE-015 (Penggunaan Lab, Praktikum, dan Modul/LKM) dan SOP-TE-019 (K3, Kecelakaan, Limbah Elektronik). Buku Induk (master.js) diperbarui: modul inspeksi dan servisan ternyata kegiatan PkM (bukan K3/lab), sehingga SOP-TE-017 menjadi Penanganan Kerusakan Alat Laboratorium dan servisan dan inspeksi dipindah ke SOP-TE-036. Bila modul sudah terpasang, cukup salin folder data/sop lalu restart.

## Pembaruan 14 November 2026 (7)
SOP baru: SOP-TE-006 (Pelaporan Nilai dan Revisi Nilai), SOP-TE-022 (Magang Luar Negeri), SOP-TE-024 (Penanganan Masalah Magang). Perubahan lain: data/sop/index.js (SOP-TE-006 kini memakai halaman detail baru, halaman lama menjadi rujukan) dan views/sop/detail.ejs (menampilkan bagian Rujukan Terkait). Bila modul sudah terpasang, salin folder data/sop dan views/sop lalu restart.

## Pembaruan 14 November 2026 (8)
SOP baru: SOP-TE-005 (UTS dan UAS), SOP-TE-009 (Pembimbingan Akademik dan Monitoring Masa Studi), SOP-TE-010 (Cuti Akademik dan Aktif Kembali). Bila modul sudah terpasang, cukup salin folder data/sop lalu restart.
