// ==================== KONFIGURASI "FIREBASE" (SEKARANG: MARIADB) ====================
// PENTING — v3.0 Migrasi MariaDB:
// File ini DULU menginisialisasi Firebase Admin SDK (Firestore + Firebase Auth).
// Sekarang server ini jalan di Armbian/STB lokal tanpa koneksi ke Google Cloud,
// jadi `db` dan `admin` di file ini adalah lapisan kompatibilitas yang meniru
// API Firestore/Firebase Auth persis, tapi datanya betul-betul tersimpan di
// MariaDB lokal (lihat config/db.js dan config/firestoreCompat.js).
//
// Kenapa exportnya dipertahankan sama (`admin`, `db`, `firebaseClientConfig`)?
// Supaya SEMUA route lain (yang melakukan `const { db, admin } = require('../config/firebase')`)
// tetap berjalan tanpa perlu diubah satu per satu — hanya "otak" di baliknya yang berpindah
// dari Firestore ke MariaDB.
const { db, admin } = require('./firestoreCompat');

// firebaseClientConfig dipertahankan sebagai objek kosong untuk kompatibilitas
// mundur (beberapa view lama masih mereferensikannya). Login & register sekarang
// memakai form biasa (bcrypt + session), BUKAN lagi Firebase Client SDK di browser.
const firebaseClientConfig = {};

module.exports = { admin, db, firebaseClientConfig };
