// ==================== KONEKSI MARIADB (TERPUSAT) ====================
// Menggantikan Firestore (config/firebase.js versi lama). Semua modul lain
// TIDAK langsung memakai file ini — mereka tetap memakai `db`/`admin` dari
// config/firebase.js, yang sekarang jadi "wajah" Firestore-compatible di atas
// pool MariaDB ini (lihat config/firestoreCompat.js).
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'merah_putih_ils',
  waitForConnections: true,
  // Server STB/Armbian RAM & CPU terbatas — koneksi dibatasi kecil supaya tidak
  // membebani MariaDB. Cukup untuk trafik sekolah bahasa skala kecil-menengah.
  connectionLimit: 8,
  queueLimit: 0,
  charset: 'utf8mb4_unicode_ci'
});

// Cache nama tabel yang sudah dipastikan ada, supaya tidak mengirim
// "CREATE TABLE IF NOT EXISTS" berulang-ulang di setiap query (hemat round-trip
// di board dengan CPU terbatas).
const knownTables = new Set();

/**
 * Pastikan tabel untuk sebuah "collection" (gaya Firestore) sudah ada.
 * Semua collection punya struktur SAMA & generik: id + data (JSON) + created_at.
 * Ini yang memungkinkan compat layer bekerja generik untuk semua modul tanpa
 * perlu skema berbeda-beda per fitur.
 */
async function ensureTable(name) {
  if (knownTables.has(name)) return;
  // Nama tabel divalidasi ketat (hanya huruf/angka/underscore) supaya query
  // DDL di bawah ini aman dari SQL injection meskipun namanya interpolasi string.
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name)) {
    throw new Error(`Nama collection tidak valid: ${name}`);
  }
  await pool.query(
    `CREATE TABLE IF NOT EXISTS \`${name}\` (
      id VARCHAR(191) NOT NULL PRIMARY KEY,
      data JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
  );
  knownTables.add(name);
}

module.exports = { pool, ensureTable };
