// ==================== FIRESTORE-COMPATIBLE LAYER DI ATAS MARIADB ====================
// Tujuan file ini: meniru API Firestore versi Admin SDK (db.collection().where()...,
// admin.firestore.FieldValue, admin.auth()) TAPI datanya betul-betul disimpan di MariaDB.
//
// Kenapa begini (bukan menulis ulang query SQL di 20 file route satu-satu)?
// - Semua route (admin, teacher, siswa, chat, dst) sudah konsisten memakai pola
//   `db.collection('x').where(...).get()`, `doc.data()`, `FieldValue.serverTimestamp()`, dst.
// - Dengan meniru API itu persis, migrasi ke MariaDB tidak perlu mengubah logika bisnis
//   di setiap file — cukup ganti "otaknya" di satu tempat (file ini + config/firebase.js).
// - Ini jauh lebih aman untuk sistem yang sudah kompleks: risiko bug jauh lebih kecil
//   dibanding menulis ulang ratusan query SQL secara manual sekaligus.
//
// Setiap "collection" Firestore menjadi SATU TABEL generik di MariaDB:
//   id VARCHAR(191) PRIMARY KEY, data JSON, created_at, updated_at
// Filter (.where), urutan (.orderBy) dan limit (.limit) diproses di JavaScript
// (bukan di SQL) supaya semantiknya PERSIS sama dengan Firestore (perbandingan tipe,
// array-contains, dst) tanpa harus berurusan dengan kerumitan dialek JSON SQL.
// Untuk skala sekolah bahasa (ratusan-ribuan baris per tabel), full-scan di memori
// ini cepat dan jauh lebih murah CPU-nya dibanding overhead query JSON bertingkat.

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { pool, ensureTable } = require('./db');

// ---------------------------------------------------------------------------
// Helper: tandai object Date supaya selamat lewat JSON.stringify/parse, dan
// bisa "dihidupkan lagi" jadi Date asli (dengan method .toDate() ala Firestore
// Timestamp) waktu dibaca kembali. ContraSTB: field seperti createdAt/startDate
// sering dipakai dengan pola `field.toDate()` di kode lama — supaya kode itu
// TIDAK perlu diubah, kita bikin hasil revive-nya adalah Date sungguhan yang
// juga punya method .toDate().
// ---------------------------------------------------------------------------
function markDates(value) {
  if (value instanceof Date) return { __ts: true, iso: value.toISOString() };
  if (Array.isArray(value)) return value.map(markDates);
  if (value && typeof value === 'object') {
    const out = {};
    for (const k of Object.keys(value)) out[k] = markDates(value[k]);
    return out;
  }
  return value;
}

function reviveDates(key, value) {
  if (value && typeof value === 'object' && value.__ts === true && typeof value.iso === 'string') {
    const d = new Date(value.iso);
    d.toDate = () => new Date(value.iso);
    return d;
  }
  return value;
}

function toJsonStorage(obj) {
  return JSON.stringify(markDates(obj || {}));
}

function fromJsonStorage(str) {
  if (str === null || str === undefined) return {};
  const parsed = typeof str === 'string' ? JSON.parse(str) : str;
  return JSON.parse(JSON.stringify(parsed), reviveDates);
}

function newId() {
  return crypto.randomUUID();
}

// ---------------------------------------------------------------------------
// Sentinel values ala admin.firestore.FieldValue — dikenali secara khusus
// oleh DocRef.update()/set() waktu memproses field.
// ---------------------------------------------------------------------------
class ArrayUnionSentinel { constructor(values) { this.values = values; } }
class ArrayRemoveSentinel { constructor(values) { this.values = values; } }
class IncrementSentinel { constructor(n) { this.n = n; } }

const FieldValue = {
  serverTimestamp: () => new Date(),
  arrayUnion: (...values) => new ArrayUnionSentinel(values),
  arrayRemove: (...values) => new ArrayRemoveSentinel(values),
  increment: (n) => new IncrementSentinel(n)
};

// Terapkan semantik FieldValue di atas objek data existing (raw, belum di-revive
// Date-nya) + partial baru dari pemanggil .update()/.set().
function applyFieldValues(existingRaw, partial) {
  const result = { ...partial };
  for (const key of Object.keys(partial)) {
    const val = partial[key];
    if (val instanceof ArrayUnionSentinel) {
      const current = Array.isArray(existingRaw[key]) ? existingRaw[key].map(v => (v && v.__ts ? v : v)) : [];
      const currentPlain = Array.isArray(existingRaw[key]) ? existingRaw[key] : [];
      const merged = [...currentPlain];
      for (const v of val.values) {
        if (!merged.some(m => JSON.stringify(m) === JSON.stringify(v))) merged.push(v);
      }
      result[key] = merged;
    } else if (val instanceof ArrayRemoveSentinel) {
      const currentPlain = Array.isArray(existingRaw[key]) ? existingRaw[key] : [];
      result[key] = currentPlain.filter(m => !val.values.some(v => JSON.stringify(v) === JSON.stringify(m)));
    } else if (val instanceof IncrementSentinel) {
      const base = typeof existingRaw[key] === 'number' ? existingRaw[key] : 0;
      result[key] = base + val.n;
    } else if (val instanceof Date) {
      result[key] = markDates(val);
    } else {
      result[key] = markDates(val);
    }
  }
  return { ...existingRaw, ...result };
}

// ---------------------------------------------------------------------------
// DocSnapshot — meniru firebase-admin DocumentSnapshot
// ---------------------------------------------------------------------------
class DocSnapshot {
  constructor(table, id, rawDataOrNull) {
    this.id = id;
    this.exists = rawDataOrNull !== null;
    this._raw = rawDataOrNull;
    this.ref = new DocRef(table, id);
  }
  data() {
    if (!this.exists) return undefined;
    return fromJsonStorage(JSON.stringify(this._raw));
  }
}

// ---------------------------------------------------------------------------
// DocRef — meniru firebase-admin DocumentReference
// ---------------------------------------------------------------------------
class DocRef {
  constructor(table, id) {
    this.table = table;
    this.id = id;
  }

  async get() {
    await ensureTable(this.table);
    const [rows] = await pool.query(`SELECT data FROM \`${this.table}\` WHERE id = ? LIMIT 1`, [this.id]);
    if (rows.length === 0) return new DocSnapshot(this.table, this.id, null);
    const raw = typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : rows[0].data;
    return new DocSnapshot(this.table, this.id, raw);
  }

  // Firestore .set(data) menimpa seluruh dokumen (tanpa {merge:true}, yang tidak
  // dipakai di codebase ini — jadi tidak perlu didukung).
  async set(data) {
    await ensureTable(this.table);
    const json = toJsonStorage(data);
    await pool.query(
      `INSERT INTO \`${this.table}\` (id, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)`,
      [this.id, json]
    );
    return this;
  }

  // Firestore .update(partial) menimpa field top-level yang disebutkan saja,
  // plus dukungan FieldValue.serverTimestamp/arrayUnion/arrayRemove/increment.
  async update(partial) {
    await ensureTable(this.table);
    const [rows] = await pool.query(`SELECT data FROM \`${this.table}\` WHERE id = ? LIMIT 1`, [this.id]);
    const existingRaw = rows.length > 0 ? (typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : rows[0].data) : {};
    const merged = applyFieldValues(existingRaw, partial);
    const json = JSON.stringify(merged);
    await pool.query(
      `INSERT INTO \`${this.table}\` (id, data) VALUES (?, ?) ON DUPLICATE KEY UPDATE data = VALUES(data)`,
      [this.id, json]
    );
    return this;
  }

  async delete() {
    await ensureTable(this.table);
    await pool.query(`DELETE FROM \`${this.table}\` WHERE id = ?`, [this.id]);
    return this;
  }
}

// ---------------------------------------------------------------------------
// QuerySnapshot — meniru firebase-admin QuerySnapshot
// ---------------------------------------------------------------------------
class QuerySnapshot {
  constructor(docs) {
    this.docs = docs;
    this.empty = docs.length === 0;
    this.size = docs.length;
  }
  forEach(cb) { this.docs.forEach(cb); }
}

// ---------------------------------------------------------------------------
// CollectionRef / Query — meniru firebase-admin CollectionReference + Query
// (chainable: .where().where().orderBy().limit().get())
// ---------------------------------------------------------------------------
class CollectionRef {
  constructor(table, filters = [], order = null, limitN = null) {
    this.table = table;
    this._filters = filters;
    this._order = order;
    this._limit = limitN;
  }

  doc(id) {
    return new DocRef(this.table, id || newId());
  }

  where(field, op, value) {
    if (op !== '==' && op !== 'array-contains') {
      throw new Error(`Operator where() belum didukung compat layer: ${op}`);
    }
    const filterFn = op === '=='
      ? (data) => data[field] === value
      : (data) => Array.isArray(data[field]) && data[field].includes(value);
    return new CollectionRef(this.table, [...this._filters, filterFn], this._order, this._limit);
  }

  orderBy(field, dir = 'asc') {
    return new CollectionRef(this.table, this._filters, { field, dir }, this._limit);
  }

  limit(n) {
    return new CollectionRef(this.table, this._filters, this._order, n);
  }

  async add(data) {
    await ensureTable(this.table);
    const id = newId();
    const json = toJsonStorage(data);
    await pool.query(`INSERT INTO \`${this.table}\` (id, data) VALUES (?, ?)`, [id, json]);
    return new DocRef(this.table, id);
  }

  async get() {
    await ensureTable(this.table);
    const [rows] = await pool.query(`SELECT id, data FROM \`${this.table}\``);
    let items = rows.map(r => ({
      id: r.id,
      raw: typeof r.data === 'string' ? JSON.parse(r.data) : r.data
    }));

    // Filter memakai data yang SUDAH di-revive (Date asli) supaya perbandingan
    // di predicate .where() konsisten dengan yang dilihat kode pemanggil.
    items = items.map(it => ({ id: it.id, raw: it.raw, live: fromJsonStorage(JSON.stringify(it.raw)) }));
    for (const filterFn of this._filters) {
      items = items.filter(it => filterFn(it.live));
    }

    if (this._order) {
      const { field, dir } = this._order;
      const mul = dir === 'desc' ? -1 : 1;
      items.sort((a, b) => {
        const av = a.live[field];
        const bv = b.live[field];
        if (av === undefined || av === null) return bv === undefined || bv === null ? 0 : 1;
        if (bv === undefined || bv === null) return -1;
        if (av instanceof Date && bv instanceof Date) return (av - bv) * mul;
        if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * mul;
        return String(av).localeCompare(String(bv)) * mul;
      });
    }

    if (this._limit !== null) items = items.slice(0, this._limit);

    const docs = items.map(it => new DocSnapshot(this.table, it.id, it.raw));
    return new QuerySnapshot(docs);
  }
}

// ---------------------------------------------------------------------------
// Batch — meniru firebase-admin WriteBatch (dijalankan berurutan, bukan atomik
// sungguhan seperti Firestore — cukup untuk skala & pola pakai aplikasi ini).
// ---------------------------------------------------------------------------
class WriteBatch {
  constructor() { this._ops = []; }
  set(ref, data) { this._ops.push({ type: 'set', ref, data }); return this; }
  update(ref, data) { this._ops.push({ type: 'update', ref, data }); return this; }
  delete(ref) { this._ops.push({ type: 'delete', ref }); return this; }
  async commit() {
    for (const op of this._ops) {
      if (op.type === 'set') await op.ref.set(op.data);
      else if (op.type === 'update') await op.ref.update(op.data);
      else if (op.type === 'delete') await op.ref.delete();
    }
    this._ops = [];
  }
}

// ---------------------------------------------------------------------------
// db — meniru firebase-admin Firestore instance
// ---------------------------------------------------------------------------
const db = {
  collection(name) { return new CollectionRef(name); },
  batch() { return new WriteBatch(); }
};

// ---------------------------------------------------------------------------
// admin.auth() — meniru firebase-admin Auth, dibekengi tabel 'users' (koleksi
// yang sama dipakai db.collection('users')) + bcrypt untuk password.
// ---------------------------------------------------------------------------
function authError(code, message) {
  const err = new Error(message);
  err.code = code;
  return err;
}

const auth = {
  async createUser({ email, password, displayName, username }) {
    await ensureTable('users');
    if (username) {
      const [existingUsername] = await pool.query(
        `SELECT id FROM users WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.username')) = ? LIMIT 1`,
        [username]
      );
      if (existingUsername.length > 0) {
        throw authError('auth/username-already-exists', 'Username sudah dipakai');
      }
    }
    if (email) {
      const [existing] = await pool.query(
        `SELECT id FROM users WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.email')) = ? LIMIT 1`,
        [email]
      );
      if (existing.length > 0) {
        throw authError('auth/email-already-exists', 'Email sudah terdaftar');
      }
    }
    const id = newId();
    const passwordHash = await bcrypt.hash(password, 10);
    const data = {
      username: username || null,
      email: email || null,
      name: displayName || username || (email ? email.split('@')[0] : 'User'),
      passwordHash,
      role: 'user',
      status: 'active',
      createdAt: new Date()
    };
    await pool.query(`INSERT INTO users (id, data) VALUES (?, ?)`, [id, toJsonStorage(data)]);
    return { uid: id, email, username, displayName };
  },

  async getUserByEmail(email) {
    await ensureTable('users');
    const [rows] = await pool.query(
      `SELECT id, data FROM users WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.email')) = ? LIMIT 1`,
      [email]
    );
    if (rows.length === 0) throw authError('auth/user-not-found', 'User tidak ditemukan');
    const raw = typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : rows[0].data;
    return { uid: rows[0].id, email, displayName: raw.name, username: raw.username };
  },

  async updateUser(uid, updates) {
    await ensureTable('users');
    const patch = {};
    if (updates.displayName !== undefined) patch.name = updates.displayName;
    if (updates.password !== undefined) patch.passwordHash = await bcrypt.hash(updates.password, 10);
    if (updates.email !== undefined) patch.email = updates.email;
    if (updates.username !== undefined) patch.username = updates.username;
    const ref = new DocRef('users', uid);
    await ref.update(patch);
    return { uid };
  },

  // Dipakai internal oleh route login (bukan bagian API Firebase asli, tapi
  // ditaruh di sini supaya semua logic password ada di satu tempat).
  // Login sekarang pakai USERNAME (bukan email) sebagai kredensial utama.
  async verifyPasswordByUsername(username, password) {
    await ensureTable('users');
    const [rows] = await pool.query(
      `SELECT id, data FROM users WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.username')) = ? LIMIT 1`,
      [username]
    );
    if (rows.length === 0) return null;
    const raw = typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : rows[0].data;
    if (!raw.passwordHash) return null;
    const ok = await bcrypt.compare(password, raw.passwordHash);
    if (!ok) return null;
    return { uid: rows[0].id, username: raw.username, email: raw.email, name: raw.name, role: raw.role };
  },

  // Dipertahankan untuk kompatibilitas (dulu login pakai email) — tidak lagi
  // dipakai oleh route /login, tapi tetap tersedia kalau dibutuhkan modul lain.
  async verifyPassword(email, password) {
    await ensureTable('users');
    const [rows] = await pool.query(
      `SELECT id, data FROM users WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.email')) = ? LIMIT 1`,
      [email]
    );
    if (rows.length === 0) return null;
    const raw = typeof rows[0].data === 'string' ? JSON.parse(rows[0].data) : rows[0].data;
    if (!raw.passwordHash) return null;
    const ok = await bcrypt.compare(password, raw.passwordHash);
    if (!ok) return null;
    return { uid: rows[0].id, email: raw.email, name: raw.name, role: raw.role };
  }
};

const admin = {
  firestore: { FieldValue },
  auth: () => auth
};

module.exports = { db, admin, FieldValue };
