// ==================== REKAP NILAI (GRADEBOOK) PER KELAS ====================
const express = require('express');
const { db } = require('../config/firebase');
const { isAdminOrTeacher } = require('../middleware/auth');

const router = express.Router();

router.get('/classes/:classId/gradebook', isAdminOrTeacher, async (req, res) => {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.classId).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };

    const role = req.session.user.role;
    if (role === 'teacher' && cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }
    const backUrl = role === 'admin' ? `/admin/classes/${cls.id}` : `/teacher/classes/${cls.id}`;

    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }

    const asgSnap = await db.collection('assignments')
      .where('classId', '==', req.params.classId)
      .where('status', '==', 'published')
      .get();
    const assignmentList = asgSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    assignmentList.sort((a, b) => (a.createdAt?.toMillis?.() || 0) - (b.createdAt?.toMillis?.() || 0));

    const gradebook = [];
    for (const student of students) {
      const scores = [];
      let total = 0, graded = 0;
      for (const a of assignmentList) {
        const subDoc = await db.collection('submissions').doc(`${a.id}_${student.id}`).get();
        const sub = subDoc.exists ? subDoc.data() : null;
        const score = (sub && sub.status === 'dinilai') ? sub.score : null;
        if (score !== null) { total += score; graded++; }
        scores.push({ assignmentId: a.id, score, status: sub ? sub.status : 'belum' });
      }
      const average = graded === 0 ? null : Math.round(total / graded);
      gradebook.push({ student, scores, average });
    }

    res.render('classes/gradebook', { cls, backUrl, assignmentList, gradebook, role: req.session.user.role });
  } catch (err) {
    console.error(err);
    res.send('Gagal membuat rekap nilai: ' + err.message);
  }
});

module.exports = router;
