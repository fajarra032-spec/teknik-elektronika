// routes/admin/dashboard.js
const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const { getAdminPending } = require('../../helpers/adminBadgeHelper');
const { ambilPeriodeBerakhirBelumDitutup } = require('../../helpers/periodeMagangHelper');

/** Tanggal hari ini menurut WITA (server bisa berjam UTC; antara 00.00-08.00 WITA tanggal UTC masih kemarin). */
const hariIniWITA = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Makassar' });

router.use(verifyToken);
router.use(isAdmin);

/**
 * Hitung jumlah dokumen yang cocok dengan sebuah query TANPA membaca isi
 * dokumennya (pakai Firestore count() aggregation - jauh lebih hemat kuota
 * daripada .get() biasa, apalagi untuk koleksi besar seperti `users`).
 * Ada fallback ke .get().size kalau versi firebase-admin di server ternyata
 * belum mendukung count() (SDK lama), supaya dashboard tetap jalan normal -
 * cuma tidak sehemat itu sampai firebase-admin di-update.
 */
async function hitungJumlah(query) {
  try {
    const snap = await query.count().get();
    return snap.data().count;
  } catch (err) {
    console.error('count() tidak tersedia, fallback ke get().size (pertimbangkan update firebase-admin):', err.message);
    const snap = await query.get();
    return snap.size;
  }
}

router.get('/', async (req, res) => {
  try {
    // ✅ OPTIMISASI KUOTA: semua yang di bawah ini cuma butuh JUMLAH dokumen,
    // bukan isinya - jadi pakai hitungJumlah() (Firestore count() aggregation)
    // alih-alih .get() biasa. .get() biasa MEMBACA SETIAP dokumen yang cocok
    // (kena biaya 1 read per dokumen), padahal kita cuma perlu angkanya saja.
    // count() jauh lebih murah karena tidak mengunduh isi dokumennya sama
    // sekali - penghematan sangat besar kalau koleksinya (mis. `users`) berisi
    // ratusan/ribuan dokumen. Dijalankan paralel (Promise.all) sekalian
    // supaya dashboard tetap cepat.
    const [
      mahasiswaCount,
      dosenCount,
      mkCount,
      krsPending,
      logbookPending,
      laporanPending,
      suratMahasiswaPending,
      suratDosenPending,
      suratTugasPending,
      badge,
      eventsSnapshot
    ] = await Promise.all([
      hitungJumlah(db.collection('users').where('role', '==', 'mahasiswa')),
      hitungJumlah(db.collection('dosen')),
      hitungJumlah(db.collection('mataKuliah')),
      hitungJumlah(db.collection('krs').where('status', '==', 'pending')),
      hitungJumlah(db.collection('logbookMagang').where('status', '==', 'pending')),
      hitungJumlah(db.collection('laporanMagang').where('status', '==', 'submitted')),
      hitungJumlah(db.collection('surat').where('status', '==', 'pending')),
      hitungJumlah(db.collection('surat_dosen').where('status', '==', 'pending')),
      hitungJumlah(db.collection('surat_tugas').where('status', '==', 'pending')),
      getAdminPending(db).catch(() => ({ kunjungan: 0, peminjaman: 0, seminar: 0, pmb: 0 })),
      db.collection('jadwalPenting')
        .where('tanggal', '>=', hariIniWITA())
        .orderBy('tanggal', 'asc')
        .limit(5)
        .get() // ini tetap .get() biasa karena kita memang butuh ISI 5 event-nya utk ditampilkan
    ]);

    // Periode magang yang tanggal selesainya sudah lewat tapi belum dinilai/ditutup
    const periodeBerakhir = await ambilPeriodeBerakhirBelumDitutup(db).catch(() => []);

    const suratPending = suratMahasiswaPending + suratDosenPending + suratTugasPending;
    const events = eventsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

    const stats = {
      mahasiswaCount,
      dosenCount,
      mkCount,
      krsPending,
      logbookPending,
      laporanPending,
      periodeBerakhir: periodeBerakhir.length,
      suratPending,
      // Dulu tidak dikirim sehingga kartu di view selalu 0
      kunjunganPending: badge.kunjungan,
      peminjamanPending: badge.peminjaman,
      seminarPending: badge.seminar,
      pmbPending: badge.pmb,
      // Opsional: kirim juga detail per role jika diperlukan di view
      suratMahasiswaPending,
      suratDosenPending
    };

    res.render('admin/dashboard', {
      title: 'Dashboard Admin',
      user: req.user,
      stats,
      events
    });

  } catch (error) {
    console.error('Error loading admin dashboard:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat dashboard admin'
    });
  }
});

module.exports = router;