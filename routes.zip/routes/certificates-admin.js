// ==================== ADMIN: KELOLA SERTIFIKAT (DAFTAR TERPUSAT) ====================
// Sebelumnya sertifikat hanya bisa dilihat satu-satu lewat halaman enrollment siswa
// tertentu. Halaman ini mengumpulkan SEMUA sertifikat yang sudah terbit dalam satu
// daftar supaya admin bisa cari & cetak ulang tanpa harus tahu enrollment ID-nya.
const express = require('express');
const { db } = require('../config/firebase');
const { isAdmin } = require('../middleware/auth');
const { getGradeClassification } = require('../utils/helpers');

const router = express.Router();

router.get('/admin/certificates', isAdmin, async (req, res) => {
  try {
    const certsSnap = await db.collection('certificates').orderBy('issuedAt', 'desc').get();
    const certificates = [];
    for (const doc of certsSnap.docs) {
      const cert = { id: doc.id, ...doc.data() };
      const enrollDoc = await db.collection('enrollments').doc(cert.enrollmentId).get();
      const enrollment = enrollDoc.exists ? enrollDoc.data() : {};
      const userDoc = await db.collection('users').doc(cert.userId).get();
      const programDoc = enrollment.programId ? await db.collection('programs').doc(enrollment.programId).get() : null;

      cert.studentName = userDoc.exists ? userDoc.data().name : '(siswa dihapus)';
      cert.studentEmail = userDoc.exists ? userDoc.data().email : '-';
      cert.programName = programDoc && programDoc.exists ? programDoc.data().name : '(program dihapus)';
      cert.overallScore = enrollment.overallScore || 0;
      cert.gradeInfo = getGradeClassification(cert.overallScore);
      cert.issuedAtDate = cert.issuedAt ? (cert.issuedAt.toDate ? cert.issuedAt.toDate() : new Date(cert.issuedAt)) : null;

      certificates.push(cert);
    }

    res.render('admin/certificates', { certificates });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil daftar sertifikat: ' + err.message);
  }
});

module.exports = router;
