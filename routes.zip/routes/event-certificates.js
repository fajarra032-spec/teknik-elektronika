// ==================== ADMIN: SERTIFIKAT EVENT (DI LUAR PROGRAM KURSUS) ====================
// Beda dari sertifikat kelulusan program (yang otomatis terbit dari Enrollment),
// sertifikat event ini untuk acara LEPAS: webinar, seminar, lomba, workshop, dll —
// tidak butuh siswa punya akun/program di sistem, tinggal isi nama & detail acara.
const express = require('express');
const QRCode = require('qrcode');
const { db } = require('../config/firebase');
const { isAdmin } = require('../middleware/auth');
const { formatEventCertNumber } = require('../utils/helpers');

const router = express.Router();

const VALID_TEMPLATES = ['klasik', 'modern', 'elegan'];
const PREDIKAT_PRESETS = ['Peserta', 'Juara 1', 'Juara 2', 'Juara 3', 'Juara Harapan 1', 'Juara Harapan 2', 'Pembicara', 'Panitia'];

router.get('/admin/event-certificates', isAdmin, async (req, res) => {
  try {
    const snap = await db.collection('event_certificates').orderBy('issuedAt', 'desc').get();
    const certificates = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    res.render('admin/event-certificates', {
      certificates,
      predikatPresets: PREDIKAT_PRESETS,
      success: req.query.success || null,
      error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil daftar sertifikat event: ' + err.message);
  }
});

// TAMBAH — mendukung 1 nama sekaligus ATAU banyak nama sekaligus (satu nama per baris,
// semuanya dapat event/predikat/template yang sama — cocok untuk sertifikat peserta webinar).
router.post('/admin/event-certificates', isAdmin, async (req, res) => {
  const { eventName, namesRaw, predikat, predikatCustom, keterangan, eventDate, template } = req.body;

  const finalPredikat = (predikat === '__custom__' ? predikatCustom : predikat || '').trim();
  const finalTemplate = VALID_TEMPLATES.includes(template) ? template : 'klasik';

  if (!eventName || !finalPredikat || !namesRaw) {
    return res.redirect('/admin/event-certificates?error=' + encodeURIComponent('Nama acara, predikat, dan minimal 1 nama peserta wajib diisi.'));
  }

  const names = namesRaw.split('\n').map(n => n.trim()).filter(Boolean);
  if (names.length === 0) {
    return res.redirect('/admin/event-certificates?error=' + encodeURIComponent('Isi minimal 1 nama peserta (satu nama per baris).'));
  }
  if (names.length > 200) {
    return res.redirect('/admin/event-certificates?error=' + encodeURIComponent('Maksimal 200 nama sekaligus dalam satu kali buat, supaya server tidak terlalu berat.'));
  }

  try {
    const existingCount = (await db.collection('event_certificates').get()).size;
    const now = new Date();
    let seq = existingCount + 1;

    for (const recipientName of names) {
      const certificateNumber = formatEventCertNumber(seq, now);
      await db.collection('event_certificates').add({
        eventName,
        recipientName,
        predikat: finalPredikat,
        keterangan: keterangan || '',
        eventDate: eventDate ? new Date(eventDate) : now,
        template: finalTemplate,
        certificateNumber,
        issuedAt: now,
        createdBy: req.session.user.uid
      });
      seq += 1;
    }

    const msg = names.length === 1
      ? `Sertifikat untuk "${names[0]}" berhasil dibuat.`
      : `${names.length} sertifikat berhasil dibuat sekaligus.`;
    res.redirect('/admin/event-certificates?success=' + encodeURIComponent(msg));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/event-certificates?error=' + encodeURIComponent(err.message));
  }
});

router.post('/admin/event-certificates/:id/delete', isAdmin, async (req, res) => {
  try {
    await db.collection('event_certificates').doc(req.params.id).delete();
    res.redirect('/admin/event-certificates?success=' + encodeURIComponent('Sertifikat dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/event-certificates?error=' + encodeURIComponent(err.message));
  }
});

// LIHAT/CETAK sertifikat event — PUBLIK (tidak perlu login), sama seperti sertifikat
// kelulusan kursus: link-nya sendiri (UUID acak) + nomor sertifikat yang berfungsi
// sebagai "kunci akses", karena penerima sertifikat event umumnya TIDAK punya akun
// login di sistem ini (misal peserta webinar dari luar).
router.get('/certificate/event/:id', async (req, res) => {
  try {
    const doc = await db.collection('event_certificates').doc(req.params.id).get();
    if (!doc.exists) return res.status(404).send('Sertifikat tidak ditemukan');
    const cert = doc.data();

    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const verificationUrl = `${baseUrl}/verify-certificate?cert=${encodeURIComponent(cert.certificateNumber)}`;
    const qrCodeDataUrl = await QRCode.toDataURL(verificationUrl);

    res.render('certificate-event', { cert, verificationUrl, qrCodeDataUrl });
  } catch (err) {
    console.error(err);
    res.status(500).send('Terjadi kesalahan: ' + err.message);
  }
});

module.exports = router;
