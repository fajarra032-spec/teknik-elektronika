// ==================== CHAT REAL-TIME (Guru-Siswa & Admin-Siswa) ====================
// Arsitektur: Express (Admin SDK) hanya dipakai untuk membuat percakapan baru dan
// menampilkan daftar inbox (aman, tervalidasi di server). Begitu masuk ke satu
// percakapan, halaman chat/room.ejs beralih memakai Firebase Client SDK langsung
// dari browser (onSnapshot) supaya pesan baru muncul REAL-TIME tanpa refresh —
// sesuai keputusan awal untuk pakai Firestore listener, bukan Socket.io.
//
// Keamanan real-time diatur lewat firestore.rules (lihat file itu), BUKAN di sini.
const express = require('express');
const { db, admin, firebaseClientConfig } = require('../config/firebase');
const { isAuthenticated } = require('../middleware/auth');

const router = express.Router();

function displayName(role) {
  if (role === 'admin') return 'Admin Sekolah';
  if (role === 'teacher') return 'Guru';
  return 'Siswa';
}

// ==================== INBOX (daftar percakapan, role-aware) ====================
router.get('/chat', isAuthenticated, async (req, res) => {
  const { uid, role, name } = req.session.user;
  try {
    let conversations = [];
    let startOptions = []; // opsi "mulai chat baru" (khusus siswa/guru)

    if (role === 'user') {
      const snap = await db.collection('conversations').where('studentId', '==', uid).orderBy('lastMessageAt', 'desc').get();
      conversations = snap.docs.map(d => ({ id: d.id, ...d.data() }));

      // Opsi mulai chat: guru dari tiap kelas yang diikuti siswa + "Hubungi Admin"
      const classesSnap = await db.collection('classes').where('studentIds', 'array-contains', uid).get();
      for (const doc of classesSnap.docs) {
        const cls = doc.data();
        if (cls.teacherId) {
          const teacherDoc = await db.collection('users').doc(cls.teacherId).get();
          if (teacherDoc.exists) {
            const alreadyExists = conversations.some(c => c.type === 'teacher_student' && c.teacherId === cls.teacherId && c.classId === doc.id);
            startOptions.push({
              type: 'teacher_student', teacherId: cls.teacherId, teacherName: teacherDoc.data().name,
              classId: doc.id, className: cls.name, alreadyExists
            });
          }
        }
      }
    } else if (role === 'teacher') {
      const snap = await db.collection('conversations').where('teacherId', '==', uid).orderBy('lastMessageAt', 'desc').get();
      conversations = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } else if (role === 'admin') {
      const snap = await db.collection('conversations').where('type', '==', 'admin_student').orderBy('lastMessageAt', 'desc').get();
      conversations = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    }

    res.render('chat/inbox', {
      user: req.session.user, conversations, startOptions,
      dashboardUrl: role === 'admin' ? '/admin/dashboard' : role === 'teacher' ? '/teacher/dashboard' : '/user/dashboard'
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat inbox chat: ' + err.message);
  }
});

// ==================== MULAI / CARI PERCAKAPAN ====================
router.post('/chat/start', isAuthenticated, async (req, res) => {
  const { uid, role, name } = req.session.user;
  const { targetType, teacherId, studentId, classId } = req.body;

  try {
    let query;
    let newConvoData;

    if (role === 'user' && targetType === 'teacher') {
      // Siswa mulai chat dengan guru salah satu kelasnya
      if (!teacherId || !classId) return res.status(400).send('Data tidak lengkap');
      query = await db.collection('conversations')
        .where('studentId', '==', uid).where('teacherId', '==', teacherId).where('classId', '==', classId).limit(1).get();
      if (query.empty) {
        const teacherDoc = await db.collection('users').doc(teacherId).get();
        const clsDoc = await db.collection('classes').doc(classId).get();
        newConvoData = {
          type: 'teacher_student', studentId: uid, studentName: name,
          teacherId, teacherName: teacherDoc.exists ? teacherDoc.data().name : 'Guru',
          classId, className: clsDoc.exists ? clsDoc.data().name : '',
          lastMessage: null, lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        };
      }
    } else if (role === 'user' && targetType === 'admin') {
      // Siswa mulai/lanjut chat dengan Admin (shared inbox, siapapun admin bisa balas)
      query = await db.collection('conversations').where('studentId', '==', uid).where('type', '==', 'admin_student').limit(1).get();
      if (query.empty) {
        newConvoData = {
          type: 'admin_student', studentId: uid, studentName: name,
          teacherId: null, teacherName: 'Admin Sekolah', classId: null, className: null,
          lastMessage: null, lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        };
      }
    } else if (role === 'teacher' && targetType === 'student') {
      // Guru mulai chat dengan salah satu siswa di kelasnya
      if (!studentId || !classId) return res.status(400).send('Data tidak lengkap');
      const clsDoc = await db.collection('classes').doc(classId).get();
      if (!clsDoc.exists || clsDoc.data().teacherId !== uid) return res.status(403).send('Anda bukan pengajar kelas ini');
      query = await db.collection('conversations')
        .where('studentId', '==', studentId).where('teacherId', '==', uid).where('classId', '==', classId).limit(1).get();
      if (query.empty) {
        const studentDoc = await db.collection('users').doc(studentId).get();
        newConvoData = {
          type: 'teacher_student', studentId, studentName: studentDoc.exists ? studentDoc.data().name : 'Siswa',
          teacherId: uid, teacherName: name,
          classId, className: clsDoc.data().name,
          lastMessage: null, lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        };
      }
    } else {
      return res.status(400).send('Kombinasi role/targetType tidak didukung');
    }

    let conversationId;
    if (query && !query.empty) {
      conversationId = query.docs[0].id;
    } else {
      const ref = await db.collection('conversations').add(newConvoData);
      conversationId = ref.id;
    }
    res.redirect(`/chat/${conversationId}`);
  } catch (err) {
    console.error(err);
    res.status(500).send('Gagal memulai percakapan: ' + err.message);
  }
});

// ==================== HALAMAN CHAT ROOM (real-time via client SDK) ====================
router.get('/chat/:id', isAuthenticated, async (req, res) => {
  const { uid, role, name } = req.session.user;
  try {
    const convoDoc = await db.collection('conversations').doc(req.params.id).get();
    if (!convoDoc.exists) return res.status(404).send('Percakapan tidak ditemukan');
    const convo = { id: convoDoc.id, ...convoDoc.data() };

    const isParticipant = convo.studentId === uid || convo.teacherId === uid || (convo.type === 'admin_student' && role === 'admin');
    if (!isParticipant) return res.status(403).send('Anda tidak punya akses ke percakapan ini');

    // Tandai percakapan ini sudah dibaca oleh user yang sedang buka halamannya
    // (dipakai untuk hitung badge "belum dibaca" di lonceng notifikasi & inbox chat)
    await db.collection('conversations').doc(convo.id).update({
      [`readBy.${uid}`]: admin.firestore.FieldValue.serverTimestamp()
    });

    const otherName = role === 'user' ? (convo.teacherName || 'Admin Sekolah') : convo.studentName;

    res.render('chat/room', {
      user: req.session.user,
      conversation: convo,
      otherName,
      firebaseConfig: firebaseClientConfig,
      dashboardUrl: role === 'admin' ? '/admin/dashboard' : role === 'teacher' ? '/teacher/dashboard' : '/user/dashboard'
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal membuka percakapan: ' + err.message);
  }
});

module.exports = router;
