// ==================== ADMIN: KELOLA PROGRAM & MATERI (GOOGLE DRIVE) ====================
const express = require('express');
const multer = require('multer');
const { db, admin } = require('../config/firebase');
const { isAdmin } = require('../middleware/auth');
const { generateShortId } = require('../utils/helpers');
const { isDriveConfigured, getNestedFolder, uploadBufferToDrive, deleteDriveFile } = require('../utils/localStorageHelper');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } }); // maks 50MB

// LIST semua program
router.get('/admin/programs', isAdmin, async (req, res) => {
  try {
    const snapshot = await db.collection('programs').orderBy('name').get();
    const programs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.render('admin/programs', {
      programs,
      success: req.query.success || null,
      error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil data program: ' + err.message);
  }
});

// CREATE program baru
router.post('/admin/programs', isAdmin, async (req, res) => {
  const { name, description, level, duration, passingScore } = req.body;
  if (!name || !level || !duration) {
    return res.redirect('/admin/programs?error=' + encodeURIComponent('Nama, level, dan durasi wajib diisi'));
  }
  try {
    await db.collection('programs').add({
      name, description: description || '', level, duration,
      passingScore: passingScore ? parseInt(passingScore) : 70,
      status: 'active', syllabus: [],
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.redirect('/admin/programs?success=' + encodeURIComponent('Program berhasil dibuat'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/programs?error=' + encodeURIComponent(err.message));
  }
});

// DETAIL program + kelola materi (syllabus)
router.get('/admin/programs/:id', isAdmin, async (req, res) => {
  try {
    const progDoc = await db.collection('programs').doc(req.params.id).get();
    if (!progDoc.exists) return res.status(404).send('Program tidak ditemukan');
    const program = { id: progDoc.id, ...progDoc.data() };
    res.render('admin/program-detail', {
      program,
      success: req.query.success || null,
      error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil detail program: ' + err.message);
  }
});

// UPDATE info dasar program
router.post('/admin/programs/:id/update', isAdmin, async (req, res) => {
  const { name, description, level, duration, status, passingScore } = req.body;
  try {
    await db.collection('programs').doc(req.params.id).update({
      name, description: description || '', level, duration, status: status || 'active',
      passingScore: passingScore ? parseInt(passingScore) : 70
    });
    res.redirect(`/admin/programs/${req.params.id}?success=` + encodeURIComponent('Info program diperbarui'));
  } catch (err) {
    console.error(err);
    res.redirect(`/admin/programs/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

// TAMBAH materi (link Google Drive) ke syllabus program
router.post('/admin/programs/:id/materials', isAdmin, upload.single('file'), async (req, res) => {
  const { title, description, type } = req.body;
  let { driveLink } = req.body;
  const file = req.file;

  if (!title || (!driveLink && !file)) {
    return res.redirect(`/admin/programs/${req.params.id}?error=` + encodeURIComponent('Judul wajib diisi, dan pilih salah satu: unggah file ATAU tempel link Google Drive'));
  }

  try {
    const progRef = db.collection('programs').doc(req.params.id);
    const progDoc = await progRef.get();
    if (!progDoc.exists) return res.status(404).send('Program tidak ditemukan');
    const program = progDoc.data();

    let driveFileId = null;

    // Kalau admin unggah file langsung -> upload ke Google Drive milik sekolah
    // (bukan tempel link manual). Butuh GOOGLE_DRIVE_ROOT_FOLDER_ID & OAuth di .env.
    if (file) {
      if (!isDriveConfigured()) {
        return res.redirect(`/admin/programs/${req.params.id}?error=` + encodeURIComponent('Upload file belum bisa dipakai — integrasi Google Drive belum di-setup di server (lihat PANDUAN_INTEGRASI_V2.md). Sementara pakai opsi "Tempel Link" dulu.'));
      }
      const folderId = await getNestedFolder(['ELMS', 'Materi', program.name]);
      const fileName = `${Date.now()}_${file.originalname}`;
      const uploaded = await uploadBufferToDrive({ buffer: file.buffer, fileName, mimeType: file.mimetype, folderId });
      driveLink = uploaded.previewUrl;
      driveFileId = uploaded.fileId;
    }

    const syllabus = program.syllabus || [];
    syllabus.push({
      id: generateShortId('materi'),
      title,
      description: description || '',
      driveLink,
      driveFileId, // null kalau link ditempel manual (bukan diunggah lewat sistem)
      type: type || 'dokumen',
      order: syllabus.length + 1
    });
    await progRef.update({ syllabus });
    res.redirect(`/admin/programs/${req.params.id}?success=` + encodeURIComponent('Materi berhasil ditambahkan'));
  } catch (err) {
    console.error(err);
    res.redirect(`/admin/programs/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS materi dari syllabus
router.post('/admin/programs/:id/materials/:materialId/delete', isAdmin, async (req, res) => {
  try {
    const progRef = db.collection('programs').doc(req.params.id);
    const progDoc = await progRef.get();
    if (!progDoc.exists) return res.status(404).send('Program tidak ditemukan');
    const syllabus = progDoc.data().syllabus || [];
    const target = syllabus.find(m => m.id === req.params.materialId);

    // v3.3: cegah hapus materi yang sudah punya nilai siswa tersimpan — kalau
    // dihapus begitu saja, nilai siswa untuk materi itu "hilang" diam-diam dari
    // perhitungan Nilai Akhir tanpa peringatan apa pun (celah yang sempat
    // ditemukan waktu audit). Materi baru boleh dihapus kalau memang belum ada
    // satupun siswa yang dinilai untuk materi tersebut.
    const enrollmentsSnap = await db.collection('enrollments').where('programId', '==', req.params.id).get();
    const hasGradedStudent = enrollmentsSnap.docs.some(doc => {
      const progress = doc.data().progress || [];
      return progress.some(p => p.materialId === req.params.materialId && p.score !== null && p.score !== undefined);
    });
    if (hasGradedStudent) {
      return res.redirect(`/admin/programs/${req.params.id}?error=` + encodeURIComponent(
        `Materi "${target ? target.name : ''}" tidak bisa dihapus karena sudah ada siswa yang punya nilai di materi ini. Nilai akan hilang dari perhitungan kalau materinya dihapus. Kalau memang harus dihapus, hubungi admin sistem untuk bantuan manual.`
      ));
    }

    // Kalau file ini diunggah lewat sistem (punya driveFileId), hapus juga dari Drive
    // supaya tidak jadi sampah/menuh-menuhin storage. Best-effort, tidak menggagalkan proses.
    if (target && target.driveFileId && isDriveConfigured()) {
      await deleteDriveFile(target.driveFileId);
    }
    const updatedSyllabus = syllabus.filter(m => m.id !== req.params.materialId);
    await progRef.update({ syllabus: updatedSyllabus });
    res.redirect(`/admin/programs/${req.params.id}?success=` + encodeURIComponent('Materi dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect(`/admin/programs/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS program (hanya jika tidak dipakai kelas manapun)
router.post('/admin/programs/:id/delete', isAdmin, async (req, res) => {
  try {
    const classesUsingProgram = await db.collection('classes').where('programId', '==', req.params.id).limit(1).get();
    if (!classesUsingProgram.empty) {
      return res.redirect('/admin/programs?error=' + encodeURIComponent('Tidak bisa dihapus, masih dipakai oleh kelas aktif'));
    }
    await db.collection('programs').doc(req.params.id).delete();
    res.redirect('/admin/programs?success=' + encodeURIComponent('Program dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/programs?error=' + encodeURIComponent(err.message));
  }
});

module.exports = router;
