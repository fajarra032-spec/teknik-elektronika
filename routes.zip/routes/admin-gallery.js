// ==================== ADMIN: KELOLA GALERI (FOTO/VIDEO DI HALAMAN UTAMA) ====================
const express = require('express');
const multer = require('multer');
const { db, admin } = require('../config/firebase');
const { isAdmin } = require('../middleware/auth');
const { isDriveConfigured, getNestedFolder, uploadBufferToDrive, deleteDriveFile } = require('../utils/localStorageHelper');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } }); // maks 20MB

// Ambil semua item galeri, urut sesuai field "order" (dibuat kalau belum ada)
async function getGalleryItems() {
  const snapshot = await db.collection('gallery').orderBy('order', 'asc').get();
  return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

// LIST + form tambah/edit
router.get('/admin/gallery', isAdmin, async (req, res) => {
  try {
    const items = await getGalleryItems();
    res.render('admin/gallery', {
      items,
      driveConfigured: isDriveConfigured(),
      success: req.query.success || null,
      error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil data galeri: ' + err.message);
  }
});

// TAMBAH item galeri baru — bisa unggah file (foto/video) langsung, atau tempel URL
router.post('/admin/gallery', isAdmin, upload.single('file'), async (req, res) => {
  const { caption, altText, mediaType, mediaUrlManual, featured } = req.body;
  const file = req.file;

  if (!caption) {
    return res.redirect('/admin/gallery?error=' + encodeURIComponent('Caption wajib diisi'));
  }
  if (!file && !mediaUrlManual) {
    return res.redirect('/admin/gallery?error=' + encodeURIComponent('Pilih salah satu: unggah file ATAU tempel URL gambar/video'));
  }

  try {
    let mediaUrl = mediaUrlManual || null;
    let driveFileId = null;

    if (file) {
      if (!isDriveConfigured()) {
        return res.redirect('/admin/gallery?error=' + encodeURIComponent('Upload file belum bisa dipakai — integrasi Google Drive belum di-setup di server. Sementara pakai opsi "Tempel URL" dulu.'));
      }
      const folderId = await getNestedFolder(['ELMS', 'Galeri Beranda']);
      const fileName = `${Date.now()}_${file.originalname}`;
      const uploaded = await uploadBufferToDrive({ buffer: file.buffer, fileName, mimeType: file.mimetype, folderId });
      mediaUrl = uploaded.fileUrl;
      driveFileId = uploaded.fileId;
    }

    // Item baru ditaruh paling akhir urutan
    const existing = await db.collection('gallery').orderBy('order', 'desc').limit(1).get();
    const nextOrder = existing.empty ? 1 : (existing.docs[0].data().order || 0) + 1;

    await db.collection('gallery').add({
      caption,
      altText: altText || caption,
      mediaType: mediaType === 'video' ? 'video' : 'foto',
      mediaUrl,
      driveFileId, // null kalau URL ditempel manual (bukan diunggah lewat sistem)
      featured: featured === 'on',
      order: nextOrder,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.redirect('/admin/gallery?success=' + encodeURIComponent('Item galeri berhasil ditambahkan'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/gallery?error=' + encodeURIComponent(err.message));
  }
});

// EDIT caption/alt/featured, dan opsional ganti file/URL media
router.post('/admin/gallery/:id/update', isAdmin, upload.single('file'), async (req, res) => {
  const { caption, altText, mediaType, mediaUrlManual, featured } = req.body;
  const file = req.file;

  if (!caption) {
    return res.redirect('/admin/gallery?error=' + encodeURIComponent('Caption wajib diisi'));
  }

  try {
    const ref = db.collection('gallery').doc(req.params.id);
    const docSnap = await ref.get();
    if (!docSnap.exists) return res.status(404).send('Item galeri tidak ditemukan');
    const current = docSnap.data();

    const updateData = {
      caption,
      altText: altText || caption,
      mediaType: mediaType === 'video' ? 'video' : 'foto',
      featured: featured === 'on'
    };

    if (file) {
      if (!isDriveConfigured()) {
        return res.redirect('/admin/gallery?error=' + encodeURIComponent('Upload file belum bisa dipakai — integrasi Google Drive belum di-setup di server. Sementara pakai opsi "Tempel URL" dulu.'));
      }
      const folderId = await getNestedFolder(['ELMS', 'Galeri Beranda']);
      const fileName = `${Date.now()}_${file.originalname}`;
      const uploaded = await uploadBufferToDrive({ buffer: file.buffer, fileName, mimeType: file.mimetype, folderId });
      updateData.mediaUrl = uploaded.fileUrl;
      updateData.driveFileId = uploaded.fileId;
      // Foto/video lama yang diunggah lewat sistem dihapus supaya tidak menumpuk sampah di Drive
      if (current.driveFileId) await deleteDriveFile(current.driveFileId);
    } else if (mediaUrlManual && mediaUrlManual !== current.mediaUrl) {
      updateData.mediaUrl = mediaUrlManual;
      updateData.driveFileId = null;
      if (current.driveFileId) await deleteDriveFile(current.driveFileId);
    }

    await ref.update(updateData);
    res.redirect('/admin/gallery?success=' + encodeURIComponent('Item galeri diperbarui'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/gallery?error=' + encodeURIComponent(err.message));
  }
});

// UBAH URUTAN — geser satu item naik/turun (dipakai tombol panah di admin)
router.post('/admin/gallery/:id/move', isAdmin, async (req, res) => {
  const { direction } = req.body; // 'up' | 'down'
  try {
    const items = await getGalleryItems();
    const idx = items.findIndex(i => i.id === req.params.id);
    if (idx === -1) return res.redirect('/admin/gallery');

    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= items.length) return res.redirect('/admin/gallery');

    const a = items[idx];
    const b = items[swapIdx];
    const batch = db.batch();
    batch.update(db.collection('gallery').doc(a.id), { order: b.order });
    batch.update(db.collection('gallery').doc(b.id), { order: a.order });
    await batch.commit();

    res.redirect('/admin/gallery?success=' + encodeURIComponent('Urutan diperbarui'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/gallery?error=' + encodeURIComponent(err.message));
  }
});

// HAPUS item galeri
router.post('/admin/gallery/:id/delete', isAdmin, async (req, res) => {
  try {
    const ref = db.collection('gallery').doc(req.params.id);
    const docSnap = await ref.get();
    if (docSnap.exists) {
      const data = docSnap.data();
      if (data.driveFileId && isDriveConfigured()) {
        await deleteDriveFile(data.driveFileId);
      }
      await ref.delete();
    }
    res.redirect('/admin/gallery?success=' + encodeURIComponent('Item galeri dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/gallery?error=' + encodeURIComponent(err.message));
  }
});

module.exports = router;
