// ==================== ADMIN: KELOLA KELAS (MULTI-KELAS / MULTI-LEVEL) ====================
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdmin } = require('../middleware/auth');
const { generateUniqueUsername } = require('../utils/helpers');

const router = express.Router();

// Helper: ambil semua program (untuk dropdown)
async function getAllPrograms() {
  const snap = await db.collection('programs').orderBy('name').get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
// Helper: ambil semua guru
async function getAllTeachers() {
  const snap = await db.collection('users').where('role', '==', 'teacher').get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
// Helper: ambil semua siswa aktif
async function getAllStudents() {
  const snap = await db.collection('users').where('role', '==', 'user').where('status', '==', 'active').get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// LIST semua kelas
router.get('/admin/classes', isAdmin, async (req, res) => {
  try {
    const snapshot = await db.collection('classes').orderBy('createdAt', 'desc').get();
    const classes = [];
    for (const doc of snapshot.docs) {
      const cls = { id: doc.id, ...doc.data() };
      const progDoc = await db.collection('programs').doc(cls.programId).get();
      cls.programName = progDoc.exists ? progDoc.data().name : '(program dihapus)';
      if (cls.teacherId) {
        const teacherDoc = await db.collection('users').doc(cls.teacherId).get();
        cls.teacherName = teacherDoc.exists ? teacherDoc.data().name : '(guru dihapus)';
      } else {
        cls.teacherName = null;
      }
      cls.studentCount = (cls.studentIds || []).length;
      classes.push(cls);
    }
    const programs = await getAllPrograms();
    const teachers = await getAllTeachers();
    res.render('admin/classes', {
      classes, programs, teachers,
      success: req.query.success || null,
      error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil data kelas: ' + err.message);
  }
});

// CREATE kelas baru
router.post('/admin/classes', isAdmin, async (req, res) => {
  const { name, programId, level, schedule, teacherId } = req.body;
  if (!name || !programId || !level) {
    return res.redirect('/admin/classes?error=' + encodeURIComponent('Nama kelas, program, dan level wajib diisi'));
  }
  try {
    await db.collection('classes').add({
      name, programId, level,
      schedule: schedule || '',
      teacherId: teacherId || null,
      studentIds: [],
      status: 'active',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    });
    res.redirect('/admin/classes?success=' + encodeURIComponent('Kelas berhasil dibuat'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/classes?error=' + encodeURIComponent(err.message));
  }
});

// DETAIL kelas: assign guru, kelola siswa, lihat materi program terkait
router.get('/admin/classes/:id', isAdmin, async (req, res) => {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.id).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };

    const progDoc = await db.collection('programs').doc(cls.programId).get();
    const program = progDoc.exists ? { id: progDoc.id, ...progDoc.data() } : null;

    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }

    // v2.0: cek enrollment untuk program kelas ini, supaya admin tahu siswa mana
    // yang sudah di-enroll (progress/sertifikat) vs yang cuma masuk kelas tanpa enrollment
    const enrollSnap = await db.collection('enrollments').where('programId', '==', cls.programId).get();
    const enrolledUserIds = new Set(enrollSnap.docs.map(d => d.data().userId));
    students.forEach(s => { s.isEnrolled = enrolledUserIds.has(s.id); });

    const allTeachers = await getAllTeachers();
    const allStudents = await getAllStudents();
    // Siswa yang belum ada di kelas ini (untuk dropdown tambah siswa)
    const availableStudents = allStudents
      .filter(s => !(cls.studentIds || []).includes(s.id))
      .map(s => ({ ...s, isEnrolled: enrolledUserIds.has(s.id) }));

    res.render('admin/class-detail', {
      cls, program, students, allTeachers, availableStudents,
      success: req.query.success || null,
      error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil detail kelas: ' + err.message);
  }
});

// SET / GANTI guru pengampu
router.post('/admin/classes/:id/teacher', isAdmin, async (req, res) => {
  const { teacherId } = req.body;
  try {
    await db.collection('classes').doc(req.params.id).update({ teacherId: teacherId || null });
    res.redirect(`/admin/classes/${req.params.id}?success=` + encodeURIComponent('Guru pengampu diperbarui'));
  } catch (err) {
    console.error(err);
    res.redirect(`/admin/classes/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

// TAMBAH siswa ke kelas
router.post('/admin/classes/:id/students/add', isAdmin, async (req, res) => {
  const { studentId } = req.body;
  if (!studentId) return res.redirect(`/admin/classes/${req.params.id}?error=` + encodeURIComponent('Pilih siswa terlebih dahulu'));
  try {
    await db.collection('classes').doc(req.params.id).update({
      studentIds: admin.firestore.FieldValue.arrayUnion(studentId)
    });
    res.redirect(`/admin/classes/${req.params.id}?success=` + encodeURIComponent('Siswa ditambahkan ke kelas'));
  } catch (err) {
    console.error(err);
    res.redirect(`/admin/classes/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS siswa dari kelas
router.post('/admin/classes/:id/students/remove', isAdmin, async (req, res) => {
  const { studentId } = req.body;
  try {
    await db.collection('classes').doc(req.params.id).update({
      studentIds: admin.firestore.FieldValue.arrayRemove(studentId)
    });
    res.redirect(`/admin/classes/${req.params.id}?success=` + encodeURIComponent('Siswa dikeluarkan dari kelas'));
  } catch (err) {
    console.error(err);
    res.redirect(`/admin/classes/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS kelas
router.post('/admin/classes/:id/delete', isAdmin, async (req, res) => {
  try {
    await db.collection('classes').doc(req.params.id).delete();
    res.redirect('/admin/classes?success=' + encodeURIComponent('Kelas dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect('/admin/classes?error=' + encodeURIComponent(err.message));
  }
});

// ==================== KELOLA AKUN GURU (TEACHER) ====================
// Buat akun guru baru (Firebase Auth + Firestore, role: teacher)
router.post('/admin/teachers/create', isAdmin, async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.redirect('/admin/classes?error=' + encodeURIComponent('Semua field akun guru wajib diisi'));
  }
  try {
    const username = await generateUniqueUsername(name || email);
    const userRecord = await admin.auth().createUser({ email, password, displayName: name, username });
    // v3.1: .update() bukan .set() — supaya passwordHash yang sudah disimpan
    // createUser() tidak ketimpa (kalau ketimpa, akun guru ini tidak bisa login).
    await db.collection('users').doc(userRecord.uid).update({
      role: 'teacher', status: 'active'
    });
    res.redirect('/admin/classes?success=' + encodeURIComponent(`Akun guru berhasil dibuat. Username login: ${username}`));
  } catch (err) {
    console.error(err);
    let msg = err.message;
    if (err.code === 'auth/email-already-exists') msg = 'Email sudah terdaftar';
    res.redirect('/admin/classes?error=' + encodeURIComponent(msg));
  }
});

module.exports = router;
