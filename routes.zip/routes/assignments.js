// ==================== TUGAS / QUIZ / CBT PER KELAS ====================
// Mirip pola schedule-attendance.js: dipakai bersama Admin & Guru (guru dibatasi
// hanya untuk kelas yang ia ampu). Soal quiz/CBT diambil dari Bank Soal program terkait.
const express = require('express');
const { db, admin } = require('../config/firebase');
const { isAdminOrTeacher } = require('../middleware/auth');
const { notifyUser } = require('../utils/notificationHelper');

const router = express.Router();

async function loadClassAndAuthorize(req, res, next) {
  try {
    const clsDoc = await db.collection('classes').doc(req.params.classId).get();
    if (!clsDoc.exists) return res.status(404).send('Kelas tidak ditemukan');
    const cls = { id: clsDoc.id, ...clsDoc.data() };

    const role = req.session.user.role;
    if (role === 'teacher' && cls.teacherId !== req.session.user.uid) {
      return res.status(403).send('Anda bukan pengajar kelas ini');
    }

    const students = [];
    for (const uid of (cls.studentIds || [])) {
      const uDoc = await db.collection('users').doc(uid).get();
      if (uDoc.exists) students.push({ id: uid, ...uDoc.data() });
    }

    req.cls = cls;
    req.classStudents = students;
    req.backUrl = role === 'admin' ? `/admin/classes/${cls.id}` : `/teacher/classes/${cls.id}`;
    next();
  } catch (err) {
    console.error(err);
    res.send('Gagal memuat data kelas: ' + err.message);
  }
}

router.use('/classes/:classId/assignments', isAdminOrTeacher, loadClassAndAuthorize);

// LIST tugas/quiz/CBT sebuah kelas
router.get('/classes/:classId/assignments', async (req, res) => {
  try {
    const snap = await db.collection('assignments')
      .where('classId', '==', req.params.classId)
      .orderBy('createdAt', 'desc')
      .get();
    const assignments = [];
    for (const doc of snap.docs) {
      const a = { id: doc.id, ...doc.data() };
      const subsSnap = await db.collection('submissions').where('assignmentId', '==', a.id).get();
      a.submittedCount = subsSnap.size;
      assignments.push(a);
    }

    let bankQuestions = [];
    if (req.cls.programId) {
      const qSnap = await db.collection('questions').where('programId', '==', req.cls.programId).get();
      bankQuestions = qSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    }

    res.render('classes/assignments', {
      cls: req.cls, assignments, bankQuestions, backUrl: req.backUrl, role: req.session.user.role,
      totalStudents: req.classStudents.length,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil daftar tugas/quiz: ' + err.message);
  }
});

// BUAT tugas/quiz/CBT baru
router.post('/classes/:classId/assignments', async (req, res) => {
  const { title, type, description, dueDate, duration } = req.body;
  if (!title || !type) {
    return res.redirect(`/classes/${req.params.classId}/assignments?error=` + encodeURIComponent('Judul dan tipe wajib diisi'));
  }
  try {
    const data = {
      classId: req.params.classId,
      title, type, // 'tugas' | 'quiz' | 'cbt'
      description: description || '',
      dueDate: dueDate || null,
      duration: duration ? parseInt(duration) : null, // menit, khusus quiz/cbt
      status: 'draft',
      createdBy: req.session.user.uid,
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    if (type === 'quiz' || type === 'cbt') {
      let questionIds = req.body.questionIds || [];
      if (!Array.isArray(questionIds)) questionIds = [questionIds];
      if (questionIds.length === 0) {
        return res.redirect(`/classes/${req.params.classId}/assignments?error=` + encodeURIComponent('Pilih minimal 1 soal dari bank soal untuk quiz/CBT'));
      }
      data.questionIds = questionIds;
    }
    await db.collection('assignments').add(data);
    res.redirect(`/classes/${req.params.classId}/assignments?success=` + encodeURIComponent('Berhasil dibuat (masih Draft, jangan lupa Publikasikan)'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/assignments?error=` + encodeURIComponent(err.message));
  }
});

// DETAIL: daftar submission siswa + form nilai manual (untuk tugas esai)
router.get('/classes/:classId/assignments/:id', async (req, res) => {
  try {
    const aDoc = await db.collection('assignments').doc(req.params.id).get();
    if (!aDoc.exists) return res.status(404).send('Tidak ditemukan');
    const assignmentData = { id: aDoc.id, ...aDoc.data() };

    let questions = [];
    if (assignmentData.questionIds && assignmentData.questionIds.length > 0) {
      const qDocs = await Promise.all(assignmentData.questionIds.map(qid => db.collection('questions').doc(qid).get()));
      questions = qDocs.filter(d => d.exists).map(d => ({ id: d.id, ...d.data() }));
    }

    const rows = [];
    for (const student of req.classStudents) {
      const subDoc = await db.collection('submissions').doc(`${assignmentData.id}_${student.id}`).get();
      rows.push({ student, submission: subDoc.exists ? subDoc.data() : null });
    }

    res.render('classes/assignment-detail', {
      cls: req.cls, assignment: assignmentData, questions, rows, backUrl: req.backUrl, role: req.session.user.role,
      success: req.query.success || null, error: req.query.error || null
    });
  } catch (err) {
    console.error(err);
    res.send('Gagal mengambil detail: ' + err.message);
  }
});

// PUBLIKASIKAN / jadikan draft lagi
router.post('/classes/:classId/assignments/:id/publish', async (req, res) => {
  try {
    const aDoc = await db.collection('assignments').doc(req.params.id).get();
    const current = aDoc.data().status;
    await db.collection('assignments').doc(req.params.id).update({ status: current === 'published' ? 'draft' : 'published' });
    res.redirect(`/classes/${req.params.classId}/assignments?success=` + encodeURIComponent('Status berhasil diubah'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/assignments?error=` + encodeURIComponent(err.message));
  }
});

// HAPUS
router.post('/classes/:classId/assignments/:id/delete', async (req, res) => {
  try {
    await db.collection('assignments').doc(req.params.id).delete();
    res.redirect(`/classes/${req.params.classId}/assignments?success=` + encodeURIComponent('Berhasil dihapus'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/assignments?error=` + encodeURIComponent(err.message));
  }
});

// NILAI MANUAL (khusus tipe "tugas" / esai yang tidak auto-grade)
router.post('/classes/:classId/assignments/:id/submissions/:studentId/grade', async (req, res) => {
  const { manualScore, teacherFeedback } = req.body;
  try {
    await db.collection('submissions').doc(`${req.params.id}_${req.params.studentId}`).update({
      score: parseInt(manualScore) || 0,
      teacherFeedback: teacherFeedback || '',
      status: 'dinilai',
      gradedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    const asgDoc = await db.collection('assignments').doc(req.params.id).get();
    await notifyUser({
      userId: req.params.studentId, type: 'grade',
      title: 'Nilai Tugas Baru',
      message: `Tugas "${asgDoc.exists ? asgDoc.data().title : ''}" sudah dinilai: ${parseInt(manualScore) || 0}`,
      link: `/student/assignments/${req.params.id}`
    });

    res.redirect(`/classes/${req.params.classId}/assignments/${req.params.id}?success=` + encodeURIComponent('Nilai berhasil disimpan'));
  } catch (err) {
    console.error(err);
    res.redirect(`/classes/${req.params.classId}/assignments/${req.params.id}?error=` + encodeURIComponent(err.message));
  }
});

module.exports = router;
