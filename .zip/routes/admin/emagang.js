/**
 * routes/admin/emagang.js
 * E‑Magang - Admin/Kaprodi melihat dan mengelola logbook mahasiswa
 * Fitur lengkap: Mulai periode, Edit perusahaan, Lock/Unlock, Extend, Complete & Nilai
 * OPTIMASI: Cache sederhana + Promise.all untuk mengurangi query berulang.
 */

const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const { getAllMahasiswa } = require('../../helpers/cache');
const { filterEnrollmentDocsAktif } = require('../../helpers/statusMahasiswaHelper');
const { invalidateProgressMagangHarian } = require('../../helpers/magangHelper');
const { ITEM_PENDAMPING_LAPANGAN, daftarKategori, hitungRincian, getNilaiMagang, getNilaiDosenEfektif, savePenilaianPendampingLapangan, hitungNilaiAkhirMagang, kunciNilaiMagangKeGrades } = require('../../helpers/nilaiMagangHelper');
const { buildFormPenilaianData } = require('../../helpers/formPenilaianMagangHelper');
const {
  lockMagangPeriod,
  unlockMagangPeriod,
  extendMagangPeriod,
  editTanggalMulaiMagangPeriod,
  updatePerusahaanMagangPeriod
} = require('../../models/magangPeriodModel');
const { getPembimbingMahasiswa } = require('../../helpers/pembimbingHelper');
const { buildLogbookPrintData } = require('../../helpers/logbookPrintHelper');
const { tampilkanCetakLogbook } = require('../../helpers/logbookPdfHelper');
const magangNotif = require('../../helpers/magangNotifHelper');
const { createKrsDanEnrollment } = require('../../helpers/paketKurikulumHelper');
const { getCurrentAcademicSemester } = require('../../helpers/academicHelper');
const { hariIniWITA, pilihPeriodeDefault, rentangLogbookPeriode, terapkanRentang, dalamRentang, ambilPeriodePerMahasiswa, statistikLogbookPeriode, validasiMulaiPeriode, periodeSudahBerakhir, hitungTanggalSelesaiMagang, DURASI_MAGANG_BULAN } = require('../../helpers/periodeMagangHelper');

router.use(verifyToken);
router.use(isAdmin);

// ============================================================================
// CACHE SEDERHANA (untuk satu request)
// ============================================================================
const cache = {
  mahasiswa: new Map(),      // userId -> { nama, nim, ... }
  bimbingan: new Map(),      // mahasiswaId -> { pembimbingId, pembimbingNama } (= Dosen PA)
  magangPeriods: new Map(),  // mahasiswaId -> array periode
  logbookStats: new Map()     // key "userId_pdkId" -> { total, pending, approved, rejected }
};

function clearCache() {
  cache.mahasiswa.clear();
  cache.bimbingan.clear();
  cache.magangPeriods.clear();
  cache.logbookStats.clear();
}

// ============================================================================
// FUNGSI BANTU (dengan cache)
// ============================================================================

function formatDate(dateString) {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

function formatDateTime(dateString) {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return date.toLocaleDateString('id-ID', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

async function getMahasiswa(userId) {
  if (cache.mahasiswa.has(userId)) return cache.mahasiswa.get(userId);
  try {
    const userDoc = await db.collection('users').doc(userId).get();
    const data = userDoc.exists ? { id: userDoc.id, ...userDoc.data() } : { id: userId, nama: 'Unknown', nim: '-' };
    cache.mahasiswa.set(userId, data);
    return data;
  } catch (error) {
    console.error('Error getMahasiswa:', error);
    return { id: userId, nama: 'Error', nim: '-' };
  }
}

// Pembimbing magang = Dosen PA mahasiswa (Pembimbing 1 & 2 ditiadakan).
// Diambil dari users.dosenPaId, BUKAN lagi dari koleksi `bimbingan`.
async function getBimbingan(mahasiswaId) {
  if (cache.bimbingan.has(mahasiswaId)) return cache.bimbingan.get(mahasiswaId);
  try {
    const pembimbing = await getPembimbingMahasiswa(mahasiswaId);
    if (!pembimbing) return null;
    const data = { pembimbingId: pembimbing.id, pembimbingNama: pembimbing.nama };
    cache.bimbingan.set(mahasiswaId, data);
    return data;
  } catch (error) {
    console.error('Error getBimbingan:', error);
    return null;
  }
}

async function getMagangPeriods(mahasiswaId) {
  if (cache.magangPeriods.has(mahasiswaId)) return cache.magangPeriods.get(mahasiswaId);
  try {
    const snapshot = await db.collection('magangPeriod')
      .where('mahasiswaId', '==', mahasiswaId)
      .orderBy('pdkKode', 'asc')
      .get();
    const periods = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    cache.magangPeriods.set(mahasiswaId, periods);
    return periods;
  } catch (error) {
    console.error('Error getMagangPeriods:', error);
    return [];
  }
}

async function getLogbookStats(mahasiswaId, pdkId = null) {
  const key = pdkId ? `${mahasiswaId}_${pdkId}` : mahasiswaId;
  if (cache.logbookStats.has(key)) return cache.logbookStats.get(key);
  try {
    // ✅ OPTIMISASI KUOTA: sebelumnya di sini membaca SEMUA dokumen logbook
    // milik mahasiswa ini (.get()) hanya untuk menghitung status - kalau
    // dipanggil untuk tiap mahasiswa di daftar (lihat router.get('/') di
    // bawah), ini bisa jadi ratusan/ribuan pembacaan dokumen SETIAP kali
    // halaman monitoring dibuka. Sekarang pakai count() agregasi: biayanya
    // TETAP 1 read-unit per query, berapapun jumlah dokumen logbook yang
    // dimiliki mahasiswa tsb (4 query paralel = 4 read-unit, bukan N-dokumen).
    let base = db.collection('logbookMagang').where('userId', '==', mahasiswaId);
    if (pdkId) base = base.where('pdkId', '==', pdkId);
    const [totalSnap, pendingSnap, approvedSnap, rejectedSnap] = await Promise.all([
      base.count().get(),
      base.where('status', '==', 'pending').count().get(),
      base.where('status', '==', 'approved').count().get(),
      base.where('status', '==', 'rejected').count().get()
    ]);
    const result = {
      total: totalSnap.data().count,
      pending: pendingSnap.data().count,
      approved: approvedSnap.data().count,
      rejected: rejectedSnap.data().count
    };
    cache.logbookStats.set(key, result);
    return result;
  } catch (error) {
    console.error('Error getLogbookStats:', error);
    return { total: 0, pending: 0, approved: 0, rejected: 0 };
  }
}

// ============================================================================
// RUTE UTAMA – DAFTAR MAHASISWA (OPTIMASI)
// ============================================================================

router.get('/', async (req, res) => {
  try {
    clearCache();
    const { search, angkatan } = req.query;

    // ✅ OPTIMISASI KUOTA: sebelumnya di sini membaca SEMUA enrollment AKTIF
    // DI SELURUH SISTEM (semua mata kuliah, bukan cuma magang/PDK) - lalu
    // baru menyaring mana yang PDK di JS. Data real dari Firebase Query
    // Insights menunjukkan ini salah satu query paling boros di seluruh
    // aplikasi (~234 dokumen dibaca SETIAP kali halaman ini dibuka).
    // Sekarang: cari dulu MK mana saja yang isPDK==true (jumlahnya jauh
    // lebih sedikit, biasanya cuma beberapa PDK per angkatan), baru query
    // enrollment DIBATASI ke mkId-mkId itu saja.
    const pdkMkSnapshot = await db.collection('mataKuliah').where('isPDK', '==', true).get();
    const pdkMkIds = pdkMkSnapshot.docs.map(doc => doc.id);
    const mkMap = new Map();
    pdkMkSnapshot.docs.forEach(doc => mkMap.set(doc.id, doc.data()));

    if (pdkMkIds.length === 0) {
      return res.render('admin/emagang_list', {
        title: 'E‑Magang - Monitoring Magang',
        mahasiswaList: [],
        totalMahasiswa: 0,
        summaryStats: { totalLogbook: 0, totalPending: 0, totalApproved: 0, totalRejected: 0 },
        angkatanList: [],
        filters: { search: search || '', angkatan: angkatan || '', berakhir: false },
        pageInfo: null,
        showAll: false,
        pageListUrl: '/admin/emagang',
        user: req.user
      });
    }

    function chunkArray(arr, size) {
      const chunks = [];
      for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
      return chunks;
    }
    const enrollmentDocsAll = [];
    for (const chunk of chunkArray(pdkMkIds, 10)) {
      const snap = await db.collection('enrollment')
        .where('mkId', 'in', chunk)
        .where('status', '==', 'active')
        .get();
      enrollmentDocsAll.push(...snap.docs);
    }

    // Kelompokkan per mahasiswa (mahasiswa Cuti/Keluar tidak ikut magang -> dibuang)
    const userPdkMap = new Map();
    const enrollmentDocsAktif = await filterEnrollmentDocsAktif(db, enrollmentDocsAll);
    for (const doc of enrollmentDocsAktif) {
      const enrollment = doc.data();
      const userId = enrollment.userId;
      const mk = mkMap.get(enrollment.mkId);
      if (mk && mk.isPDK === true) {
        if (!userPdkMap.has(userId)) {
          userPdkMap.set(userId, { pdks: [], mahasiswaData: null });
        }
        userPdkMap.get(userId).pdks.push({
          id: enrollment.mkId,
          kode: mk.kode,
          nama: mk.nama,
          urutan: mk.urutanPDK,
          semester: enrollment.semester
        });
      }
    }

    // Ambil data mahasiswa SEKALIGUS lewat db.getAll() (bukan Promise.all
    // per-doc yang read cost-nya sama tapi round-trip-nya lebih banyak).
    const userIds = Array.from(userPdkMap.keys());
    const mahasiswaDocs = userIds.length > 0
      ? await db.getAll(...userIds.map(id => db.collection('users').doc(id)))
      : [];
    const mahasiswaMap = new Map();
    mahasiswaDocs.forEach((doc, idx) => {
      if (doc.exists && doc.data().role === 'mahasiswa') {
        mahasiswaMap.set(userIds[idx], { id: doc.id, ...doc.data() });
      } else {
        userPdkMap.delete(userIds[idx]);
      }
    });

    // Bangun array mahasiswaList
    let mahasiswaList = [];
    for (const [userId, data] of userPdkMap) {
      const mhs = mahasiswaMap.get(userId);
      if (!mhs) continue;
      data.pdks.sort((a, b) => (a.urutan || 0) - (b.urutan || 0));
      mahasiswaList.push({
        ...mhs,
        enrolledPdks: data.pdks,
        pdkKodes: data.pdks.map(p => p.kode).join(', '),
        pdkUrutans: data.pdks.map(p => `PDK ${p.urutan}`).join(', ')
      });
    }

    // Filter pencarian
    if (search) {
      const searchLower = search.toLowerCase();
      mahasiswaList = mahasiswaList.filter(m =>
        m.nama.toLowerCase().includes(searchLower) || (m.nim && m.nim.includes(search))
      );
    }
    if (angkatan) {
      mahasiswaList = mahasiswaList.filter(m => {
        const nimAngkatan = m.nim ? '20' + m.nim.substring(0, 2) : '';
        return nimAngkatan === angkatan;
      });
    }

    mahasiswaList.sort((a, b) => a.nama.localeCompare(b.nama));
    const angkatanList = [...new Set(mahasiswaList.map(m => m.nim ? '20' + m.nim.substring(0,2) : '').filter(a => a))].sort().reverse();

    // Ambil statistik logbook untuk semua mahasiswa TERFILTER (paralel, tapi
    // sekarang pakai count() murah - lihat getLogbookStats di atas) supaya
    // kartu ringkasan (Total Logbook/Pending/Approved/Rejected) tetap akurat
    // terhadap filter pencarian/angkatan yang aktif.
    // Rekap PER PERIODE (periode yang sedang berjalan), bukan jumlah semua Magang.
    const periodePerMhs = await ambilPeriodePerMahasiswa(db, mahasiswaList.map(m => m.id));
    // ?berakhir=1 -> hanya mahasiswa yang punya periode 'active' tetapi tanggal selesainya sudah lewat
    const filterBerakhir = req.query.berakhir === '1';
    if (filterBerakhir) {
      const hariIniFilter = hariIniWITA();
      mahasiswaList = mahasiswaList.filter(m =>
        (periodePerMhs.get(m.id) || []).some(p => p.status === 'active' && periodeSudahBerakhir(p, hariIniFilter)));
    }

    // ===== Kategori status magang (sama seperti monitoring dosen) =====
    //   aktif   : punya periode berstatus active/locked
    //   selesai : tidak ada periode aktif, tetapi ada periode completed
    //   krs     : sudah KRS (memprogram PDK) tetapi periode magang belum dimulai
    // Satu mahasiswa hanya masuk SATU kategori (prioritas aktif > selesai > krs),
    // jadi jumlah ketiga tab = jumlah "Semua". Tanpa query Firestore tambahan.
    const hariIniKat = hariIniWITA();
    mahasiswaList.forEach((m) => {
      const semuaP = (periodePerMhs.get(m.id) || []).filter(p => p.status !== 'cancelled');
      const aktifP = semuaP.filter(p => p.status === 'active' || p.status === 'locked');
      const selesaiP = semuaP.filter(p => p.status === 'completed');
      m.statusMagang = aktifP.length ? 'aktif' : (selesaiP.length ? 'selesai' : 'krs');
      const tampil = aktifP.length ? pilihPeriodeDefault(aktifP, hariIniKat)
        : (selesaiP.length ? pilihPeriodeDefault(selesaiP, hariIniKat) : null);
      m.periodeInfo = tampil ? {
        pdkNama: tampil.pdkNama || '',
        tanggalMulai: tampil.tanggalMulai || '',
        tanggalSelesai: tampil.tanggalSelesai || '',
        perusahaan: (tampil.perusahaan && tampil.perusahaan.nama) || '',
        berakhir: aktifP.length > 0 && periodeSudahBerakhir(tampil, hariIniKat)
      } : null;
      m.jumlahPeriodeSelesai = selesaiP.length;
    });
    const tabCounts = {
      semua: mahasiswaList.length,
      krs: mahasiswaList.filter(m => m.statusMagang === 'krs').length,
      aktif: mahasiswaList.filter(m => m.statusMagang === 'aktif').length,
      selesai: mahasiswaList.filter(m => m.statusMagang === 'selesai').length
    };
    const tab = ['krs', 'aktif', 'selesai'].includes(req.query.tab) ? req.query.tab : 'semua';
    if (tab !== 'semua') mahasiswaList = mahasiswaList.filter(m => m.statusMagang === tab);
    const statsPromises = mahasiswaList.map(async (m) => {
      const semua = periodePerMhs.get(m.id) || [];
      const per = pilihPeriodeDefault(semua, hariIniWITA());
      m.rekapLabel = per ? (per.pdkNama || '') : '';
      if (!per) return getLogbookStats(m.id);
      const key = `rekap_${per.id}`;
      if (cache.logbookStats.has(key)) return cache.logbookStats.get(key);
      const st = await statistikLogbookPeriode(db, m.id, per, semua);
      cache.logbookStats.set(key, st);
      return st;
    });
    const statsResults = await Promise.all(statsPromises);
    mahasiswaList.forEach((m, idx) => {
      m.totalLogbook = statsResults[idx].total;
      m.pendingCount = statsResults[idx].pending;
      m.approvedCount = statsResults[idx].approved;
      m.rejectedCount = statsResults[idx].rejected;
    });

    // ✅ PAGINASI: jangan render SEMUA mahasiswa sekaligus ke tabel - default
    // 10 per halaman, tersedia tombol "Tampilkan Semua" kalau memang perlu
    // (mis. sebelum export/cetak). Ini paginasi di memori (bukan query
    // Firestore baru), jadi tidak menambah biaya baca sama sekali.
    const EMAGANG_PAGE_SIZE = 10;
    const showAll = req.query.all === '1';
    const totalFiltered = mahasiswaList.length;
    const fullMahasiswaList = mahasiswaList;

    const buildListUrl = (params) => {
      const usp = new URLSearchParams();
      if (search) usp.set('search', search);
      if (angkatan) usp.set('angkatan', angkatan);
      if (filterBerakhir) usp.set('berakhir', '1');
      if (tab !== 'semua') usp.set('tab', tab);
      Object.entries(params).forEach(([k, v]) => usp.set(k, v));
      return `/admin/emagang?${usp.toString()}`;
    };
    // URL untuk berpindah tab (mempertahankan pencarian/angkatan, kembali ke halaman 1)
    const tabUrl = (t) => {
      const usp = new URLSearchParams();
      if (search) usp.set('search', search);
      if (angkatan) usp.set('angkatan', angkatan);
      if (filterBerakhir) usp.set('berakhir', '1');
      if (t !== 'semua') usp.set('tab', t);
      const qs = usp.toString();
      return '/admin/emagang' + (qs ? '?' + qs : '');
    };

    let pageInfo = null;
    if (!showAll) {
      const page = Math.max(1, parseInt(req.query.page, 10) || 1);
      const start = (page - 1) * EMAGANG_PAGE_SIZE;
      const paged = fullMahasiswaList.slice(start, start + EMAGANG_PAGE_SIZE);
      const hasPrev = page > 1;
      const hasNext = start + EMAGANG_PAGE_SIZE < totalFiltered;
      pageInfo = {
        hasPrev,
        hasNext,
        prevUrl: hasPrev ? buildListUrl({ page: page - 1 }) : null,
        nextUrl: hasNext ? buildListUrl({ page: page + 1 }) : null,
        allUrl: buildListUrl({ all: '1' }),
        count: paged.length,
        total: totalFiltered
      };
      mahasiswaList = paged;
    }

    // Kartu ringkasan (Total Logbook/Pending/Approved/Rejected) dihitung dari
    // SELURUH mahasiswa terfilter (fullMahasiswaList), bukan cuma halaman
    // yang sedang tampil, supaya angkanya tetap benar walau tabelnya dipaginasi.
    const summaryStats = fullMahasiswaList.reduce((acc, m) => {
      acc.totalLogbook += m.totalLogbook || 0;
      acc.totalPending += m.pendingCount || 0;
      acc.totalApproved += m.approvedCount || 0;
      acc.totalRejected += m.rejectedCount || 0;
      return acc;
    }, { totalLogbook: 0, totalPending: 0, totalApproved: 0, totalRejected: 0 });

    res.render('admin/emagang_list', {
      title: 'E‑Magang - Monitoring Magang',
      mahasiswaList,
      totalMahasiswa: totalFiltered,
      summaryStats,
      angkatanList,
      filters: { search: search || '', angkatan: angkatan || '', berakhir: filterBerakhir, tab },
      tab,
      tabCounts,
      tabUrls: { semua: tabUrl('semua'), krs: tabUrl('krs'), aktif: tabUrl('aktif'), selesai: tabUrl('selesai') },
      pageInfo,
      showAll,
      pageListUrl: buildListUrl({ page: 1 }),
      user: req.user
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', { message: 'Gagal mengambil data logbook' });
  }
});

// ============================================================================
// DETAIL LOGBOOK PER MAHASISWA (OPTIMASI)
// ============================================================================

router.get('/mahasiswa/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { periodId, semester } = req.query;

    clearCache();
    const bimbingan = await getBimbingan(userId);
    const mahasiswa = await getMahasiswa(userId);
    if (!mahasiswa.nama || mahasiswa.nama === 'Unknown') {
      return res.status(404).send('Mahasiswa tidak ditemukan');
    }

    const allPeriods = await getMagangPeriods(userId);
    let selectedPeriod = null;
    if (periodId) selectedPeriod = allPeriods.find(p => p.id === periodId);
    else if (allPeriods.length > 0) selectedPeriod = pilihPeriodeDefault(allPeriods, hariIniWITA());
    const rentangTerpilih = selectedPeriod ? rentangLogbookPeriode(selectedPeriod, allPeriods) : { awal: null, akhir: null };

    // ✅ OPTIMISASI KUOTA: hanya logbook PERIODE yang dipilih yang dibaca (bukan seluruh
    // logbook semua Magang). Statistik periode lain dihitung lewat count() agregasi.
    let logbookPeriode;
    if (selectedPeriod) {
      const snapPeriode = await terapkanRentang(db.collection('logbookMagang')
        .where('userId', '==', userId)
        .where('pdkId', '==', selectedPeriod.pdkId), rentangTerpilih).get();
      logbookPeriode = snapPeriode.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } else {
      const snapSemua = await db.collection('logbookMagang').where('userId', '==', userId).get();
      logbookPeriode = snapSemua.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    }

    // Daftar semester unik (dari logbook periode yang sedang dilihat)
    const semesterSet = new Set();
    logbookPeriode.forEach(l => { if (l.semester) semesterSet.add(l.semester); });
    const semesterList = Array.from(semesterSet).sort();

    // Daftar logbook yang ditampilkan (filter semester + urutkan)
    let logbookList = logbookPeriode.filter(l => !semester || l.semester === semester);
    logbookList.sort((a, b) => new Date(b.tanggal) - new Date(a.tanggal));
    logbookList = logbookList.map(data => ({
      ...data,
      tanggalFormatted: formatDate(data.tanggal),
      tanggalWaktuFormatted: formatDateTime(data.tanggal)
    }));

    // Statistik per PDK/periode: periode terpilih dihitung dari data yang sudah ada,
    // periode lain lewat count().
    const pdkStats = await Promise.all(allPeriods.map(async (period) => {
      let st;
      if (selectedPeriod && period.id === selectedPeriod.id) {
        st = { pending: 0, approved: 0, rejected: 0 };
        logbookPeriode.forEach(l => { if (st[l.status] !== undefined) st[l.status]++; });
      } else {
        st = await statistikLogbookPeriode(db, userId, period, allPeriods);
      }
      return {
        id: period.id,
        pdkKode: period.pdkKode,
        pdkNama: period.pdkNama,
        pendingCount: st.pending,
        approvedCount: st.approved,
        rejectedCount: st.rejected,
        status: period.status,
        tanggalMulai: period.tanggalMulai,
        tanggalSelesai: period.tanggalSelesai,
        perusahaan: period.perusahaan
      };
    }));

    // Daftar PDK untuk dropdown (satu query)
    const pdkSnapshot = await db.collection('mataKuliah')
      .where('isPDK', '==', true)
      .orderBy('urutanPDK', 'asc')
      .get();
    const pdkList = pdkSnapshot.docs.map(doc => ({
      id: doc.id,
      kode: doc.data().kode,
      nama: doc.data().nama
    }));

    // Nilai Magang 2-komponen (Dosen Pembimbing + Pendamping Lapangan) untuk
    // periode yang sedang dipilih - dipakai form input Pendamping Lapangan + tombol Kunci.
    let nilaiMagangInfo = null;
    if (selectedPeriod) {
      const nilaiMagang = await getNilaiMagang(userId, selectedPeriod.pdkId);
      // Data lama memakai kunci `logbook` (sekarang `laporan`) - isi awal form baru
      const itemsLapangan = { ...nilaiMagang.nilaiLapanganItems };
      if (itemsLapangan.laporan === undefined && itemsLapangan.logbook !== undefined) itemsLapangan.laporan = itemsLapangan.logbook;
      nilaiMagangInfo = {
        ...nilaiMagang,
        nilaiLapanganItemsForm: itemsLapangan,
        nilaiDosenEfektif: getNilaiDosenEfektif(nilaiMagang),
        rincianLapangan: hitungRincian(itemsLapangan, ITEM_PENDAMPING_LAPANGAN),
        hasil: hitungNilaiAkhirMagang(nilaiMagang)
      };
    }

    res.render('admin/emagang_mahasiswa', {
      durasiMagangBulan: DURASI_MAGANG_BULAN,
      title: `Logbook - ${mahasiswa.nama}`,
      mahasiswa,
      logbookList,
      semesterList,
      selectedSemester: semester || '',
      allPeriods,
      selectedPeriod,
      pdkStats,
      pdkList,
      bimbingan,
      nilaiMagangInfo,
      ITEM_PENDAMPING_LAPANGAN,
      KATEGORI_PENDAMPING: daftarKategori(ITEM_PENDAMPING_LAPANGAN),
      user: req.user
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).render('error', { message: 'Gagal mengambil data logbook' });
  }
});

// ============================================================================
// KELOLA PERIODE MAGANG (TIDAK BERUBAH)
// ============================================================================

router.post('/period/start', async (req, res) => {
  try {
    const { 
      mahasiswaId, pdkId, tanggalMulai, tanggalSelesai: tanggalSelesaiInput,
      namaPerusahaan, alamatPerusahaan, kontakPerusahaan, kontakHpPerusahaan,
      emailPerusahaan, websitePerusahaan, pembimbingLapangan, jabatanPembimbingLapangan
    } = req.body;
    // Tanggal selesai otomatis (tanggal mulai + durasi standar) bila tidak diisi
    const tanggalSelesai = tanggalSelesaiInput || hitungTanggalSelesaiMagang(tanggalMulai);
    
    if (!mahasiswaId || !pdkId || !tanggalMulai || !namaPerusahaan) {
      req.session.error = 'Data tidak lengkap. Nama perusahaan wajib diisi.';
      return res.redirect('back');
    }
    
    const pdkDoc = await db.collection('mataKuliah').doc(pdkId).get();
    if (!pdkDoc.exists) {
      req.session.error = 'Mata kuliah PDK tidak ditemukan';
      return res.redirect('back');
    }
    const pdk = pdkDoc.data();
    
    const bimbingan = await getBimbingan(mahasiswaId);
    if (!bimbingan) {
      req.session.error = 'Mahasiswa belum memiliki Dosen PA (dosen pembimbing) - tetapkan dulu di menu Mahasiswa';
      return res.redirect('back');
    }
    
    const existing = await db.collection('magangPeriod')
      .where('mahasiswaId', '==', mahasiswaId)
      .where('pdkId', '==', pdkId)
      .where('status', 'in', ['active', 'locked'])
      .get();
    
    if (!existing.empty) {
      req.session.error = `Mahasiswa sudah memiliki periode magang aktif untuk ${pdk.nama}`;
      return res.redirect('back');
    }
    
    // Validasi tanggal: urutan tanggal, tidak tumpang tindih, urutan Magang 1/2/3
    const galatPeriode = await validasiMulaiPeriode(db, { mahasiswaId, pdkId, tanggalMulai, tanggalSelesai });
    if (galatPeriode) {
      req.session.error = galatPeriode;
      return res.redirect('back');
    }

    // OTOMATIS KRS: kalau mahasiswa belum punya enrollment aktif untuk PDK ini,
    // buatkan KRS (approved) + enrollment langsung, supaya PDK muncul di KRS/KHS
    // dan lolos validasi PDK aktif tanpa admin harus "Buat KRS" manual dulu.
    // Kalau sudah ada enrollment aktif, tidak dibuat ganda.
    let krsOtomatis = false;
    const enrollAktif = await db.collection('enrollment')
      .where('userId', '==', mahasiswaId)
      .where('mkId', '==', pdkId)
      .where('status', '==', 'active')
      .limit(1)
      .get();
    if (enrollAktif.empty) {
      const academicLabel = getCurrentAcademicSemester().label;
      await createKrsDanEnrollment(db, mahasiswaId, [pdkId], academicLabel, req.user.id, {
        dibuatOlehSistem: true,
        catatan: `KRS otomatis saat periode magang ${pdk.nama} dimulai`
      });
      krsOtomatis = true;
    }

    const now = new Date().toISOString();
    await db.collection('magangPeriod').add({
      mahasiswaId,
      pdkId,
      pdkKode: pdk.kode,
      pdkNama: pdk.nama,
      tanggalMulai,
      tanggalSelesai: tanggalSelesai || null,
      status: 'active',
      pembimbingId: bimbingan.pembimbingId,
      pembimbingNama: bimbingan.pembimbingNama,
      perusahaan: {
        nama: namaPerusahaan,
        alamat: alamatPerusahaan || '',
        kontak: kontakPerusahaan || '',
        kontakHp: kontakHpPerusahaan || '',
        email: emailPerusahaan || '',
        website: websitePerusahaan || '',
        pembimbingLapangan: pembimbingLapangan || '',
        jabatanPembimbingLapangan: jabatanPembimbingLapangan || '',
        diisiOleh: req.user.id,
        diisiPada: now
      },
      nilai: { angka: null, huruf: null, komentar: null, dinilaiOleh: null, dinilaiPada: null, komponenNilai: {} },
      ulasan: { isFilled: false },
      lockHistory: [],
      createdAt: now,
      updatedAt: now,
      completedAt: null,
      history: [{
        action: 'started',
        tanggal: new Date().toISOString().split('T')[0],
        catatan: `Periode magang ${pdk.nama} di ${namaPerusahaan} dimulai oleh ${req.user.nama || 'Admin'}`
      }]
    });
    
    magangNotif.periodeDimulai(db, { mahasiswaId, perusahaan: namaPerusahaan, tanggalMulai, tanggalSelesai });
    req.session.success = `Periode magang ${pdk.nama} berhasil dimulai` + (krsOtomatis ? ` dan KRS ${pdk.nama} otomatis dibuatkan (${getCurrentAcademicSemester().label})` : '');
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal memulai periode magang';
    res.redirect('back');
  }
});

router.post('/period/:periodId/update-perusahaan', async (req, res) => {
  try {
    const { periodId } = req.params;
    const { namaPerusahaan, alamatPerusahaan, kontakPerusahaan, kontakHpPerusahaan,
      emailPerusahaan, websitePerusahaan, pembimbingLapangan, jabatanPembimbingLapangan } = req.body;
    
    const periodRef = db.collection('magangPeriod').doc(periodId);
    const periodDoc = await periodRef.get();
    if (!periodDoc.exists) {
      req.session.error = 'Periode magang tidak ditemukan';
      return res.redirect('back');
    }
    const mahasiswaId = periodDoc.data().mahasiswaId;
    
    await updatePerusahaanMagangPeriod(periodId, {
      nama: namaPerusahaan,
      alamat: alamatPerusahaan,
      kontak: kontakPerusahaan,
      kontakHp: kontakHpPerusahaan,
      email: emailPerusahaan,
      website: websitePerusahaan,
      pembimbingLapangan,
      jabatanPembimbingLapangan
    }, { id: req.user.id, nama: req.user.nama || 'Admin' });
    
    req.session.success = 'Informasi perusahaan berhasil diupdate';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal update perusahaan';
    res.redirect('back');
  }
});

router.post('/period/:periodId/lock', async (req, res) => {
  try {
    const { periodId } = req.params;
    const { reason } = req.body;
    const periodDoc = await db.collection('magangPeriod').doc(periodId).get();
    if (!periodDoc.exists) {
      req.session.error = 'Periode magang tidak ditemukan';
      return res.redirect('back');
    }
    const mahasiswaId = periodDoc.data().mahasiswaId;
    
    await lockMagangPeriod(periodId, reason, { id: req.user.id, nama: req.user.nama || 'Admin' });
    
    magangNotif.periodeDikunci(db, { mahasiswaId, alasan: reason, oleh: 'Admin' });
    req.session.success = 'Periode magang berhasil dikunci';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal mengunci periode magang: ' + error.message;
    res.redirect('back');
  }
});

router.post('/period/:periodId/unlock', async (req, res) => {
  try {
    const { periodId } = req.params;
    const { reason } = req.body;
    const periodDoc = await db.collection('magangPeriod').doc(periodId).get();
    if (!periodDoc.exists) {
      req.session.error = 'Periode magang tidak ditemukan';
      return res.redirect('back');
    }
    const mahasiswaId = periodDoc.data().mahasiswaId;
    
    await unlockMagangPeriod(periodId, reason, { id: req.user.id, nama: req.user.nama || 'Admin' });
    
    magangNotif.periodeDibuka(db, { mahasiswaId, oleh: 'Admin' });
    req.session.success = 'Periode magang berhasil dibuka';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal membuka kunci periode magang: ' + error.message;
    res.redirect('back');
  }
});

router.post('/period/:periodId/extend', async (req, res) => {
  try {
    const { periodId } = req.params;
    const { tanggalSelesaiBaru, catatan } = req.body;
    const periodDoc = await db.collection('magangPeriod').doc(periodId).get();
    if (!periodDoc.exists) {
      req.session.error = 'Periode magang tidak ditemukan';
      return res.redirect('back');
    }
    const mahasiswaId = periodDoc.data().mahasiswaId;
    
    await extendMagangPeriod(periodId, tanggalSelesaiBaru, catatan, { id: req.user.id, nama: req.user.nama || 'Admin' });
    
    magangNotif.periodeDiperpanjang(db, { mahasiswaId, tanggalSelesaiBaru, oleh: 'Admin' });
    req.session.success = 'Periode magang berhasil diperpanjang';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal memperpanjang periode magang: ' + error.message;
    res.redirect('back');
  }
});

// ============================================================================
// EDIT TANGGAL MULAI (Admin) - beda dari /extend yang cuma ubah tanggal
// selesai. Dipakai kalau tanggal mulai yang diinput waktu "Mulai Periode
// Baru" ternyata salah/perlu dikoreksi (bukan perpanjangan).
// ============================================================================
router.post('/period/:periodId/edit-tanggal-mulai', async (req, res) => {
  try {
    const { periodId } = req.params;
    const { tanggalMulaiBaru, catatan } = req.body;
    if (!tanggalMulaiBaru) {
      req.session.error = 'Tanggal mulai baru wajib diisi';
      return res.redirect('back');
    }
    const periodRef = db.collection('magangPeriod').doc(periodId);
    const periodDoc = await periodRef.get();
    if (!periodDoc.exists) {
      req.session.error = 'Periode magang tidak ditemukan';
      return res.redirect('back');
    }
    const period = periodDoc.data();
    const mahasiswaId = period.mahasiswaId;

    if (period.tanggalSelesai && tanggalMulaiBaru > period.tanggalSelesai) {
      req.session.error = 'Tanggal mulai baru tidak boleh setelah tanggal selesai';
      return res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
    }

    await editTanggalMulaiMagangPeriod(periodId, tanggalMulaiBaru, catatan, { id: req.user.id, nama: req.user.nama || 'Admin' });
    req.session.success = 'Tanggal mulai periode magang berhasil diubah';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error edit tanggal mulai:', error);
    req.session.error = 'Gagal mengubah tanggal mulai periode magang';
    res.redirect('back');
  }
});

// ============================================================================
// CATATAN: Route lama POST /period/:periodId/complete ("Selesaikan &
// Beri Nilai" - input satu nilaiAngka manual) SUDAH DIHAPUS. Digantikan
// sepenuhnya oleh alur 3-komponen di bawah (Nilai Laporan & Nilai Logbook
// oleh Dosen PA, Nilai Pendamping Lapangan oleh Admin) yang
// dikunci lewat kunciNilaiMagangKeGrades(). Route lama tidak mengecek
// ACC laporan/kunci logbook dan bisa menimpa nilai yang sudah dikunci
// lewat alur baru. Jangan tambahkan lagi.
// ============================================================================
// NILAI MAGANG 3-KOMPONEN (Laporan/Logbook/Lapangan) - lihat
// helpers/nilaiMagangHelper.js untuk penjelasan lengkap sistemnya. Ini
// PENGGANTI dari '/period/:periodId/complete' di atas (yang masih
// dipertahankan untuk kompatibilitas data lama / input cepat satu nilai).
// ============================================================================

/**
 * POST /admin/emagang/mahasiswa/:userId/nilai-lapangan
 * Admin input Nilai Lapangan (mewakili pembimbing lapangan di perusahaan,
 * yang tidak punya akses ke sistem).
 */
/**
 * POST /admin/emagang/mahasiswa/:userId/nilai-lapangan
 * Admin input Nilai Pendamping Lapangan (mewakili pendamping lapangan di
 * IDUKA, yang tidak punya akses ke sistem) - 10 indikator (format baru), lihat
 * ITEM_PENDAMPING_LAPANGAN.
 */
router.post('/mahasiswa/:userId/nilai-lapangan', async (req, res) => {
  try {
    const { userId } = req.params;
    const { pdkId } = req.body;
    if (!pdkId) {
      req.session.error = 'Pilih periode magang (PDK) dulu';
      return res.redirect('back');
    }

    const itemScores = {};
    for (const it of ITEM_PENDAMPING_LAPANGAN) {
      const v = req.body.item ? req.body.item[it.key] : undefined;
      const angka = parseFloat(v);
      if (v === undefined || v === '' || isNaN(angka) || angka < 0 || angka > 100) {
        req.session.error = `Isi semua ${ITEM_PENDAMPING_LAPANGAN.length} indikator dengan angka 0-100 (indikator "${it.label}" belum valid).`;
        return res.redirect('back');
      }
      itemScores[it.key] = angka;
    }

    await savePenilaianPendampingLapangan(userId, pdkId, itemScores, req.user.id, req.body.catatan);
    req.session.success = 'Nilai Pendamping Lapangan berhasil disimpan';
    res.redirect(`/admin/emagang/mahasiswa/${userId}?periodId=${req.body.periodId || ''}`);
  } catch (error) {
    console.error('Error menyimpan Nilai Pendamping Lapangan:', error);
    req.session.error = 'Gagal menyimpan Nilai Pendamping Lapangan: ' + error.message;
    res.redirect('back');
  }
});

/**
 * GET /admin/emagang/print-penilaian/:userId?periodId=&jenis=dosen|lapangan
 * Cetak FORM PENILAIAN MAGANG INDUSTRI (format resmi) - jenis `dosen` (diisi
 * Dosen Pembimbing) atau `lapangan` (diisi Pendamping Lapangan di IDUKA).
 */
router.get('/print-penilaian/:userId', async (req, res) => {
  try {
    const jenis = req.query.jenis === 'lapangan' ? 'lapangan' : 'dosen';
    const data = await buildFormPenilaianData(req.params.userId, req.query.periodId, jenis, req.query.kosong === '1');
    if (!data) return res.status(404).send('Data mahasiswa tidak ditemukan');
    res.render('magang/form_penilaian_print', data);
  } catch (error) {
    console.error('Error cetak form penilaian (admin):', error);
    res.status(500).send('Gagal mencetak form penilaian');
  }
});

/**
 * POST /admin/emagang/mahasiswa/:userId/kunci-nilai-magang
 * Kunci nilai akhir magang (gabungan 2 komponen: Dosen Pembimbing + Pendamping
 * Lapangan) ke koleksi grades/KHS. Ditolak kalau salah satu komponen belum terisi.
 */
router.post('/mahasiswa/:userId/kunci-nilai-magang', async (req, res) => {
  try {
    const { userId } = req.params;
    const { pdkId, periodId } = req.body;
    if (!pdkId) {
      req.session.error = 'PDK tidak diketahui';
      return res.redirect('back');
    }
    const hasil = await kunciNilaiMagangKeGrades(userId, pdkId, req.user.id);
    magangNotif.nilaiMagangKeluar(db, { mahasiswaId: userId, huruf: hasil.huruf });
    req.session.success = `Nilai akhir magang berhasil dikunci: ${hasil.huruf} (${hasil.nilaiAkhir}) - sudah masuk ke KHS/Transkrip mahasiswa.`;
    res.redirect(`/admin/emagang/mahasiswa/${userId}?periodId=${periodId || ''}`);
  } catch (error) {
    console.error('Error kunci nilai magang:', error);
    req.session.error = 'Gagal mengunci nilai: ' + error.message;
    res.redirect('back');
  }
});


// ============================================================================
// APPROVE/REJECT LOGBOOK
// ============================================================================

router.post('/logbook/:id/approve', async (req, res) => {
  try {
    const logbookId = req.params.id;
    const logbookDoc = await db.collection('logbookMagang').doc(logbookId).get();
    if (!logbookDoc.exists) {
      req.session.error = 'Logbook tidak ditemukan';
      return res.redirect('back');
    }
    const logbook = logbookDoc.data();
    const mahasiswaId = logbook.userId;
    await logbookDoc.ref.update({
      status: 'approved',
      approvedAt: new Date().toISOString(),
      approvedBy: req.user.id,
      approvedByNama: req.user.nama || 'Admin',
      approvedByRole: 'Admin'
    });
    invalidateProgressMagangHarian(mahasiswaId, logbook.pdkId);
    magangNotif.logbookDisetujui(db, { mahasiswaId, tanggal: logbook.tanggal, oleh: 'Admin' });
    req.session.success = 'Logbook berhasil disetujui';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal menyetujui logbook';
    res.redirect('back');
  }
});

router.post('/logbook/:id/reject', async (req, res) => {
  try {
    const logbookId = req.params.id;
    const { alasan } = req.body;
    const logbookDoc = await db.collection('logbookMagang').doc(logbookId).get();
    if (!logbookDoc.exists) {
      req.session.error = 'Logbook tidak ditemukan';
      return res.redirect('back');
    }
    const logbook = logbookDoc.data();
    const mahasiswaId = logbook.userId;
    await logbookDoc.ref.update({
      status: 'rejected',
      rejectedAt: new Date().toISOString(),
      rejectedBy: req.user.id,
      rejectedByNama: req.user.nama || 'Admin',
      rejectedByRole: 'Admin',
      rejectionReason: alasan || 'Tidak ada alasan'
    });
    invalidateProgressMagangHarian(mahasiswaId, logbook.pdkId);
    magangNotif.logbookDitolak(db, { mahasiswaId, tanggal: logbook.tanggal, alasan, oleh: 'Admin' });
    req.session.success = 'Logbook berhasil ditolak';
    res.redirect(`/admin/emagang/mahasiswa/${mahasiswaId}`);
  } catch (error) {
    console.error('Error:', error);
    req.session.error = 'Gagal menolak logbook';
    res.redirect('back');
  }
});

// ============================================================================
// SETUJUI LOGBOOK 1 MINGGU SEKALIGUS (Admin)
// ============================================================================
// Sama seperti versi dosen (routes/dosen/magang.js) - menyetujui semua
// logbook 'pending' mahasiswa ini dalam 7 hari terakhir sekaligus, supaya
// admin tidak perlu klik "Setujui" satu per satu untuk tiap entri harian.
router.post('/mahasiswa/:userId/setujui-minggu', async (req, res) => {
  try {
    const { userId } = req.params;
    const { periodId } = req.body;

    let pdkId = null;
    if (periodId) {
      const periodDoc = await db.collection('magangPeriod').doc(periodId).get();
      if (!periodDoc.exists) {
        req.session.error = 'Periode magang tidak ditemukan';
        return res.redirect(`/admin/emagang/mahasiswa/${userId}`);
      }
      pdkId = periodDoc.data().pdkId;
    }

    // Rentang 7 hari terakhir (hari ini mundur 6 hari), format YYYY-MM-DD.
    const hariIni = new Date();
    const tujuhHariLalu = new Date(hariIni);
    tujuhHariLalu.setDate(hariIni.getDate() - 6);
    const tanggalAkhir = hariIni.toISOString().split('T')[0];
    const tanggalAwal = tujuhHariLalu.toISOString().split('T')[0];

    let query = db.collection('logbookMagang')
      .where('userId', '==', userId)
      .where('status', '==', 'pending');
    if (pdkId) query = query.where('pdkId', '==', pdkId);
    const pendingSnapshot = await query.get();

    const docsMingguIni = pendingSnapshot.docs.filter(doc => {
      const tgl = doc.data().tanggal;
      return tgl && tgl >= tanggalAwal && tgl <= tanggalAkhir;
    });

    if (docsMingguIni.length === 0) {
      req.session.error = 'Tidak ada logbook pending dalam 7 hari terakhir untuk disetujui';
      return res.redirect(`/admin/emagang/mahasiswa/${userId}${periodId ? `?periodId=${periodId}` : ''}`);
    }

    const now = new Date().toISOString();
    const catatan = 'Mahasiswa telah konsultasi dan logbook disetujui';
    const batch = db.batch();
    docsMingguIni.forEach(doc => {
      batch.update(doc.ref, {
        status: 'approved',
        approvedAt: now,
        approvedBy: req.user.id,
        approvedByNama: req.user.nama || 'Admin',
        approvedByRole: 'Admin',
        catatan
      });
    });
    await batch.commit();

    const pdkIdUntukInvalidasi = pdkId
      ? [pdkId]
      : [...new Set(docsMingguIni.map(doc => doc.data().pdkId).filter(Boolean))];
    pdkIdUntukInvalidasi.forEach(pid => invalidateProgressMagangHarian(userId, pid));

    magangNotif.logbookBanyakDisetujui(db, { mahasiswaId: userId, jumlah: docsMingguIni.length, oleh: 'Admin' });
    req.session.success = `${docsMingguIni.length} logbook (7 hari terakhir) berhasil disetujui sekaligus`;
    res.redirect(`/admin/emagang/mahasiswa/${userId}${periodId ? `?periodId=${periodId}` : ''}`);
  } catch (error) {
    console.error('Error setujui logbook per minggu (admin):', error);
    req.session.error = 'Gagal menyetujui logbook per minggu';
    res.redirect('back');
  }
});

// ============================================================================
// SETUJUI SEMUA LOGBOOK PENDING (Admin) - tanpa batas 7 hari, semua yang
// masih 'pending' untuk mahasiswa ini (opsional difilter per periode PDK
// kalau periodId dikirim).
// ============================================================================
router.post('/mahasiswa/:userId/setujui-semua', async (req, res) => {
  try {
    const { userId } = req.params;
    const { periodId } = req.body;

    let pdkId = null;
    if (periodId) {
      const periodDoc = await db.collection('magangPeriod').doc(periodId).get();
      if (!periodDoc.exists) {
        req.session.error = 'Periode magang tidak ditemukan';
        return res.redirect(`/admin/emagang/mahasiswa/${userId}`);
      }
      pdkId = periodDoc.data().pdkId;
    }

    let query = db.collection('logbookMagang')
      .where('userId', '==', userId)
      .where('status', '==', 'pending');
    if (pdkId) query = query.where('pdkId', '==', pdkId);
    const pendingSnapshot = await query.get();

    if (pendingSnapshot.empty) {
      req.session.error = 'Tidak ada logbook pending untuk disetujui';
      return res.redirect(`/admin/emagang/mahasiswa/${userId}${periodId ? `?periodId=${periodId}` : ''}`);
    }

    const now = new Date().toISOString();
    const catatan = 'Disetujui sekaligus (Setujui Semua) oleh Admin';
    // Firestore batch dibatasi maks 500 operasi - pecah jadi beberapa batch
    // kalau logbook pending-nya sangat banyak.
    const docs = pendingSnapshot.docs;
    for (let i = 0; i < docs.length; i += 450) {
      const batch = db.batch();
      docs.slice(i, i + 450).forEach(doc => {
        batch.update(doc.ref, {
          status: 'approved',
          approvedAt: now,
          approvedBy: req.user.id,
          approvedByNama: req.user.nama || 'Admin',
          approvedByRole: 'Admin',
          catatan
        });
      });
      await batch.commit();
    }

    const pdkIdUntukInvalidasi = pdkId
      ? [pdkId]
      : [...new Set(docs.map(doc => doc.data().pdkId).filter(Boolean))];
    pdkIdUntukInvalidasi.forEach(pid => invalidateProgressMagangHarian(userId, pid));

    magangNotif.logbookBanyakDisetujui(db, { mahasiswaId: userId, jumlah: docs.length, oleh: 'Admin' });
    req.session.success = `${docs.length} logbook pending berhasil disetujui semua sekaligus`;
    res.redirect(`/admin/emagang/mahasiswa/${userId}${periodId ? `?periodId=${periodId}` : ''}`);
  } catch (error) {
    console.error('Error setujui semua logbook (admin):', error);
    req.session.error = 'Gagal menyetujui semua logbook';
    res.redirect('back');
  }
});

// ============================================================================
// CETAK LOGBOOK (OPTIMASI)
// ============================================================================

// Cetak memakai template & data yang SAMA dengan cetak mahasiswa
// (helpers/logbookPrintHelper.js -> views/mahasiswa/magang/print.ejs).
// Cetak per mahasiswa: wajib ?userId=... (periodId opsional).
router.get('/print', async (req, res) => {
  try {
    const { userId, periodId } = req.query;
    if (!userId) {
      return res.status(400).send('Pilih mahasiswa dulu: cetak logbook dilakukan per mahasiswa (parameter userId).');
    }
    const data = await buildLogbookPrintData(userId, periodId);
    if (!data) return res.status(404).send('Data mahasiswa tidak ditemukan');
    tampilkanCetakLogbook(req, res, { ...data, title: `Cetak Logbook - ${data.mahasiswa.nama}`, user: req.user });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Gagal mencetak logbook');
  }
});

// ============================================================================
// API ENDPOINT
// ============================================================================

router.get('/api/mahasiswa', async (req, res) => {
  try {
    const semua = await getAllMahasiswa(db); // cache bersama, bukan scan ulang tiap panggilan
    const data = semua
      .map(m => ({ id: m.id, nama: m.nama, nim: m.nim }))
      .sort((a, b) => String(a.nama || '').localeCompare(String(b.nama || '')));
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/api/periods/:userId', async (req, res) => {
  try {
    const periods = await getMagangPeriods(req.params.userId);
    res.json({ success: true, data: periods });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;