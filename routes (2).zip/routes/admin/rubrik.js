// routes/admin/rubrik.js
// Rekap Rubrik Penilaian SELURUH Mata Kuliah (Admin/Kaprodi).
// Admin bisa melihat hasil rubrik (kehadiran, sikap, keaktifan, tugas, kuis,
// UTS, UAS, nilai akhir, huruf) untuk setiap MK dari semua dosen, mencetaknya,
// dan mengunci nilai akhir seorang mahasiswa ke koleksi 'grades' resmi
// (dipakai transkrip/KHS) memakai saveGradeFinal yang sudah ada.

const express = require('express');
const router = express.Router();
const { verifyToken, isAdmin } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const {
  getPeriodeAktif,
  getHasilRubrikSemuaMahasiswa,
  getRincianTugasByMkId,
  getKontrakKuliah,
  hitungRubrik,
  saveGradeFinal,
  saveGradeFinalBulk,
  getStatusKunciByMkId
} = require('../../helpers/nilaiHelper');
const { getSemesterForDate } = require('../../helpers/academicHelper');
const { getNilaiMagangBanyak, hitungNilaiAkhirMagang } = require('../../helpers/nilaiMagangHelper');

router.use(verifyToken);
router.use(isAdmin);

// ✅ OPTIMISASI KUOTA: cache nama dosen dalam satu request (banyak MK sering
// diampu oleh dosen yang sama, jadi tidak perlu baca dokumen `users` yang
// sama berkali-kali).
const _dosenNamaCache = new Map();
async function getDosenNamaByIds(dosenIds = []) {
  const idBelumAda = dosenIds.filter(id => !_dosenNamaCache.has(id));
  if (idBelumAda.length > 0) {
    const refs = idBelumAda.map(id => db.collection('users').doc(id));
    const docs = await db.getAll(...refs);
    docs.forEach((doc, i) => {
      _dosenNamaCache.set(idBelumAda[i], doc.exists ? (doc.data().nama || idBelumAda[i]) : idBelumAda[i]);
    });
  }
  return dosenIds.map(id => _dosenNamaCache.get(id)).join(', ');
}

/**
 * Ambil banyak dokumen `users` SEKALIGUS (satu round-trip via db.getAll),
 * bukan satu per satu dalam loop - dipakai utk daftar mahasiswa di halaman
 * detail rubrik/cetak.
 */
async function getMahasiswaBanyak(uids) {
  if (uids.length === 0) return {};
  const refs = uids.map(uid => db.collection('users').doc(uid));
  const docs = await db.getAll(...refs);
  const map = {};
  docs.forEach((doc, i) => {
    map[uids[i]] = doc.exists ? { id: uids[i], ...doc.data() } : { id: uids[i], nama: 'Unknown', nim: '-' };
  });
  return map;
}

/**
 * Versi ambilDataRubrik KHUSUS MK PDK/Magang - lihat komentar lebih
 * lengkap di routes/dosen/rubrik.js (fungsi sama persis).
 */
async function ambilDataRubrikPDK(mk, mahasiswaIds, periode) {
  const [mahasiswaMap, nilaiMagangMap, statusKunciMap] = await Promise.all([
    getMahasiswaBanyak(mahasiswaIds),
    getNilaiMagangBanyak(mk.id),
    getStatusKunciByMkId(mk.kode, periode)
  ]);

  const data = mahasiswaIds.map(uid => {
    const mahasiswa = mahasiswaMap[uid];
    const nm = nilaiMagangMap.get(uid) || {
      nilaiLaporan: null, nilaiLogbook: null, nilaiLapangan: null, logbookDikunci: false
    };
    const hitungan = hitungNilaiAkhirMagang(nm);

    const kunciInfo = statusKunciMap.get(uid);
    let kunci = { terkunci: false, nilaiTerkunci: null, berbeda: false };
    if (kunciInfo) {
      const beda = hitungan.nilaiAkhir === null
        ? true
        : Math.round(hitungan.nilaiAkhir * 100) / 100 !== Math.round(kunciInfo.nilaiTerkunci * 100) / 100;
      kunci = { terkunci: true, nilaiTerkunci: kunciInfo.nilaiTerkunci, berbeda: beda };
    }

    return {
      mahasiswa,
      komponen: {},
      isPDK: true,
      nilaiMagang: nm,
      hasil: {
        nilaiAkhir: hitungan.nilaiAkhir,
        huruf: hitungan.huruf,
        keterangan: hitungan.keterangan,
        belumLengkap: hitungan.belumLengkap
      },
      kunci
    };
  });
  data.sort((a, b) => String(a.mahasiswa.nim).localeCompare(String(b.mahasiswa.nim)));

  return { mk, bobot: null, data, isPDK: true };
}

async function ambilDataRubrik(mkId, periode) {
  const mkDoc = await db.collection('mataKuliah').doc(mkId).get();
  if (!mkDoc.exists) return null;
  const mk = { id: mkId, ...mkDoc.data() };

  const enrollmentSnapshot = await db.collection('enrollment')
    .where('mkId', '==', mkId)
    .where('status', '==', 'active')
    .get();
  const mahasiswaIds = enrollmentSnapshot.docs.map(d => d.data().userId);

  if (mk.isPDK === true) {
    return await ambilDataRubrikPDK(mk, mahasiswaIds, periode);
  }

  const { bobot, komponenMap, hasilMap } = await getHasilRubrikSemuaMahasiswa(mkId, periode);
  const [mahasiswaMap, statusKunciMap] = await Promise.all([
    getMahasiswaBanyak(mahasiswaIds), // 1 round-trip, bukan N
    getStatusKunciByMkId(mk.kode, periode)
  ]);

  const data = mahasiswaIds.map(uid => {
    const mahasiswa = mahasiswaMap[uid];
    const komponen = komponenMap[uid] || {};
    const hasil = hasilMap[uid] || hitungRubrik({}, null, bobot);

    // Status kunci ke transkrip - lihat komentar di getStatusKunciByMkId()
    const kunciInfo = statusKunciMap.get(uid);
    let kunci = { terkunci: false, nilaiTerkunci: null, berbeda: false };
    if (kunciInfo) {
      const beda = hasil.nilaiAkhir === null
        ? true // nilai saat ini malah jadi tidak lengkap lagi - tetap tandai beda
        : Math.round(hasil.nilaiAkhir * 100) / 100 !== Math.round(kunciInfo.nilaiTerkunci * 100) / 100;
      kunci = { terkunci: true, nilaiTerkunci: kunciInfo.nilaiTerkunci, berbeda: beda };
    }

    return { mahasiswa, komponen, hasil, kunci };
  });
  data.sort((a, b) => String(a.mahasiswa.nim).localeCompare(String(b.mahasiswa.nim)));

  return { mk, bobot, data };
}

/**
 * Susun rincian nilai per-tugas (WEB + MANUAL) untuk halaman cetak
 * "Penilaian" - pakai ulang hasil.data (tidak query enrollment lagi) dan
 * getRincianTugasByMkId (sumber sama dengan halaman Rincian Tugas dosen).
 */
async function ambilDataPenilaian(mkId, periode, hasilRubrik) {
  const { tugasList, perMahasiswa } = await getRincianTugasByMkId(mkId, periode);
  const data = hasilRubrik.data.map(item => {
    const uid = item.mahasiswa.id;
    const nilaiMahasiswa = perMahasiswa[uid] || {};
    const nilaiPerTugas = tugasList.map(tugas => ({
      tugasId: tugas.id,
      nilai: nilaiMahasiswa[tugas.id] ?? null
    }));
    return { mahasiswa: item.mahasiswa, nilaiPerTugas };
  });
  return { tugasList, data };
}

/**
 * Susun daftar 16 pertemuan dari field `materi` mataKuliah, untuk halaman
 * cetak "Berita Acara Pengajaran". Fungsi murni (tidak akses DB).
 */
function ambilDataPertemuan(mk) {
  const materi = mk.materi || [];
  const pertemuanList = [];
  for (let i = 1; i <= 16; i++) {
    const existing = materi.find(m => m.pertemuan === i) || {};
    pertemuanList.push({
      pertemuan: i,
      topik: existing.topik || '',
      tanggal: existing.tanggal || null,
      adaMateri: !!(existing.fileUrl || existing.topik),
      catatan: existing.catatan || ''
    });
  }
  return pertemuanList;
}

/**
 * Admin tidak punya req.dosen sendiri (bukan dosen), jadi utk NUPTK di
 * dokumen cetak, ambil dari dosen PERTAMA yang mengampu MK ini.
 */
async function getNuptkDosenPertama(dosenIds = []) {
  if (dosenIds.length === 0) return '-';
  try {
    const doc = await db.collection('users').doc(dosenIds[0]).get();
    if (!doc.exists) return '-';
    return doc.data().nuptk || doc.data().nidn || '-';
  } catch {
    return '-';
  }
}

// ============================================================================
// DAFTAR SEMUA MATA KULIAH (lintas dosen)
// ============================================================================
router.get('/', async (req, res) => {
  try {
    const periode = req.query.periode || getPeriodeAktif();
    const mkSnapshot = await db.collection('mataKuliah').orderBy('kode').get();

    // ✅ OPTIMISASI KUOTA: sebelumnya, untuk SETIAP mata kuliah di daftar ini,
    // sistem membaca ULANG SELURUH koleksi 'nilai' MK tsb DUA KALI
    // (getKomponenRubrikByMkId + getRataTugasByMkId) hanya untuk menghitung
    // "berapa mahasiswa yang rubriknya sudah lengkap" - padahal itu cuma
    // angka ringkasan di halaman daftar. Kalau prodi punya puluhan MK, itu
    // artinya puluhan kali pembacaan penuh koleksi 'nilai' SETIAP KALI
    // admin membuka halaman ini. Sekarang dihapus dari sini - angka
    // kelengkapan lengkap tetap bisa dilihat dengan klik ke detail MK
    // (yang memang perlu baca data itu, tapi cuma untuk 1 MK, bukan semua).
    // Jumlah mahasiswa per MK juga dipakai count() aggregation (bukan
    // membaca semua dokumen enrollment).
    const mkList = await Promise.all(mkSnapshot.docs.map(async (doc) => {
      const mk = { id: doc.id, ...doc.data() };
      const [jumlahMahasiswa, namaDosen] = await Promise.all([
        db.collection('enrollment')
          .where('mkId', '==', doc.id)
          .where('status', '==', 'active')
          .count().get()
          .then(s => s.data().count)
          .catch(async () => {
            const s = await db.collection('enrollment').where('mkId', '==', doc.id).where('status', '==', 'active').get();
            return s.size;
          }),
        getDosenNamaByIds(mk.dosenIds || [])
      ]);
      mk.jumlahMahasiswa = jumlahMahasiswa;
      mk.namaDosen = namaDosen;
      return mk;
    }));

    res.render('admin/rubrik_list', {
      title: 'Rekap Rubrik Penilaian - Semua Mata Kuliah',
      mkList,
      periode
    });
  } catch (error) {
    console.error('Error daftar rubrik admin:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat daftar rubrik: ' + error.message });
  }
});

// ============================================================================
// DETAIL RUBRIK SATU MK (READ-ONLY REKAP, semua komponen + nilai akhir)
// ============================================================================
router.get('/:mkId', async (req, res) => {
  try {
    const periode = req.query.periode || getPeriodeAktif();
    const hasil = await ambilDataRubrik(req.params.mkId, periode);
    if (!hasil) {
      return res.status(404).render('error', { title: 'Tidak Ditemukan', message: 'Mata kuliah tidak ditemukan' });
    }
    hasil.mk.namaDosen = await getDosenNamaByIds(hasil.mk.dosenIds || []);

    // --- Diagnostik: MK duplikat (kode sama, ID beda) + tugas/nilai yang
    // tercatat di periode lain - lihat komentar lebih lengkap di
    // routes/dosen/rubrik.js pada diagnostik yang sama.
    let mkDuplikat = [];
    let periodeLain = [];
    let jumlahNilaiTugasTanpaTugas = 0;
    try {
      const [mkSnapshot, tugasSemuaPeriode, nilaiMentahSnapshot] = await Promise.all([
        db.collection('mataKuliah').where('kode', '==', hasil.mk.kode).get(),
        db.collection('tugas').where('mkId', '==', req.params.mkId).get(),
        db.collection('nilai').where('mkId', '==', req.params.mkId).get()
      ]);
      mkDuplikat = mkSnapshot.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter(m => m.id !== req.params.mkId);

      const periodeSet = new Set();
      tugasSemuaPeriode.docs.forEach(d => {
        const p = d.data().periode;
        if (p && p !== periode) periodeSet.add(p);
      });
      periodeLain = Array.from(periodeSet).sort();

      const tugasIdSet = new Set(tugasSemuaPeriode.docs.map(d => d.id));
      jumlahNilaiTugasTanpaTugas = nilaiMentahSnapshot.docs.filter(d => {
        const tipe = d.data().tipe || '';
        if (!tipe.startsWith('tugas_')) return false;
        return !tugasIdSet.has(tipe.replace('tugas_', ''));
      }).length;
    } catch (diagErr) {
      console.error('Diagnostik rubrik admin gagal (diabaikan):', diagErr);
    }

    res.render('admin/rubrik_detail', {
      title: `Rubrik Penilaian - ${hasil.mk.kode} ${hasil.mk.nama}`,
      mk: hasil.mk,
      bobot: hasil.bobot || {},
      data: hasil.data,
      periode,
      mkDuplikat,
      periodeLain,
      jumlahNilaiTugasTanpaTugas,
      isPDK: !!hasil.isPDK
    });
  } catch (error) {
    console.error('Error detail rubrik admin:', error);
    res.status(500).render('error', { title: 'Error', message: 'Gagal memuat detail rubrik: ' + error.message });
  }
});

// ============================================================================
// KUNCI NILAI AKHIR -> koleksi 'grades' resmi (dipakai transkrip/KHS/IPK)
// ============================================================================
router.post('/:mkId/kunci/:mahasiswaId', async (req, res) => {
  try {
    const { mkId, mahasiswaId } = req.params;
    const periode = req.body.periode || getPeriodeAktif();

    const hasil = await ambilDataRubrik(mkId, periode);
    if (!hasil) return res.status(404).json({ success: false, message: 'MK tidak ditemukan' });

    const item = hasil.data.find(d => d.mahasiswa.id === mahasiswaId);
    if (!item || item.hasil.nilaiAkhir === null) {
      return res.status(400).json({ success: false, message: 'Komponen rubrik mahasiswa ini belum lengkap' });
    }

    await saveGradeFinal({
      userId: mahasiswaId,
      kodeMk: hasil.mk.kode,
      namaMk: hasil.mk.nama,
      sks: hasil.mk.sks,
      nilai: item.hasil.nilaiAkhir,
      semester: periode
    });

    res.json({ success: true, nilaiAkhir: item.hasil.nilaiAkhir, huruf: item.hasil.huruf });
  } catch (error) {
    console.error('Error kunci nilai akhir dari rubrik:', error);
    res.status(500).json({ success: false, message: 'Gagal mengunci nilai: ' + error.message });
  }
});

// ============================================================================
// KUNCI SEMUA NILAI AKHIR SEKELAS SEKALIGUS -> koleksi 'grades' resmi
// ============================================================================
router.post('/:mkId/kunci-semua', async (req, res) => {
  try {
    const { mkId } = req.params;
    const periode = req.body.periode || getPeriodeAktif();

    const hasil = await ambilDataRubrik(mkId, periode);
    if (!hasil) return res.status(404).json({ success: false, message: 'MK tidak ditemukan' });

    const siapDikunci = hasil.data.filter(d => d.hasil.nilaiAkhir !== null);
    const belumLengkap = hasil.data.length - siapDikunci.length;

    if (siapDikunci.length === 0) {
      return res.status(400).json({ success: false, message: 'Belum ada mahasiswa dengan nilai akhir lengkap di MK ini' });
    }

    const items = siapDikunci.map(d => ({
      userId: d.mahasiswa.id,
      namaMk: hasil.mk.nama,
      sks: hasil.mk.sks,
      nilai: d.hasil.nilaiAkhir
    }));

    const { count } = await saveGradeFinalBulk(hasil.mk.kode, periode, items);

    res.json({
      success: true,
      count,
      belumLengkap,
      pesan: belumLengkap > 0
        ? `${count} nilai berhasil dikunci ke transkrip. ${belumLengkap} mahasiswa dilewati karena rubriknya belum lengkap.`
        : `${count} nilai berhasil dikunci ke transkrip.`
    });
  } catch (error) {
    console.error('Error kunci semua nilai akhir dari rubrik:', error);
    res.status(500).json({ success: false, message: 'Gagal mengunci nilai sekelas: ' + error.message });
  }
});

// ============================================================================
// CETAK DOKUMEN PERKULIAHAN (5 halaman - view sama dengan dosen)
// ============================================================================
router.get('/:mkId/cetak', async (req, res) => {
  try {
    const { mkId } = req.params;
    const periode = req.query.periode || getPeriodeAktif();
    const hasil = await ambilDataRubrik(mkId, periode);
    if (!hasil) return res.status(404).send('Mata kuliah tidak ditemukan');
    hasil.mk.namaDosen = await getDosenNamaByIds(hasil.mk.dosenIds || []);

    const [nuptkDosen, penilaian, kontrakKuliah] = await Promise.all([
      getNuptkDosenPertama(hasil.mk.dosenIds || []),
      ambilDataPenilaian(mkId, periode, hasil),
      getKontrakKuliah(mkId, periode)
    ]);
    const pertemuanList = ambilDataPertemuan(hasil.mk);
    const terlaksana = pertemuanList.filter(p => p.adaMateri).length;
    const infoSemester = getSemesterForDate(new Date());

    res.render('rubrik_print', {
      title: `Cetak Dokumen Perkuliahan - ${hasil.mk.kode}`,
      mk: hasil.mk,
      bobot: hasil.bobot || {},
      data: hasil.data,
      periode,
      namaDosen: hasil.mk.namaDosen,
      nuptkDosen,
      penilaian,
      pertemuanList,
      terlaksana,
      infoSemester,
      kontrakKuliah
    });
  } catch (error) {
    console.error('Error cetak rubrik admin:', error);
    res.status(500).send('Gagal memuat halaman cetak: ' + error.message);
  }
});

module.exports = router;
