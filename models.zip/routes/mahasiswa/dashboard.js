/**
 * routes/mahasiswa/dashboard.js
 * Dashboard utama mahasiswa
 */

const express = require('express');
const router = express.Router();
const { verifyToken } = require('../../middleware/auth');
const { db } = require('../../config/firebaseAdmin');
const { getCurrentAcademicSemester } = require('../../helpers/academicHelper');
const { getPublishedModulPraktikum } = require('../../helpers/modulPraktikumHelper');
const semesterSekarang = getCurrentAcademicSemester().label;
router.use(verifyToken);

// ============================================================================
// FUNGSI BANTU
// ============================================================================

async function getTagihan(userId) {
  try {
    const tagihanDoc = await db.collection('tagihan').doc(userId).get();
    return tagihanDoc.exists ? tagihanDoc.data().semester || [] : [];
  } catch (error) {
    console.error('Error getTagihan:', error);
    return [];
  }
}

async function getMataKuliahDiambil(userId) {
  try {
    const enrollmentSnapshot = await db.collection('enrollment')
      .where('userId', '==', userId)
      .where('status', '==', 'active')
      .get();

    // ✅ OPTIMISASI KUOTA: ambil semua dokumen mataKuliah SEKALIGUS lewat
    // db.getAll(), bukan satu per satu di dalam loop serial. Halaman ini
    // dibuka SETIAP mahasiswa SETIAP login, jadi kecil pun penghematannya
    // dikali jumlah mahasiswa jadi besar.
    const enrollments = enrollmentSnapshot.docs.map(doc => ({ id: doc.id, data: doc.data() }));
    if (enrollments.length === 0) return [];

    const mkDocs = await db.getAll(...enrollments.map(e => db.collection('mataKuliah').doc(e.data.mkId)));
    const mkList = [];
    mkDocs.forEach((mkDoc, i) => {
      if (mkDoc.exists) {
        mkList.push({
          id: enrollments[i].data.mkId,
          ...mkDoc.data(),
          enrollmentId: enrollments[i].id,
          semesterEnrollment: enrollments[i].data.semester,
          tahunAjaran: enrollments[i].data.tahunAjaran
        });
      }
    });
    return mkList;
  } catch (error) {
    console.error('Error getMataKuliahDiambil:', error);
    return [];
  }
}

function getPertemuanTerkini(mk) {
  if (!mk.materi || !Array.isArray(mk.materi)) return 0;
  return mk.materi.filter(m => m.status === 'selesai').length;
}

async function getTugasAktif(mkIds) {
  try {
    if (mkIds.length === 0) return [];
    const now = new Date().toISOString();

    // ✅ OPTIMISASI KUOTA: sebelumnya query 'tugas' dijalankan TERPISAH utk
    // SETIAP mata kuliah (N query utk N MK yang diambil mahasiswa - mahasiswa
    // dg 8 MK = 8 query serial). Sekarang di-batch pakai `where(...,'in',...)`
    // per 10 mkId sekaligus, jadi maksimal N/10 query, dijalankan paralel.
    //
    // ⚠️ PENTING: filter deadline SENGAJA tidak ditaruh di query Firestore
    // (mis. .where('deadline','>',now)) karena kombinasi filter `in` +
    // filter rentang (>) pada field BERBEDA butuh composite index manual di
    // Firestore Console. Kalau index itu belum dibuat, query akan gagal
    // (exception), ketangkap oleh catch di bawah, dan diam-diam SELALU
    // mengembalikan array kosong - akibatnya "Tugas Aktif" di dashboard
    // tampak selalu kosong walau sebenarnya ada tugas aktif. Makanya filter
    // deadline dilakukan di JS setelah data diambil, supaya tidak
    // bergantung pada index tambahan apa pun.
    function chunkArray(arr, size) {
      const chunks = [];
      for (let i = 0; i < arr.length; i += size) chunks.push(arr.slice(i, i + size));
      return chunks;
    }
    const chunks = chunkArray(mkIds, 10);
    const snapshots = await Promise.all(chunks.map(chunk =>
      db.collection('tugas')
        .where('mkId', 'in', chunk)
        .get()
    ));

    const tugasList = [];
    snapshots.forEach(snapshot => {
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        // Hanya tugas yang deadline-nya masih di depan (belum lewat)
        if (data.deadline && data.deadline > now) {
          tugasList.push({ id: doc.id, ...data });
        }
      });
    });
    tugasList.sort((a, b) => (a.deadline || '').localeCompare(b.deadline || ''));
    return tugasList;
  } catch (error) {
    console.error('Error getTugasAktif:', error);
    return [];
  }
}

// Fungsi baru untuk mengambil upcoming events
async function getUpcomingEvents(limit = 3) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const snapshot = await db.collection('jadwalPenting')
      .where('tanggal', '>=', today)
      .orderBy('tanggal', 'asc')
      .limit(limit)
      .get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error('Error getUpcomingEvents:', error);
    return [];
  }
}

/**
 * LKM Praktikum yang sudah dipublikasikan dosen (mk.praktikumPublished +
 * modul individual aktif) tapi belum diunggah mahasiswa ini. Dipakai untuk
 * widget "LKM Belum Dikumpulkan" di dashboard, sama semangatnya dengan
 * "Tugas Aktif" di atas.
 */
async function getLkmBelumDikumpulkan(mkList, userId) {
  try {
    const mkPublished = mkList.filter(mk => mk.praktikumPublished === true);
    if (mkPublished.length === 0) return [];

    // Modul yang tersedia (aktif) per MK yang dipublikasikan
    const daftarModul = [];
    mkPublished.forEach(mk => {
      const { modulList } = getPublishedModulPraktikum(mk);
      modulList.forEach(m => daftarModul.push({
        mkId: mk.id, mkKode: mk.kode, mkNama: mk.nama, modulId: m.id, modulJudul: m.judul, tanggal: m.tanggal || null
      }));
    });
    if (daftarModul.length === 0) return [];

    // Ambil semua pengumpulan LKM milik mahasiswa ini (satu query, cukup
    // kecil karena per-mahasiswa), lalu jadikan Set "mkId::modulId" supaya
    // gampang dicek mana yang sudah kumpul.
    const lkmSnapshot = await db.collection('lkmPengumpulan').where('mahasiswaId', '==', userId).get();
    const sudahKumpul = new Set();
    lkmSnapshot.docs.forEach(doc => {
      const d = doc.data();
      sudahKumpul.add(`${d.mkId}::${d.modulId}`);
    });

    const belumKumpul = daftarModul.filter(m => !sudahKumpul.has(`${m.mkId}::${m.modulId}`));
    belumKumpul.sort((a, b) => (a.tanggal || '9999').localeCompare(b.tanggal || '9999'));
    return belumKumpul;
  } catch (error) {
    console.error('Error getLkmBelumDikumpulkan:', error);
    return [];
  }
}

// ============================================================================
// RUTE UTAMA DASHBOARD
// ============================================================================

router.get('/', async (req, res) => {
  try {
    const user = req.user;
    const userId = user.id;

    // ⚡ OPTIMISASI KECEPATAN: tagihan, daftar MK, dan event terdekat SAMA
    // SEKALI TIDAK SALING BERGANTUNG - dijalankan bersamaan lewat Promise.all
    // alih-alih menunggu satu-satu berurutan. Hanya getTugasAktif yang harus
    // menunggu (butuh mkIds dari mkList dulu).
    const [tagihan, mkList, upcomingEvents] = await Promise.all([
      getTagihan(userId),
      getMataKuliahDiambil(userId),
      getUpcomingEvents(3)
    ]);
    const mkIds = mkList.map(mk => mk.id);
    const totalSks = mkList.reduce((acc, mk) => acc + (mk.sks || 0), 0);
    const tugasAktif = await getTugasAktif(mkIds);
    const lkmBelumDikumpulkan = await getLkmBelumDikumpulkan(mkList, userId);

    const currentSemester = getCurrentAcademicSemester();
    const semesterSekarang = currentSemester.label;

    let pertemuanRata = 0;
    if (mkList.length > 0) {
      const totalPertemuan = mkList.reduce((acc, mk) => acc + getPertemuanTerkini(mk), 0);
      pertemuanRata = Math.round(totalPertemuan / mkList.length);
    }

    // Hitung total tagihan
    let totalTagihan = 0;
    let totalLunas = 0;
    tagihan.forEach(t => {
      if (t.status === 'lunas') {
        totalLunas += t.jumlah;
      } else {
        totalTagihan += t.jumlah;
      }
    });
    const sisaTagihan = totalTagihan; // total yang belum lunas

    res.render('mahasiswa/dashboard', {
      user,
      uploadSuccess: req.query.upload === 'success',
      tagihan,
      totalTagihan,
      totalLunas,
      sisaTagihan,
      totalSks,
      semesterSekarang,
      pertemuanRata,
      tugasAktif,
      lkmBelumDikumpulkan,
      upcomingEvents  // <-- ditambahkan
    });

  } catch (error) {
    console.error('Error loading mahasiswa dashboard:', error);
    res.status(500).render('error', {
      title: 'Error',
      message: 'Gagal memuat dashboard mahasiswa'
    });
  }
});

module.exports = router;